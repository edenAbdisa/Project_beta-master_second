-- MySQL dump 10.13  Distrib 5.7.25, for Linux (x86_64)
--
-- Host: insightproduction.cv72fqbefuzc.eu-west-1.rds.amazonaws.com    Database: insightportal
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `insight`
DEFAULT CHARACTER SET utf8mb4
DEFAULT COLLATE utf8mb4_unicode_ci;

SET default_storage_engine = INNODB;


-- Function to generate a UUIDv4 value
-- Drop the function if it already exists to ensure integrity
DROP FUNCTION IF EXISTS uuid_v4;
-- Change delimiter to // from ; so that the function body doesn't end the function declaration
DELIMITER //

CREATE FUNCTION uuid_v4()
  RETURNS BINARY(16)
BEGIN
  -- Generate 8 2-byte strings that combine into UUIDv4
  SET @h1 = LPAD(HEX(FLOOR(RAND() * 0xffff)), 4, '0');
  SET @h2 = LPAD(HEX(FLOOR(RAND() * 0xffff)), 4, '0');
  SET @h3 = LPAD(HEX(FLOOR(RAND() * 0xffff)), 4, '0');
  SET @h6 = LPAD(HEX(FLOOR(RAND() * 0xffff)), 4, '0');
  SET @h7 = LPAD(HEX(FLOOR(RAND() * 0xffff)), 4, '0');
  SET @h8 = LPAD(HEX(FLOOR(RAND() * 0xffff)), 4, '0');

  -- 4th section will start with a 4 to indicate UUIDv4
  SET @h4 = CONCAT('4', LPAD(HEX(FLOOR(RAND() * 0x0fff)), 3, '0'));
  -- 5th section first half-byte can only be 8, 9, A, B
  SET @h5 = CONCAT(HEX(FLOOR(RAND() * 4 + 8)), LPAD(HEX(FLOOR(RAND() * 0x0fff)), 3, '0'));

  RETURN UNHEX(LOWER(CONCAT(@h1, @h2, @h3, @h4, @h5, @h6, @h7, @h8)));  
  
END
//

DELIMITER ;

--
-- Table structure for table `api_keys`
--

DROP TABLE IF EXISTS `api_keys`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_keys` (
  `uuid` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `access_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activated` bit(1) NOT NULL,
  `limit_tier` binary(16) NOT NULL,
  `low_hourly` double NOT NULL,
  `low_monthly` int(11) NOT NULL,
  `med_hourly` double NOT NULL,
  `med_monthly` int(11) NOT NULL,
  `high_hourly` double NOT NULL,
  `high_monthly` int(11) NOT NULL,
  `low_reset` bigint(20) NOT NULL,
  `med_reset` bigint(20) NOT NULL,
  `high_reset` bigint(20) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `api_limit_fk` (`limit_tier`),
  CONSTRAINT `api_key_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`),
  CONSTRAINT `api_limit_fk` FOREIGN KEY (`limit_tier`) REFERENCES `api_limits` (`uuid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `api_limits`
--

DROP TABLE IF EXISTS `api_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_limits` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `low_hourly` int(11) NOT NULL,
  `low_monthly` int(11) NOT NULL,
  `med_hourly` int(11) NOT NULL,
  `med_monthly` int(11) NOT NULL,
  `high_hourly` int(11) NOT NULL,
  `high_monthly` int(11) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `api_logging`
--

DROP TABLE IF EXISTS `api_logging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `api_logging` (
  `uuid` binary(16) NOT NULL,
  `api_key_id` binary(16) NOT NULL,
  `event_time` datetime NOT NULL,
  `api_call` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `api_status` smallint(5) unsigned NOT NULL,
  `ip_address` varbinary(16) NOT NULL,
  `header` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_data` json DEFAULT NULL,
  `response` json DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `api_logging_fk` (`api_key_id`),
  CONSTRAINT `api_logging_fk` FOREIGN KEY (`api_key_id`) REFERENCES `api_keys` (`uuid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `article_updates`
--

DROP TABLE IF EXISTS `article_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article_updates` (
  `uuid` binary(16) NOT NULL,
  `content` mediumtext NOT NULL,
  `read_time` smallint(6) NOT NULL,
  `article_id` binary(16) NOT NULL,
  `created_by` binary(16) NOT NULL,
  `updated_by` binary(16) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `article_update_article_fk` (`article_id`),
  KEY `article_update_created_by_fk` (`created_by`),
  KEY `article_update_updated_by_fk` (`updated_by`),
  KEY `article_update_check_in_fk` (`check_in_by`),
  CONSTRAINT `article_update_article_fk` FOREIGN KEY (`article_id`) REFERENCES `articles` (`uuid`),
  CONSTRAINT `article_update_check_in_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`),
  CONSTRAINT `article_update_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`uuid`),
  CONSTRAINT `article_update_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articles` (
  `uuid` binary(16) NOT NULL,
  `title` varchar(255) NOT NULL,
  `summary_text` text NOT NULL,
  `full_text` mediumtext NOT NULL,
  `meta_keywords` varchar(45) DEFAULT NULL,
  `read_time` smallint(6) NOT NULL,
  `img_link` varchar(255) DEFAULT NULL,
  `sef_url_id` binary(16) NOT NULL,
  `category_id` binary(16) NOT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `impact_id` binary(16) NOT NULL,
  `test_recommendation_id` binary(16) DEFAULT NULL,
  `richcard_type` varchar(255) DEFAULT NULL,
  `richcard_id` binary(16) DEFAULT NULL,
  `view_count` int(11) NOT NULL,
  `published` bit(1) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `requires_approval` bit(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_by` binary(16) NOT NULL,
  `updated_by` binary(16) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  `show_explorer_test` bit(1) NOT NULL,
  `featured` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `title` (`title`),
  UNIQUE KEY `sef_url_id` (`sef_url_id`),
  UNIQUE KEY `test_recommendation_id` (`test_recommendation_id`),
  KEY `article_category_fk` (`category_id`),
  KEY `article_impact_fk` (`impact_id`),
  KEY `article_created_by_fk` (`created_by`),
  KEY `article_updated_by_fk` (`updated_by`),
  KEY `article_check_in_fk` (`check_in_by`),
  CONSTRAINT `article_category_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`uuid`),
  CONSTRAINT `article_check_in_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`),
  CONSTRAINT `article_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`uuid`),
  CONSTRAINT `article_impact_fk` FOREIGN KEY (`impact_id`) REFERENCES `impact_rating` (`uuid`),
  CONSTRAINT `article_recommendation_fk` FOREIGN KEY (`test_recommendation_id`) REFERENCES `test_recommendation` (`uuid`),
  CONSTRAINT `article_sef_url_fk` FOREIGN KEY (`sef_url_id`) REFERENCES `sef_urls` (`uuid`),
  CONSTRAINT `article_updated_by_fk` FOREIGN KEY (`updated_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `blocked_ip`
--

DROP TABLE IF EXISTS `blocked_ip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blocked_ip` (
  `uuid` binary(16) NOT NULL,
  `ip_address` varbinary(16) NOT NULL,
  `count` smallint(5) unsigned NOT NULL,
  `end_date` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(30) NOT NULL,
  `sef_url_id` binary(16) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `sef_url_id` (`sef_url_id`),
  KEY `cat_check_in_fk` (`check_in_by`),
  CONSTRAINT `cat_check_in_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`),
  CONSTRAINT `cat_sef_url_fk` FOREIGN KEY (`sef_url_id`) REFERENCES `sef_urls` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `email_templates`
--

DROP TABLE IF EXISTS `email_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `email_templates` (
  `uuid` binary(16) NOT NULL,
  `subject` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_in` bit(1) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `email_template_user_fk` (`check_in_by`),
  CONSTRAINT `email_template_user_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `impact_rating`
--

DROP TABLE IF EXISTS `impact_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `impact_rating` (
  `uuid` binary(16) NOT NULL,
  `name` tinyint(1) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `name` (`name`),
  KEY `impact_rating_fk` (`check_in_by`),
  CONSTRAINT `impact_rating_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `newsletter`
--

DROP TABLE IF EXISTS `newsletter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `newsletter` (
  `uuid` binary(16) NOT NULL,
  `subject` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `published` bit(1) NOT NULL,
  `publish_date` datetime NOT NULL,
  `created_by` binary(16) NOT NULL,
  `created_at` datetime NOT NULL,
  `checked_in` bit(1) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `newsletter_created_by_fk` (`created_by`),
  KEY `newsletter_check_in_fk` (`check_in_by`),
  CONSTRAINT `newsletter_check_in_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`),
  CONSTRAINT `newsletter_created_by_fk` FOREIGN KEY (`created_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `is_active` bit(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `reset_code` varchar(255) NOT NULL,
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `token_UNIQUE` (`token`),
  UNIQUE KEY `reset_code_UNIQUE` (`reset_code`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `profiling_log`
--

DROP TABLE IF EXISTS `profiling_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiling_log` (
  `uuid` binary(16) NOT NULL,
  `function_id` binary(16) NOT NULL,
  `execution_time` smallint(6) NOT NULL,
  `datetime` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `prof_log_fk` (`function_id`),
  CONSTRAINT `prof_log_fk` FOREIGN KEY (`function_id`) REFERENCES `profiling_stats` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `profiling_stats`
--

DROP TABLE IF EXISTS `profiling_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `profiling_stats` (
  `uuid` binary(16) NOT NULL,
  `function_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `average_exec` smallint(6) DEFAULT NULL,
  `min_exec` smallint(6) DEFAULT NULL,
  `max_exec` smallint(6) DEFAULT NULL,
  `exec_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `function_name` (`function_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `related_articles`
--

DROP TABLE IF EXISTS `related_articles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `related_articles` (
  `uuid` binary(16) NOT NULL,
  `id` int(16) NOT NULL AUTO_INCREMENT,
  `original_article_id` binary(16) NOT NULL,
  `related_article` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10564 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `release_advisor`
--

DROP TABLE IF EXISTS `release_advisor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `release_advisor` (
  `uuid` binary(16) NOT NULL,
  `article_id` binary(16) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `subtitle` varchar(50) NOT NULL,
  `published` bit(1) NOT NULL,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `release_article_key` (`article_id`),
  CONSTRAINT `release_article_fk` FOREIGN KEY (`article_id`) REFERENCES `articles` (`uuid`),
  CONSTRAINT `release_article_key` FOREIGN KEY (`article_id`) REFERENCES `articles` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sef_urls`
--

DROP TABLE IF EXISTS `sef_urls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sef_urls` (
  `uuid` binary(16) NOT NULL,
  `sef_url` varchar(255) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `sef_url` (`sef_url`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subcategories`
--

DROP TABLE IF EXISTS `subcategories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subcategories` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(30) NOT NULL,
  `category_id` binary(16) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `subcategories_cat_fk_idx` (`category_id`),
  CONSTRAINT `subcategories_cat_fk` FOREIGN KEY (`category_id`) REFERENCES `categories` (`uuid`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `subscriptions`
--

DROP TABLE IF EXISTS `subscriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subscriptions` (
  `uuid` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `user_level_id` binary(16) NOT NULL,
  `organisation` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `payment_date` datetime DEFAULT NULL,
  `start_date` datetime DEFAULT NULL,
  `end_date` datetime DEFAULT NULL,
  `base_amount` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_amount` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gross_amount` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recurring` bit(1) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `user_level_fk_2` (`user_level_id`),
  KEY `subscription_user_fk` (`user_id`),
  CONSTRAINT `subscription_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`),
  CONSTRAINT `user_level_fk_2` FOREIGN KEY (`user_level_id`) REFERENCES `user_levels` (`uuid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `support_categories`
--

DROP TABLE IF EXISTS `support_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_categories` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_in` bit(1) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `supp_cat_check_in_fk` (`check_in_by`),
  CONSTRAINT `supp_cat_check_in_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `support_comments`
--

DROP TABLE IF EXISTS `support_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_comments` (
  `uuid` binary(16) NOT NULL,
  `ticket_id` binary(16) NOT NULL,
  `from_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` binary(16) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `supp_com_ticket_fk` (`ticket_id`),
  KEY `supp_com_user_fk` (`user_id`),
  CONSTRAINT `supp_com_ticket_fk` FOREIGN KEY (`ticket_id`) REFERENCES `support_ticket` (`uuid`),
  CONSTRAINT `supp_com_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `support_status`
--

DROP TABLE IF EXISTS `support_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_status` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checked_in` bit(1) NOT NULL,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `supp_stat_check_in_fk` (`check_in_by`),
  CONSTRAINT `supp_stat_check_in_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `support_ticket`
--

DROP TABLE IF EXISTS `support_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `support_ticket` (
  `uuid` binary(16) NOT NULL,
  `category_id` binary(16) NOT NULL,
  `status_id` binary(16) NOT NULL,
  `subject` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` binary(16) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `support_category_fk` (`category_id`),
  KEY `support_status_fk` (`status_id`),
  KEY `support_user_fk` (`user_id`),
  CONSTRAINT `support_category_fk` FOREIGN KEY (`category_id`) REFERENCES `support_categories` (`uuid`),
  CONSTRAINT `support_status_fk` FOREIGN KEY (`status_id`) REFERENCES `support_status` (`uuid`),
  CONSTRAINT `support_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_browsers`
--

DROP TABLE IF EXISTS `ta_browsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_browsers` (
  `uuid` binary(16) NOT NULL,
  `brand` varchar(50) COLLATE utf8_bin NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8 NOT NULL,
  `release_date` date DEFAULT NULL,
  `stable_info` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `stable_download` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `beta_info` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `beta_download` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `alpha_info` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `alpha_download` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `ta_browsers_uc_1` (`name`,`version`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_countries`
--

DROP TABLE IF EXISTS `ta_countries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_countries` (
  `uuid` binary(16) NOT NULL,
  `code` char(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `region` enum('AF','AN','AS','EU','NA','OC','SA') COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_users` int(10) unsigned DEFAULT NULL,
  `desktop_users` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_devices`
--

DROP TABLE IF EXISTS `ta_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_devices` (
  `uuid` binary(16) NOT NULL,
  `model` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `brand` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `announced_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `release_date` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `img_link` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_size` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_resolution` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_chipset` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `technology` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `2g_bands` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `3g_bands` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `4g_bands` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `network_speed` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gprs` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `edge` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dimensions` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weight` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `build` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sim` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_body_features` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `waterproof_rating` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_size` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_res` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `multi_touch` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `display_protection` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_display_features` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `os` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chipset` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gpu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_slot` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `internal_storage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ram` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary_camera` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `camera_features` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_features` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secondary_camera` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alert_types` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loudspeaker` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `3_5mm_jack` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_sound_features` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `wlan` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bluetooth` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gps` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nfc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `infrared_port` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `radio` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usb` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sensors` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `messaging` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_features` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `battery` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `battery_details` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stand_by` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `talk_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `music_time` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `colours` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sar_eu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performance` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_ms_browsers`
--

DROP TABLE IF EXISTS `ta_ms_browsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ms_browsers` (
  `uuid` binary(16) NOT NULL,
  `browseruuid` binary(16) NOT NULL,
  `countryuuid` binary(16) NOT NULL,
  `marketpenetration` decimal(5,1) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `browsers` (`date`,`countryuuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_ms_desktop_browsers`
--

DROP TABLE IF EXISTS `ta_ms_desktop_browsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ms_desktop_browsers` (
  `uuid` binary(16) NOT NULL,
  `browseruuid` binary(16) NOT NULL,
  `countryuuid` binary(16) NOT NULL,
  `osuuid` binary(16) NOT NULL,
  `marketpenetration` decimal(5,2) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `desk_browsers` (`date`,`countryuuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_ms_mobile_browsers`
--

DROP TABLE IF EXISTS `ta_ms_mobile_browsers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ms_mobile_browsers` (
  `uuid` binary(16) NOT NULL,
  `deviceuuid` binary(16) NOT NULL,
  `osuuid` binary(16) NOT NULL,
  `browseruuid` binary(16) NOT NULL,
  `countryuuid` binary(16) NOT NULL,
  `marketpenetration` decimal(5,2) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `mob_browsers` (`date`,`countryuuid`,`marketpenetration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_ms_mobile_devices`
--

DROP TABLE IF EXISTS `ta_ms_mobile_devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ms_mobile_devices` (
  `uuid` binary(16) NOT NULL,
  `deviceuuid` binary(16) NOT NULL,
  `countryuuid` binary(16) NOT NULL,
  `osuuid` binary(16) NOT NULL,
  `marketpenetration` decimal(5,2) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `mob_devices` (`date`,`countryuuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_ms_oss`
--

DROP TABLE IF EXISTS `ta_ms_oss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_ms_oss` (
  `uuid` binary(16) NOT NULL,
  `osuuid` binary(16) NOT NULL,
  `countryuuid` binary(16) NOT NULL,
  `marketpenetration` decimal(5,1) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `os` (`countryuuid`,`date`,`marketpenetration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ta_oss`
--

DROP TABLE IF EXISTS `ta_oss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ta_oss` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `version` varchar(255) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `ta_oss_uc_1` (`name`,`version`),
  UNIQUE KEY `uuid` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `teams`
--

DROP TABLE IF EXISTS `teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teams` (
  `uuid` binary(16) NOT NULL,
  `team_manager` binary(16) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `team_manager` (`team_manager`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `test_recommendation`
--

DROP TABLE IF EXISTS `test_recommendation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_recommendation` (
  `uuid` binary(16) NOT NULL,
  `content` text,
  `check_in_by` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `test_recommendation_fk` (`check_in_by`),
  CONSTRAINT `test_recommendation_fk` FOREIGN KEY (`check_in_by`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_levels`
--

DROP TABLE IF EXISTS `user_levels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_levels` (
  `uuid` binary(16) NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `permissions` json NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_logging`
--

DROP TABLE IF EXISTS `user_logging`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_logging` (
  `uuid` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `action` enum('Login','Logout','Change Password','Forgotten Password',' Failed Login') COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_time` datetime NOT NULL,
  `ip_address` varbinary(16) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `user_logging_fk` (`user_id`),
  CONSTRAINT `user_logging_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_notifications`
--

DROP TABLE IF EXISTS `user_notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_notifications` (
  `uuid` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `newletter_notification` bit(1) NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `notifications_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_trial`
--

DROP TABLE IF EXISTS `user_trial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_trial` (
  `uuid` binary(16) NOT NULL,
  `user_id` binary(16) NOT NULL,
  `confirmation_token` varchar(255) DEFAULT NULL,
  `sent_trial_email` bit(1) NOT NULL,
  `expire_at` datetime NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `user_id_fk` (`user_id`),
  CONSTRAINT `user_id_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`uuid`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `uuid` binary(16) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `surname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_level_id` binary(16) NOT NULL,
  `activated` bit(1) NOT NULL,
  `blocked` bit(1) NOT NULL,
  `block_count` smallint(5) unsigned DEFAULT NULL,
  `last_block_date` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `last_visit` datetime DEFAULT NULL,
  `team_id` binary(16) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  UNIQUE KEY `uuid` (`uuid`),
  UNIQUE KEY `email` (`email`),
  KEY `user_level_fk` (`user_level_id`),
  CONSTRAINT `user_level_fk` FOREIGN KEY (`user_level_id`) REFERENCES `user_levels` (`uuid`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-02-18 13:15:19
