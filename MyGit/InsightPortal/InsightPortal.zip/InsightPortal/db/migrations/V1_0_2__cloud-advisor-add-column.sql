ALTER TABLE cloud_advisor 
    ADD COLUMN max_slots INT(11) NOT NULL,
    ADD COLUMN company_name varchar(50) NOT NULL,
    ADD COLUMN browser_rules ENUM('ALPHA_CHANGE', 'BETA_CHANGE', 'PRODUCTION_CHANGE', ' NOTHING') COLLATE utf8mb4_unicode_ci NOT NULL,
    ADD COLUMN device_rules ENUM('TEST_ADVISOR', 'QTF_ADVISOR', 'NOTHING') COLLATE utf8mb4_unicode_ci NOT NULL;
    
ALTER TABLE tasks
    ADD COLUMN target_date DATETIME NOT NULL,
    ADD COLUMN cloud_uuid BINARY(16) NOT NULL,
    CHANGE slot_id slot_uuid BINARY(16) NOT NULL;
    
ALTER TABLE slot_browsers
    CHANGE COLUMN slot_id slot_uuid BINARY(16) NOT NULL;
    
ALTER TABLE cloud_advisor_countries
    ADD PRIMARY KEY (cloud_uuid, country_uuid);

ALTER TABLE slot_browsers
    ADD PRIMARY KEY (slot_uuid, browser_uuid);
    
ALTER TABLE tasks
    CHANGE priority priority int(11) NOT NULL,
    ADD UNIQUE (priority);