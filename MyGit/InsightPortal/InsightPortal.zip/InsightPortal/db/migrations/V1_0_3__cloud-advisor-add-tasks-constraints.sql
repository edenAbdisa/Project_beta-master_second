ALTER TABLE `insight`.`tasks`
ADD INDEX `tasks_slots_idx` (`slot_uuid` ASC) VISIBLE;
;
ALTER TABLE `insight`.`tasks`
ADD CONSTRAINT `tasks_slots`
  FOREIGN KEY (`slot_uuid`)
  REFERENCES `insight`.`slots` (`uuid`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `insight`.`tasks`
ADD INDEX `tasks_cloud_idx` (`cloud_uuid` ASC) VISIBLE;
;
ALTER TABLE `insight`.`tasks`
ADD CONSTRAINT `tasks_cloud`
  FOREIGN KEY (`cloud_uuid`)
  REFERENCES `insight`.`cloud_advisor` (`uuid`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
