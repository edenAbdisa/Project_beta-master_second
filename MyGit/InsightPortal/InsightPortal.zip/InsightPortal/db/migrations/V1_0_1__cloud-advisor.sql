-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 05, 2019 at 07:58 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `insight`
--

-- --------------------------------------------------------

--
-- Table structure for table `cloud_advisor`
--

DROP TABLE IF EXISTS `cloud_advisor`;
CREATE TABLE IF NOT EXISTS `cloud_advisor` (
  `uuid` binary(16) NOT NULL,
  `coverage` int(11) DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cloud_advisor_countries`
--

DROP TABLE IF EXISTS `cloud_advisor_countries`;
CREATE TABLE IF NOT EXISTS `cloud_advisor_countries` (
  `cloud_uuid` binary(16) NOT NULL,
  `country_uuid` binary(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slots`
--

DROP TABLE IF EXISTS `slots`;
CREATE TABLE IF NOT EXISTS `slots` (
  `uuid` binary(16) NOT NULL,
  `cloud_advisor_uuid` binary(16) NOT NULL,
  `slot_id` int(11) NOT NULL,
  `device_uuid` binary(16) DEFAULT NULL,
  `os_uuid` binary(16) DEFAULT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `slot_browsers`
--

DROP TABLE IF EXISTS `slot_browsers`;
CREATE TABLE IF NOT EXISTS `slot_browsers` (
  `slot_id` int(11) NOT NULL,
  `browser_uuid` binary(16) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE IF NOT EXISTS `tasks` (
  `uuid` binary(16) NOT NULL,
  `slot_id` int(11) NOT NULL,
  `priority` enum('HIGH','MEDIUM','LOW','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_type` enum('UPGRADE_DEVICE','UPGRADE_BROWSER','UPGRADE_OS','') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('COMPLETED','WAITING','IGNORED','ARCHIVED') COLLATE utf8mb4_unicode_ci NOT NULL,
  `status_comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
