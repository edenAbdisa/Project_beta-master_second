package com.qualitytaskforce.insightportal.articleIntegrationTests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DatabaseSimple {
	
	
	@Autowired 
	WebApplicationContext wac;
	
	@Autowired 
	MockHttpSession session;
	
	@Autowired 
	MockHttpServletRequest request;
	
	private MockMvc mockMvc;
	
	/** Please remove if these are not used, or atleast keep them commented out
	private static Logger LOG = LoggerFactory.getLogger(DatabaseSimple.class);

	@Autowired
	private ArticleService articleService;	
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	private ImpactRatingService impactRatingService;
	
	@Autowired
	private TestRecommendationService testRecommendationService;
	
	@Autowired
	private SefURLService sefURLService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserLevelService userLevelService;
	
	@Autowired
	private ArticleCardService articleCardService;
	
	@Autowired
	private RelatedArticlesService relatedArticlesService;
	
	*/

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
		
	@Test	
	public void testCase() throws Exception {			
		
		/*======= GET =======*/
		//this.mockMvc.perform(get("/article/set-related/{category-name}","category 1"))
		//.andExpect(status().isOk()).andReturn();	
		
		/*TODO Test if make sort elements in map*/
		
		this.mockMvc.perform(get("/article/get-related/{article-name}","New-browser-Mozilla-Firefox-5"))
			.andExpect(status().isOk()).andReturn();	
	}
	
	
}