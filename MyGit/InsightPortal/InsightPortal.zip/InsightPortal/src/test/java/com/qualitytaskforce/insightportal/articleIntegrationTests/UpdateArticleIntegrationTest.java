package com.qualitytaskforce.insightportal.articleIntegrationTests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.util.StringToSefURL;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UpdateArticleIntegrationTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;
	
	@Autowired
	ArticleService articleService;
	
	@Autowired
	CategoryService categoryService;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
		
	@Test	
	public void testCase() throws Exception {	
		
		/*======= GET =======*/
		this.mockMvc.perform(get("/article/edit-article"))
				.andExpect(status().isOk()).andReturn();		
		
		/*======= POST =======*/ 
		/*Generate title*/
		String generatedTitle = articleService.getAllArticles().get(0).getTitle()+"1";
		/*Get category*/
		String category = categoryService.getAllCategories().get(0).getName();
		/*Generate sef-url*/
		String sefUrlString = StringToSefURL.stringToSefURL(generatedTitle);
		
		
		this.mockMvc.perform(post("/article/edit-article/{uuid}","a3e43b37-488d-4b74-89aa-42abcd0eae52")
            .param("articleTitle", generatedTitle)
            .param("articleSefURL", sefUrlString)
            .param("articleSummaryText", "summ-parsed")
            .param("articleUpdatedAt", "2017-02-10")
            .param("articleFullText", "full-parsed")
            .param("testRecommendation", "test-recomend-parsed")
            .param("impactRatingName", "5")
            .param("categoryName", category)
            .param("update","update"))
			.andExpect(status().isOk()).andReturn();
	}			
}

