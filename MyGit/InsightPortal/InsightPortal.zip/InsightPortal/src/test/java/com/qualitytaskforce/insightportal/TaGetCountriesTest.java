package com.qualitytaskforce.insightportal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TaGetCountriesTest {

	@Autowired WebApplicationContext wac;

	@Autowired MockHttpSession session;

	@Autowired MockHttpServletRequest request;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}

	@Test
	public void getCountries() throws Exception {
		this.mockMvc.perform(get("/testadvisor/countries/"))
			.andExpect(status().isOk());
	}

	@Test
	public void getCountriesParam() throws Exception {
		this.mockMvc.perform(get("/testadvisor/countries/EU"))
			.andExpect(status().isNotFound());
	}

	@Test
	public void getRegions() throws Exception {
		this.mockMvc.perform(get("/testadvisor/regions/"))
			.andExpect(status().isOk());
	}

	@Test
	public void getRegionsParam() throws Exception {
		this.mockMvc.perform(get("/testadvisor/regions/EU"))
			.andExpect(status().isNotFound());
	}

	@Test
	public void getCountriesByRegion() throws Exception {
		this.mockMvc.perform(get("/testadvisor/countriesbyregion/EU"))
			.andExpect(status().isOk());
	}

	@Test
	public void getCountriesByRegionFail() throws Exception {
		this.mockMvc.perform(get("/testadvisor/countriesbyregion/ABC"))
			.andExpect(status().isNotFound());
	}

	@Test
	public void getCountriesByRegionNoParam() throws Exception {
		this.mockMvc.perform(get("/testadvisor/countriesbyregion/"))
			.andExpect(status().isNotFound());
	}
}