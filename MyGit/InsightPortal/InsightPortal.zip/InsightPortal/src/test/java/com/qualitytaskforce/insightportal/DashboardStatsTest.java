package com.qualitytaskforce.insightportal;

import com.qualitytaskforce.insightportal.model.testadvisor.ChartData;
import org.junit.Assert;
import org.junit.Test;

import java.util.Arrays;
import java.util.List;

public class DashboardStatsTest {

    @Test
    public void testRescaling() {
        float expected = 63.536379f;
        ChartData android = new ChartData("Android", 75.1f);
        ChartData iOS = new ChartData("iOS", 43.1f);
        List<ChartData> chartData = Arrays.asList(android, iOS);

        float totalMarketShare = (float) chartData.stream().mapToDouble(ChartData::getMarketPen).sum();
        chartData.forEach(p -> p.setMarketPen(p.getMarketPen() / totalMarketShare * 100));

        Assert.assertEquals(expected, chartData.get(0).getMarketPen(), 0.1);
        Assert.assertEquals(100 - expected, chartData.get(1).getMarketPen(), 0.1);

    }
}
