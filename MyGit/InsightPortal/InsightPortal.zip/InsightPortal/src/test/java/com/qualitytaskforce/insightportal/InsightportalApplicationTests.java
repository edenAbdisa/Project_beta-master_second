package com.qualitytaskforce.insightportal;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.qualitytaskforce.insightportal.controller.users.ApiLimitController;
import com.qualitytaskforce.insightportal.controller.ArticleController;
import com.qualitytaskforce.insightportal.controller.MainController;
import com.qualitytaskforce.insightportal.controller.SearchControllerLight;
import com.qualitytaskforce.insightportal.controller.users.UserController;
import com.qualitytaskforce.insightportal.controller.users.UserLevelController;

@RunWith(SpringRunner.class)
@SpringBootTest
public class InsightportalApplicationTests {

	@Autowired
	private ApiLimitController apiLimitController;
	
	@Autowired
	private ArticleController articleController;
	
	@Autowired
	private MainController mainController;

	@Autowired
	private SearchControllerLight searchControllerLight;
	
	@Autowired
	private UserController userController;
	
	@Autowired
	private UserLevelController userLevelController;
	
	@Test
	public void contextLoads(){
		assertThat(apiLimitController).isNotNull();
		assertThat(articleController).isNotNull();
		assertThat(mainController).isNotNull();
		assertThat(searchControllerLight).isNotNull();
		assertThat(userController).isNotNull();
		assertThat(userLevelController).isNotNull();
	}

}
