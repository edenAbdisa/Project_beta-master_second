package com.qualitytaskforce.insightportal.news;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NewsListWithFilterTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	// Util
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
	
	@Test
	public void testFilterNewsResponse200() throws Exception{		
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("dateStart", "01/05/2018");
		 map.put("dateStop", "15/05/2018");
		 map.put("keywords", "none");
		 List<String> list = new ArrayList<String>();
		 list.add("adobe");
		 list.add("java");
		 map.put("checkedSubcategories", list);
		
		// http://localhost:88/filter/get-filtered-articles
		this.mockMvc.perform(post("/filter/get-filtered-articles")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(200))
					.andReturn();		
	}
	
	@Test
	public void testWrongDateSequenceResponse500() throws Exception{
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("dateStart", "15/05/2018");
		 map.put("dateStop", "01/05/2018");
		 map.put("keywords", "none");
		 List<String> list = new ArrayList<String>();
		 list.add("adobe");
		 list.add("java");
		 map.put("checkedSubcategories", list);
		
		// http://localhost:88/filter/get-filtered-articles
		this.mockMvc.perform(post("/filter/get-filtered-articles")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(500))
					.andReturn();		
	}
	
	@Test
	public void testNoSubcategoriesAsParamResponse500() throws Exception{
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("dateStart", "01/05/2018");
		 map.put("dateStop", "15/05/2018");
		 map.put("keywords", "none");
		 List<String> list = new ArrayList<String>();
		 map.put("checkedSubcategories", list);
		
		// http://localhost:88/filter/get-filtered-articles
		this.mockMvc.perform(post("/filter/get-filtered-articles")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(500))
					.andReturn();		
	}
	
	@Test
	public void testNoKeywordsAsParamResponse500() throws Exception{
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("dateStart", "01/05/2018");
		 map.put("dateStop", "15/05/2018");		 
		 List<String> list = new ArrayList<String>();
		 list.add("adobe");
		 list.add("java");
		 map.put("checkedSubcategories", list);
		
		// http://localhost:88/filter/get-filtered-articles
		this.mockMvc.perform(post("/filter/get-filtered-articles")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(500))
					.andReturn();
	}
	
	@Test
	public void testNoStartDateAsParamResponse500() throws Exception{
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("dateStop", "15/05/2018");	
		 map.put("keywords", "none");
		 List<String> list = new ArrayList<String>();
		 list.add("adobe");
		 list.add("java");
		 map.put("checkedSubcategories", list);
		
		// http://localhost:88/filter/get-filtered-articles
		this.mockMvc.perform(post("/filter/get-filtered-articles")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(500))
					.andReturn();
	}
	
	@Test
	public void testNoStopDateAsParamResponse500() throws Exception{
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("dateStart", "01/05/2018");
		 map.put("keywords", "none");
		 List<String> list = new ArrayList<String>();
		 list.add("adobe");
		 list.add("java");
		 map.put("checkedSubcategories", list);
		
		// http://localhost:88/filter/get-filtered-articles
		this.mockMvc.perform(post("/filter/get-filtered-articles")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(500))
					.andReturn();
	}
	
	
	
}
