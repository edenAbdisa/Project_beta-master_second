package com.qualitytaskforce.insightportal.backoffice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CreateArticleTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	// Util
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
	
	
	@Test
	public void testCreaterticleResponse200() throws Exception{
		
		 Map<String, Object> map = new HashMap<>();
		 map.put("artworkUrl", "https://s3-eu-west-1.amazonaws.com/insightportal/images/cards/brands/Amazon.png");
		 map.put("categoryName", "Browser News");
		 map.put("fullText", "<p>TT</p>"); 
		 map.put("impactRatingName", 5);
		 map.put("published", false);
		 List<String> relatedlist = new ArrayList<String>();
		   relatedlist.add("Firefox To Add Blunt Warning About Insecure HTTP Logins");
		   relatedlist.add("Firefox issued minor security update");
		   relatedlist.add("Chrome will start flagging insecure HTTP sites");
		 map.put("relatedArticles", relatedlist);
		 List<String> ralist = new ArrayList<String>();
		 map.put("releaseAdvisors", ralist);
		 
		 map.put("richcardBrand", "");
		 map.put("richcardModel", "");
		 map.put("richcardType", "generic");
		 
		 map.put("subcategoryName", "Mobile Browsers");
		 map.put("summaryText", "TT");
		 map.put("testRecommendation", "TT");
		 map.put("title", "Just for test #2.2.4");
		
		
		// http://localhost:88/article
		this.mockMvc.perform(post("/article")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(200))
					.andReturn();
	}

}
