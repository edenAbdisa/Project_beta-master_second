package com.qualitytaskforce.insightportal.backoffice;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.http.MediaType;


@RunWith(SpringRunner.class)
@SpringBootTest
public class EditArticleTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	// Util
	public static String asJsonString(final Object obj) {
	    try {
	        final ObjectMapper mapper = new ObjectMapper();
	        final String jsonContent = mapper.writeValueAsString(obj);
	        return jsonContent;
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
		
	@Test
	public void testUpdateArticleResponse200() throws Exception{
		
		/*
		 *  [REMEMBER] User is geted from context. So need be mocked in "ArticleServicePut"
		 */
		
		 Map<String, Object> map = new HashMap<>();
		 List<String> updateslist = new ArrayList<String>(); // is redundant
		 map.put("articleUpdates", updateslist);
		 map.put("artworkUrl", "https://s3-eu-west-1.amazonaws.com/insightportal/images/cards/brands/Amazon.png");
		 map.put("categoryId", "8525e043-d1e1-4a77-85d2-78a1e57e1199"); // is redundant
		 map.put("categoryName", "Browser News");
		 map.put("fullText", "<p>TT</p>");
		 map.put("impactRatingId", "8525e043-d1e1-4a77-85d2-78a1e57e1199"); // is redundant
		 map.put("impactRatingName", 5);
		 map.put("published", false);
		 List<String> relatedlist = new ArrayList<String>();
		   relatedlist.add("Firefox To Add Blunt Warning About Insecure HTTP Logins");
		   relatedlist.add("Firefox issued minor security update");
		   relatedlist.add("Chrome will start flagging insecure HTTP sites");
		 map.put("relatedArticles", relatedlist);
		 
		 List<String> ralist = new ArrayList<String>();
		 map.put("releaseAdvisors", ralist);
		 
		 map.put("richcardBrand", "");
		 map.put("richcardId", null);
		 map.put("richcardModel", "");
		 map.put("richcardType", "generic");
		 map.put("subcategoryName", "Mobile Browsers");
		 map.put("summaryText", "TT");
		 map.put("testRecommendation", "TT");
		 map.put("testRecommendationId", "073cb182-b8fb-4fd0-a665-da4164021124");
		 map.put("title", "Just for test #2.2.1");
		 map.put("uuid", "fa234d52-f38d-4e22-9bec-163909b651e7");		 
		
		// http://localhost:88/article
		this.mockMvc.perform(put("/article/fa234d52-f38d-4e22-9bec-163909b651e7")
					.content(asJsonString(map))
				 	.contentType(MediaType.APPLICATION_JSON)
				  	.accept(MediaType.APPLICATION_JSON))				 	
					.andExpect(status().is(200))
					.andReturn();
	}

}
