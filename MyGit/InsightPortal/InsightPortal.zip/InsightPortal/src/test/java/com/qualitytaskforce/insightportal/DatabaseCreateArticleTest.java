package com.qualitytaskforce.insightportal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.qualitytaskforce.insightportal.model.post.ArticleCombinedRequest;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.service.ImpactRatingService;
import com.qualitytaskforce.insightportal.service.SefURLService;
import com.qualitytaskforce.insightportal.service.TestRecommendationService;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;

@RunWith(SpringRunner.class)
@SpringBootTest
@Component
public class DatabaseCreateArticleTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Autowired
	ArticleService articleService;

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	ImpactRatingService impactRatingService;
	
	@Autowired
	TestRecommendationService testRecommendationService;
	
	@Autowired
	SefURLService sefURLService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserLevelService userLevelService;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	@Test
	public void testCase() throws Exception {
			
		/* 
		 * Selected title must be unique
		 * Selected category must be exited
		 * ImpactRating must be is exited
		 * 
		 * Title mustn't be duplicated
		 * Field sef-url mustn't be duplicated 
		 */
		
		/*TODO change filds with createdAt, updatedAt to ArticleUpdate object*/
		
		this.mockMvc.perform(get("/article/create-article"))
		.andExpect(status().isOk()).andReturn();		
		
		ArticleCombinedRequest articleRequest = new ArticleCombinedRequest();
		/*articleRequest.setArticleTitle("titlezxzxz");
		articleRequest.setArticleFullText("full-parsed");
		articleRequest.setArticleSummaryText("summary-parsed");		
		articleRequest.setArticleUpdatedAt("10-02-2017");
		articleRequest.setCategoryName("category");
		articleRequest.setImpactRatingName(5);
		articleRequest.setTestRecommendationContent("test-test-test");*/
		
		this.mockMvc.perform(post("/article/create-article")				
				.flashAttr("articleRequest",articleRequest))
				.andExpect(status().isOk()).andReturn();		
	}	
	
	public Date strToDate(String str){
		
		Date date = null;
	    DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
	    
    	try{
    		
    	date = df.parse(str);	 
        	
	    }catch (Exception e ){
	    	
	    }
	     
	    return date;	
}
	
}