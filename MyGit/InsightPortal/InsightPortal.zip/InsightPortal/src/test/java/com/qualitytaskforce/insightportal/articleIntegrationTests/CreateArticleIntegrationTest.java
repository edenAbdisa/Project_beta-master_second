package com.qualitytaskforce.insightportal.articleIntegrationTests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.qualitytaskforce.insightportal.model.post.ArticleCombinedRequest;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.service.ImpactRatingService;
import com.qualitytaskforce.insightportal.service.SefURLService;
import com.qualitytaskforce.insightportal.service.TestRecommendationService;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
@Component
public class CreateArticleIntegrationTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Autowired
	ArticleService articleService;

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	ImpactRatingService impactRatingService;
	
	@Autowired
	TestRecommendationService testRecommendationService;
	
	@Autowired
	SefURLService sefURLService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserLevelService userLevelService;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	
	@Test
	public void testCase() throws Exception {
			
		/* 
		 * Title must be unique
		 * 
		 * Category must be exited
		 * 
		 * ImpactRating must be is exited
		 * 
		 * Title mustn't be duplicated
		 */
		
		/*======= GET =======*/
		this.mockMvc.perform(get("/article/create-article"))
		.andExpect(status().isOk()).andReturn();		
		
		/*======= POST =======*/ 
		/*Get category*/
		String category = categoryService.getAllCategories().get(0).getName();
		/*Get impact rating*/
		int impactRating = impactRatingService.findAll().get(0).getName();
		ArticleCombinedRequest articleRequest = new ArticleCombinedRequest();
		/*articleRequest.setArticleTitle("New Mozilla Firefox 57");
		articleRequest.setArticleFullText("full-parsed");
		articleRequest.setArticleSummaryText("summary-parsed");		
		articleRequest.setArticleUpdatedAt(new Date().toString());
		articleRequest.setCategoryName(category);
		articleRequest.setImpactRatingName(impactRating);
		articleRequest.setTestRecommendationContent(StringToSefURL.stringToSefURL(articleRequest.getArticleTitle())); */
		
		this.mockMvc.perform(post("/article/create-article")				
				.flashAttr("articleRequest",articleRequest))
				.andExpect(status().isOk()).andReturn();		
	}		
}