package com.qualitytaskforce.insightportal.articleIntegrationTests;

import static org.junit.Assert.assertEquals;

import java.util.UUID;

import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.util.VerifyUUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
@Component
public class VerifyUUIDTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;	
	
	@Autowired 
	ArticleService articleService;	
	
	@Test
	public void testCase() throws Exception {	
			
		UUID uuid = VerifyUUID.verifyUUID("434a8537-a187-4b22-b43f-c5da574786c9321");	
		boolean isExistArticle = articleService.updateCounter(uuid);
		assertEquals(isExistArticle,false);
		
		
	}	
}

