package com.qualitytaskforce.insightportal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TaBrowserMarketShareTest {

	@Autowired WebApplicationContext wac;

	@Autowired MockHttpSession session;

	@Autowired MockHttpServletRequest request;

	private MockMvc mockMvc;

	private String browserUrl = "/testadvisor/browsers/";

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}

	@Test
	public void getBrowserSimple() throws Exception {
		this.mockMvc.perform(get(browserUrl + "CH"))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserSimpleFail() throws Exception {
		this.mockMvc.perform(get(browserUrl + "XX"))
			.andExpect(status().isNotFound());
	}

	@Test
	public void getBrowserSimpleNoParam() throws Exception {
		this.mockMvc.perform(get(browserUrl))
			.andExpect(status().isMethodNotAllowed());
	}

	@Test
	public void getBrowserNoDate() throws Exception {
		String json = "{\"country_codes\":[\"CH\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isBadRequest());
	}

	@Test
	public void getBrowserNoCountry() throws Exception {
		String json = "{\"date\":\"2017-09-01\"}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isBadRequest());
	}

	@Test
	public void getBrowserWrongDate() throws Exception {
		String json = "{\"date\":\"2017-\", \"country_codes\":[\"CH\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void getBrowserSingleCountryNoRegion() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"country_codes\":[\"CH\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserMultipleCountryNoRegion() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"country_codes\":[\"CH\",\"GB\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserMultipleCountryWrongCountry() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"country_codes\":[\"ZZ\",\"GB\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}


	@Test
	public void getBrowserSingleRegionNoCountry() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"regions\":[\"EU\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserMultipleRegionNoCountry() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"regions\":[\"EU\",\"NA\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserMultipleRegionWrongRegionNoCountry() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"regions\":[\"ZZ\",\"NA\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isUnprocessableEntity());
	}

	@Test
	public void getBrowserMultipleRegionNoRegionDataNoCountry() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"regions\":[\"EU\",\"AN\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserSingleCountrySingleRegion() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"regions\":[\"EU\"], \"country_codes\":[\"US\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

	@Test
	public void getBrowserMultipleCountrySingleRegion() throws Exception {
		String json = "{\"date\":\"2017-09-01\", \"regions\":[\"EU\"], \"country_codes\":[\"US\",\"JP\"]}";
		this.mockMvc.perform(post(browserUrl)
			.contentType(MediaType.APPLICATION_JSON_UTF8)
			.content(json))
			.andExpect(status().isOk());
	}

}
