package com.qualitytaskforce.insightportal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class DatabaseUpdateArticleTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
		
	@Test	
	public void testCase() throws Exception {	
		
		this.mockMvc.perform(get("/article/edit-article"))
				.andExpect(status().isOk()).andReturn();		
		
		
		this.mockMvc.perform(post("/article/edit-article")
            .param("articleUUID", "434a8537-a187-4b22-b43f-c5da574786c9")
            .param("articleTitle", "New chrome 50")
            .param("articleSefURL", "sef-parsed")
            .param("articleSummaryText", "summ-parsed")
            .param("articleUpdatedAt", "2017-02-10")
            .param("articleFullText", "full-parsed")
            .param("testRecommendation", "test-recomend-parsed")
            .param("impactRatingName", "5")
            .param("categoryName", "category-parsed")
            .param("update","update"))
			.andExpect(redirectedUrl("/page-one"));
}	
		
}

