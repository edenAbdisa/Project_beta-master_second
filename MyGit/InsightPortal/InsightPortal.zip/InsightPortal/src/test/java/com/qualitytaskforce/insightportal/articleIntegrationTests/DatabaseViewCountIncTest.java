package com.qualitytaskforce.insightportal.articleIntegrationTests;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.stereotype.Component;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
@Component
public class DatabaseViewCountIncTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	@Test
	public void testCase() throws Exception {	
			
		/**
		 * Check if view counter(of selected article) is incremented 
		 */
		this.mockMvc.perform(put("/article/count-article/{uuid}","434a8537-a187-4b22-b43f-c5da574786c9"))				
				.andExpect(status().isOk()).andReturn();
		
		this.mockMvc.perform(put("/article/count-article/{uuid}","434a8537-a187-4b22-b43f-c5da574786c9321"))				
		.andExpect(status().isUnprocessableEntity()).andReturn();
	}	
}

