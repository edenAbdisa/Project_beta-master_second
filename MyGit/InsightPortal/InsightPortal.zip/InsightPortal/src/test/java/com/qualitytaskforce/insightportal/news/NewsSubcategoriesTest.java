package com.qualitytaskforce.insightportal.news;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NewsSubcategoriesTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	@Test
	public void testAllNewsSubcategoriesResponse200() throws Exception{
		// http://localhost:88/article/get-subcategories?category=All+News
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "All News"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testOSNewsSubcategoriesResponse200() throws Exception{
		// http://localhost:88/article/get-subcategories?category=OS+News
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "OS News"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testMobileNewsSubcategoriesResponse200() throws Exception{
		// http://localhost:88/article/get-subcategories?category=Mobile+News
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "Mobile News"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testBrowserNewsSubcategoriesResponse200() throws Exception{
		// http://localhost:88/article/get-subcategories?category=Browser+News
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "Browser News"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testSoftwareNewsSubcategoriesResponse200() throws Exception{
		// http://localhost:88/article/get-subcategories?category=Software+News
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "Software News"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testRumoursAndTrendsSubcategoriesResponse204() throws Exception{
		// http://localhost:88/article/get-subcategories?category=Rumours+&+Trends
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "Rumours & Trends"))
					.andExpect(status().is(204))
					.andReturn();
	}
	
	@Test
	public void testWrongCategoryResponse404() throws Exception{
		// http://localhost:88/article/get-subcategories?category=All+Newss
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", "All Newss"))
					.andExpect(status().is(404))
					.andReturn();
	}
	
	@Test
	public void testNoCategoryAsParamResponse500() throws Exception{
		// http://localhost:88/article/get-subcategories?category=
		this.mockMvc.perform(get("/article/get-subcategories")
					.param("category", ""))
					.andExpect(status().is(500))
					.andReturn();
	}
	
}
