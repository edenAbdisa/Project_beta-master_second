package com.qualitytaskforce.insightportal;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.isA;
import static org.hamcrest.Matchers.nullValue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.qualitytaskforce.insightportal.config.WebConfig;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.post.JsonReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.util.ReleaseAdvisorFilterCriteria;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.ReleaseAdvisorService;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
@Import(WebConfig.class)
public class ReleaseAdvisorTest {

	@Autowired
	WebApplicationContext wac;

	@Autowired
	MockHttpSession session;

	@Autowired
	MockHttpServletRequest request;

	@MockBean
	private ReleaseAdvisorService raService;
	
	@MockBean
	private ArticleService articleService;

	private MockMvc mockMvc;

	private DateFormat df;
	private List<ReleaseAdvisor> raList;
	private ReleaseAdvisor ra;
	private ReleaseAdvisor ra2;

	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
		df = new SimpleDateFormat("yyyy-MM-dd");

		raList = new ArrayList<>();
		ra = new ReleaseAdvisor();
		ra2 = new ReleaseAdvisor();

		/*
		 * RA event with no article specified
		 */

		ra.setArticle(null);
		ra.setCategory("firefox-beta");
		ra.setEndDate(java.sql.Date.valueOf("2017-08-01"));
		ra.setStartDate(java.sql.Date.valueOf("2017-08-12"));
		ra.setPublished(true);
		ra.setSubtitle("Beta");
		ra.setTitle("Firefox 60");
		ra.setUuid(UUID.fromString("9a7e5702-8614-4c96-938a-fcf704ba99cc"));

		/*
		 * RA event with an article
		 */

		Article article = new Article();
		article.setUuid(UUID.fromString("4d001de5-60ab-4163-bc80-e3d31b5fd131"));

		ra2.setArticle(article);
		ra2.setCategory("chrome");
		ra2.setEndDate(java.sql.Date.valueOf("2017-08-01"));
		ra2.setStartDate(java.sql.Date.valueOf("2017-08-12"));
		ra2.setPublished(true);
		ra2.setSubtitle("Release");
		ra2.setTitle("Chrome 60");
		ra2.setUuid(UUID.fromString("bcf54186-62df-4010-b2d0-6ec54532fe42"));
	}

	@Test
	public void shouldReturnOKOnFindAll() throws Exception {

		raList.add(ra);
		raList.add(ra2);

		Mockito.when(raService.findAll()).thenReturn(raList);
		this.mockMvc.perform(get("/releaseadvisor").header("Origin", "").accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))

				.andExpect(jsonPath("$", hasSize(2)))

				.andExpect(jsonPath("$[0].article_id", nullValue()))
				.andExpect(jsonPath("$[0].category", is(ra.getCategory())))
				.andExpect(jsonPath("$[0].end_date", is(df.format(ra.getEndDate()))))
				.andExpect(jsonPath("$[0].start_date", is(df.format(ra.getStartDate()))))
				.andExpect(jsonPath("$[0].published", is(ra.isPublished())))
				.andExpect(jsonPath("$[0].title", is(ra.getTitle())))
				.andExpect(jsonPath("$[0].uuid", is(ra.getUuid().toString())))

				.andExpect(jsonPath("$[1].article_id", is(ra2.getArticle().getUuid().toString())))
				.andExpect(jsonPath("$[1].category", is(ra2.getCategory())))
				.andExpect(jsonPath("$[1].end_date", is(df.format(ra2.getEndDate()))))
				.andExpect(jsonPath("$[1].start_date", is(df.format(ra2.getStartDate()))))
				.andExpect(jsonPath("$[1].published", is(ra2.isPublished())))
				.andExpect(jsonPath("$[1].title", is(ra2.getTitle())))
				.andExpect(jsonPath("$[1].uuid", is(ra2.getUuid().toString())));
	}
	
	@Test
	public void shouldReturnOk_For_getFilteredEvents() throws Exception {
		
		raList.add(ra2);

		Mockito.when(raService.findMatchingCriteria(Mockito.any(ReleaseAdvisorFilterCriteria.class))).thenReturn(raList);
		this.mockMvc.perform(get("/releaseadvisor?category=chrome").header("Origin", "").accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))

				.andExpect(jsonPath("$", hasSize(1)))

				.andExpect(jsonPath("$[0].article_id", is(ra2.getArticle().getUuid().toString())))
				.andExpect(jsonPath("$[0].category", is(ra2.getCategory())))
				.andExpect(jsonPath("$[0].end_date", is(df.format(ra2.getEndDate()))))
				.andExpect(jsonPath("$[0].start_date", is(df.format(ra2.getStartDate()))))
				.andExpect(jsonPath("$[0].published", is(ra2.isPublished())))
				.andExpect(jsonPath("$[0].title", is(ra2.getTitle())))
				.andExpect(jsonPath("$[0].uuid", is(ra2.getUuid().toString())));
	}
	

	@Test
	public void shouldReturnOk_For_getByUuid() throws Exception {
		Mockito.when(raService.findByUUIDString(Mockito.anyString())).thenReturn(ra);
		this.mockMvc
				.perform(get("/releaseadvisor/{uuid}", ra.getUuid().toString()).header("Origin", "")
						.accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.article_id", nullValue()))
				.andExpect(jsonPath("$.category", is(ra.getCategory())))
				.andExpect(jsonPath("$.end_date", is(df.format(ra.getEndDate()))))
				.andExpect(jsonPath("$.start_date", is(df.format(ra.getStartDate()))))
				.andExpect(jsonPath("$.published", is(ra.isPublished())))
				.andExpect(jsonPath("$.title", is(ra.getTitle())))
				.andExpect(jsonPath("$.uuid", is(ra.getUuid().toString())));
	}

	@Test
	public void shouldReturnErrorMessageWhenDeletingNonExistingEvent() throws Exception {
		Mockito.doThrow(EmptyResultDataAccessException.class).when(raService).deleteByUUIDString(Mockito.anyString());
		String uuid = "bcf54186-62df-4010-b2d0-6ec54532fe42";
		this.mockMvc
				.perform(delete("/releaseadvisor/" + uuid).header("Origin", "").accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isNotFound())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.timestamp", isA(java.lang.Long.class))).andExpect(jsonPath("$.status", is(404)))
				.andExpect(jsonPath("$.error", is("Not Found")))
				.andExpect(jsonPath("$.message", is("The entity of the provided uuid does not exist.")));
	}
	
	@Test
	public void shouldReturnOkWhenCreatingAnEvent() throws Exception {
		
		JsonReleaseAdvisor jsonReleaseAdvisor = new JsonReleaseAdvisor();
		Mockito.when(raService.create(Mockito.any(JsonReleaseAdvisor.class))).thenReturn(ra);
		
		this.mockMvc
		.perform(post("/releaseadvisor/").header("Origin", "")
				.accept(MediaType.APPLICATION_JSON_UTF8).contentType(MediaType.APPLICATION_JSON_UTF8)
				.content(new ObjectMapper().writeValueAsString(jsonReleaseAdvisor)))
		.andDo(print())
		
		.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))

		.andExpect(jsonPath("$.article_id", nullValue()))
		.andExpect(jsonPath("$.category", is(ra.getCategory())))
		.andExpect(jsonPath("$.end_date", is(df.format(ra.getEndDate()))))
		.andExpect(jsonPath("$.start_date", is(df.format(ra.getStartDate()))))
		.andExpect(jsonPath("$.published", is(ra.isPublished())))
		.andExpect(jsonPath("$.title", is(ra.getTitle())))
		.andExpect(jsonPath("$.uuid", is(ra.getUuid().toString())));
		
	}

	@Test
	public void shouldReturnOkFindAllForEmptyListOfEvents() throws Exception {
		Mockito.when(raService.findAll()).thenReturn(raList);
		this.mockMvc.perform(get("/releaseadvisor").header("Origin", "").accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8)).andExpect(jsonPath("$", hasSize(0)));
	}
	
	@Test
	public void shouldReturnErrorMessageWhenReleasAdvisorNotExist_For_getByUUID() throws Exception {
		Mockito.when(raService.findByUUIDString(Mockito.anyString())).thenReturn(null);
		String uuid = "bcf54186-62df-4010-b2d0-6ec54532fe42";
		this.mockMvc
				.perform(get("/releaseadvisor/" + uuid).header("Origin", "").accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isNotFound())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.timestamp", isA(java.lang.Long.class))).andExpect(jsonPath("$.status", is(404)))
				.andExpect(jsonPath("$.error", is("Not Found")))
				.andExpect(jsonPath("$.message", is("ReleaseAdvisor even of the specified UUID does not exist.")));
	}

	@Test
	public void shouldReturnNoContentForSuccesfullDelete() throws Exception {
		Mockito.doNothing().when(raService).deleteByUUIDString(Mockito.anyString());
		String uuid = "bcf54186-62df-4010-b2d0-6ec54532fe42";
		this.mockMvc
				.perform(delete("/releaseadvisor/" + uuid).header("Origin", "").accept(MediaType.APPLICATION_JSON_UTF8))
				.andDo(print()).andExpect(status().isNoContent());
	}

	@Test
	public void shouldReturnOK_PUT_FOR_updateEvent() throws Exception {
		JsonReleaseAdvisor jsonReleaseAdvisor = new JsonReleaseAdvisor();

		Mockito.when(raService.update(Mockito.anyString(), Mockito.any())).thenReturn(true);
		String uuid = "bcf54186-62df-4010-b2d0-6ec54532fe42";
		this.mockMvc
				.perform(put("/releaseadvisor/{uuid}", uuid).header("Origin", "")
						.accept(MediaType.APPLICATION_JSON_UTF8).contentType(MediaType.APPLICATION_JSON_UTF8)
						.content(new ObjectMapper().writeValueAsString(jsonReleaseAdvisor)))
				.andDo(print()).andExpect(status().isNoContent());
	}

	@Test
	public void shouldReturnErrorMessagePUTEventWhenReferencedArticleDoesNotExist_FOR_updateEvent() throws Exception {
		JsonReleaseAdvisor jsonReleaseAdvisor = new JsonReleaseAdvisor();
		Mockito.when(raService.update(Mockito.anyString(), Mockito.any())).thenReturn(false);
		String uuid = "bcf54186-62df-4010-b2d0-6ec54532fe42";
		this.mockMvc
				.perform(put("/releaseadvisor/{uuid}", uuid).header("Origin", "")
						.accept(MediaType.APPLICATION_JSON_UTF8).contentType(MediaType.APPLICATION_JSON_UTF8)
						.content(new ObjectMapper().writeValueAsString(jsonReleaseAdvisor)))
				.andDo(print()).andExpect(status().isNotFound())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON_UTF8))
				.andExpect(jsonPath("$.timestamp", isA(java.lang.Long.class))).andExpect(jsonPath("$.status", is(404)))
				.andExpect(jsonPath("$.error", is("Not Found"))).andExpect(jsonPath("$.message",
						is("Could not create the event: article with provided UUID does not exist.")));
	}
}
