package com.qualitytaskforce.insightportal.news;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringRunner.class)
@SpringBootTest
public class NewsListTest {
	
	@Autowired 
	WebApplicationContext wac;

	@Autowired 
	MockHttpSession session;

	@Autowired 
	MockHttpServletRequest request;

	private MockMvc mockMvc;
	
	@Before
	public void setup() {
		this.mockMvc = MockMvcBuilders.webAppContextSetup(this.wac).build();
	}
	
	@Test
	public void testAllNewsResponse200() throws Exception{
		// http://localhost:88/filter/get-articles?category=All%20News&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "All%20News")
					.param("part", "1"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testOSNewsResponse200() throws Exception{
		// http://localhost:88/filter/get-articles?category=OS%20News&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "OS%20News")
					.param("part", "1"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testMobileNewsResponse200() throws Exception{
		// http://localhost:88/filter/get-articles?category=OS%20News&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "Mobile%20News")
					.param("part", "1"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testBrowserNewsResponse200() throws Exception{
		// http://localhost:88/filter/get-articles?category=Browser%20News&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "Browser%20News")
					.param("part", "1"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testSoftwareNewsResponse200() throws Exception{
		// http://localhost:88/filter/get-articles?category=Software%20News&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "Software%20News")
					.param("part", "1"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testRumoursAndTrendsResponse200() throws Exception{
		// http://localhost:88/filter/get-articles?category=Rumours%20&%20Trends&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "Rumours%20&%20Trends")
					.param("part", "1"))
					.andExpect(status().is(200))
					.andReturn();
	}
	
	@Test
	public void testWrongNewsCategoryResponse404() throws Exception{
		// http://localhost:88/filter/get-articles?category=All%20Newss&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "All%20Newss")
					.param("part", "1"))
					.andExpect(status().is(404))
					.andReturn();
	}
	
	@Test
	public void testPartLess1Response500() throws Exception{
		// http://localhost:88/filter/get-articles?category=All%20News&part=0
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "All%20News")
					.param("part", "0"))
					.andExpect(status().is(500))
					.andReturn();
	}
	
	@Test
	public void testNoCategoryAsParamResponse500() throws Exception{
		// http://localhost:88/filter/get-articles?category=&part=1
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "")
					.param("part", "1"))
					.andExpect(status().is(500))
					.andReturn();
	}
	
	@Test
	public void testNoPartAsParamResponse500() throws Exception{
		// http://localhost:88/filter/get-articles?category=All%20News&part=
		this.mockMvc.perform(get("/filter/get-articles")
					.param("category", "All%20News")
					.param("part", ""))
					.andExpect(status().is(500))
					.andReturn();
	}
}
