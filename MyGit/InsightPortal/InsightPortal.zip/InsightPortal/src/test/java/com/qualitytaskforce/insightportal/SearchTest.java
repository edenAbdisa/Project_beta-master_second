package com.qualitytaskforce.insightportal;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.qualitytaskforce.insightportal.controller.SearchControllerLight;
import com.qualitytaskforce.insightportal.service.ArticleService;

public class SearchTest {
	
	@InjectMocks
	private SearchControllerLight searchControllerLight;
	private MockMvc mockMvc;
	
	@Mock
	ArticleService articlesServiceMock;
	
	@Before
	public void setup(){
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders.standaloneSetup(searchControllerLight).build();		
	}		
	
	@Test
	public void testCorrectQueryResponse() throws Exception {
		 mockMvc.perform(get("/search?query=fire"))
		  		.andExpect(status().isOk());	
	}
}
