package com.qualitytaskforce.insightportal;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

import com.qualitytaskforce.insightportal.model.util.EmailValidator;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmailValidatorTest {

	private EmailValidator ev;

	// These emails should be valid
	private String validEmail1 = "mark@127.0.0.1";
	private String validEmail2 = "dclo@us.ibm.com";
	private String validEmail3 = "abc\\@def@example.com";
	private String validEmail4 = "abc\\\\@example.com";
	private String validEmail5 = "Fred\\ Bloggs@example.com";
	private String validEmail6 = "Joe.\\\\Blow@example.com";
	private String validEmail7 = "\"Abc@def\"@example.com";
	private String validEmail8 = "\"Fred Bloggs\"@example.com";
	private String validEmail9 = "customer/department=shipping@example.com";
	private String validEmail10 = "$A12345@example.com";
	private String validEmail11 = "!def!xyz%abc@example.com";
	private String validEmail12 = "_mark@example.com";
	private String validEmail13 = "mark+mailbox@example.com";
	private String validEmail14 = "mark.greenbank@example.com";
	private String validEmail15 = "Mark\\ \\\"Ace\\\"\\ Lovell@example.com";
	private String validEmail16 = "\"Mark \\\"Ace\\\" L.\"@example.com";

	// These emails should be invalid
	private String invalidEmail1 = "abc@def@example.com";
	private String invalidEmail2 = "abc\\\\@def@example.com";
	private String invalidEmail3 = "abc\\@example.com";
	private String invalidEmail4 = "@example.com";
	private String invalidEmail5 = "mark@";
	private String invalidEmail6 = "\"qu@example.com";
	private String invalidEmail7 = "ote\"@example.com";
	private String invalidEmail8 = ".dot@example.com";
	private String invalidEmail9 = "dot.@example.com";
	private String invalidEmail10 = "two..dot@example.com";
	private String invalidEmail11 = "\"Mark \"Ace\" L.\"@example.com";
	private String invalidEmail12 = "Mark\\ \\\"Ace\\\"\\ L\\.@example.com";
	private String invalidEmail13 = "hello world@example.com";
	private String invalidEmail14 = "mark@g.re.en.b.a.n.k.";

	@Test
	public void testValidEmail1() {
		ev = new EmailValidator(validEmail1);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail2() {
		ev = new EmailValidator(validEmail2);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail3() {
		ev = new EmailValidator(validEmail3);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail4() {
		ev = new EmailValidator(validEmail4);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail5() {
		ev = new EmailValidator(validEmail5);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail6() {
		ev = new EmailValidator(validEmail6);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail7() {
		ev = new EmailValidator(validEmail7);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail8() {
		ev = new EmailValidator(validEmail8);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail9() {
		ev = new EmailValidator(validEmail9);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail10() {
		ev = new EmailValidator(validEmail10);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail11() {
		ev = new EmailValidator(validEmail11);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail12() {
		ev = new EmailValidator(validEmail12);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail13() {
		ev = new EmailValidator(validEmail13);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail14() {
		ev = new EmailValidator(validEmail14);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail15() {
		ev = new EmailValidator(validEmail15);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	@Test
	public void testValidEmail16() {
		ev = new EmailValidator(validEmail16);
		assertThat(ev.validateEmail()).isEqualTo(true);
	}

	// Begin Invalid email tests
	@Test
	public void testInvalidEmail1() {
		ev = new EmailValidator(invalidEmail1);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail2() {
		ev = new EmailValidator(invalidEmail2);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail3() {
		ev = new EmailValidator(invalidEmail3);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail4() {
		ev = new EmailValidator(invalidEmail4);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail5() {
		ev = new EmailValidator(invalidEmail5);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail6() {
		ev = new EmailValidator(invalidEmail6);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail7() {
		ev = new EmailValidator(invalidEmail7);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail8() {
		ev = new EmailValidator(invalidEmail8);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail9() {
		ev = new EmailValidator(invalidEmail9);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail10() {
		ev = new EmailValidator(invalidEmail10);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail11() {
		ev = new EmailValidator(invalidEmail11);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail12() {
		ev = new EmailValidator(invalidEmail12);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}

	@Test
	public void testInvalidEmail13() {
		ev = new EmailValidator(invalidEmail13);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}


	@Test
	public void testInvalidEmail14() {
		ev = new EmailValidator(invalidEmail14);
		assertThat(ev.validateEmail()).isEqualTo(false);
	}
}