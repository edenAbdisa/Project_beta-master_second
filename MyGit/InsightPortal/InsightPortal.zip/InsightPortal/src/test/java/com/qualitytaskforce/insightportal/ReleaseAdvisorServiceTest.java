package com.qualitytaskforce.insightportal;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.qualitytaskforce.insightportal.error.SaveEntityException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.post.JsonReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.util.ReleaseAdvisorFilterCriteria;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.repository.ReleaseAdvisorRepository;
import com.qualitytaskforce.insightportal.service.ReleaseAdvisorService;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest

public class ReleaseAdvisorServiceTest {
	@Autowired
	ReleaseAdvisorService service;

	@MockBean
	ReleaseAdvisorRepository repo;

	@MockBean
	ArticleRepository repoArticle;

	private String uuidStr;
	private String fakeUuidStr;
	private UUID uuid;
	private UUID fakeUuid;
	private JsonReleaseAdvisor jra;

	@Before
	public void before() {

		uuidStr = "13737543-1b93-4f75-a0a1-6a945d1238eb";
		fakeUuidStr = "13737543-1b93-4f76-a0a1-6a945d1238eb";
		uuid = UUID.fromString(uuidStr);
		fakeUuid = UUID.fromString(fakeUuidStr);

		jra = new JsonReleaseAdvisor();

		jra.setCategory("firefox-beta");
		jra.setEndDate(java.sql.Date.valueOf("2017-08-01"));
		jra.setStartDate(java.sql.Date.valueOf("2017-08-12"));
		jra.setPublished(true);
		jra.setSubtitle("Beta");
		jra.setTitle("Firefox 60");

	}

	@Test
	public void shouldReleaseAdvisorIfExists() {
		ReleaseAdvisor raReturned = new ReleaseAdvisor();
		raReturned.setUuid(uuid);
		when(repo.findByUuid(Mockito.any(UUID.class))).thenReturn(raReturned);
		ReleaseAdvisor expectedRA = service.findByUUIDString(uuidStr);

		Assert.assertThat(expectedRA, is(equalTo(raReturned)));

		verify(repo).findByUuid(uuid);
	}

	@Test
	public void returnAllReleaseAdvisorEvents() {
		List<ReleaseAdvisor> raList = new ArrayList<>();
		when(repo.findAll()).thenReturn(raList);

		service.findAll();

		verify(repo).findAll();

	}

	@Test(expected = SaveEntityException.class)
	public void throwExceptionWhenNoArticleUUIDWasSpecifiedWhenCreating() throws SaveEntityException {
		when(repoArticle.findByUuid(Mockito.any(UUID.class))).thenReturn(null);

		jra.setArticleUuid(fakeUuid);
		service.create(jra);
		verify(repoArticle).findByUuid(Mockito.any(UUID.class));
	}

	@Test
	public void saveEventWithSpecifiedArticleUUID() throws SaveEntityException {

		when(repo.save(Mockito.any(ReleaseAdvisor.class))).thenReturn(null);
		when(repoArticle.findByUuid(Mockito.any(UUID.class))).thenReturn(new Article());

		jra.setArticleUuid(uuid);
		ReleaseAdvisor ra = service.create(jra);
		verify(repo).save(ra);
	}

	@Test
	public void saveEventWithNoArticleSpecified() throws SaveEntityException {

		when(repo.save(Mockito.any(ReleaseAdvisor.class))).thenReturn(null);
		when(repoArticle.findByUuid(Mockito.any(UUID.class))).thenReturn(new Article());

		jra.setArticleUuid(null);
		ReleaseAdvisor ra = service.create(jra);
		verify(repo).save(ra);
	}

	@Test
	public void deleteExistingEventByUUIDString() {

		ReleaseAdvisor ra = new ReleaseAdvisor(jra);
		service.deleteByUUIDString(uuidStr);
		verify(repo).delete(UUID.fromString(uuidStr));
	}

	@Test
	public void updatingEventWithAnArticleChangesItsState() throws SaveEntityException {

		jra.setTitle("New title");
		jra.setArticleUuid(null);

		ReleaseAdvisor RaFromDB = new ReleaseAdvisor(jra);

		when(repo.findByUuid(Mockito.any(UUID.class))).thenReturn(RaFromDB);
		when(repoArticle.findByUuid(Mockito.any(UUID.class))).thenReturn(new Article());
		when(repo.save(Mockito.any(ReleaseAdvisor.class))).thenReturn(null);

		jra.setTitle("New test title 1");
		service.update(uuidStr, jra);
		jra.setTitle("New test title 2");
		service.update(uuidStr, jra);

		verify(repo, times(2)).save(Mockito.any(ReleaseAdvisor.class));
	}

	@Test
	public void updatingEventWithNoArticleSpecified() throws SaveEntityException {
		when(repoArticle.findByUuid(Mockito.any(UUID.class))).thenReturn(new Article());

		jra.setArticleUuid(fakeUuid);
		service.update(uuidStr, jra);

		verify(repo).save(Mockito.any(ReleaseAdvisor.class));
	}

	@Test(expected = SaveEntityException.class)
	public void throwExceptionWhenNoArticleUUIDWasSpecifiedWhenUpdating() throws SaveEntityException {
		when(repoArticle.findByUuid(Mockito.any(UUID.class))).thenReturn(null);

		jra.setArticleUuid(fakeUuid);
		service.update(uuidStr, jra);
		verify(repoArticle).findByUuid(Mockito.any(UUID.class));
	}
	
	@Test
	public void filterEventsBySingleCriterion() {
		
		Map<String, String> requestParams = new HashMap<>();
		requestParams.put("title", "testTitle");	
		ReleaseAdvisorFilterCriteria criteria = new ReleaseAdvisorFilterCriteria(requestParams);
		when(repo.findMatchingCriteria(criteria)).thenReturn(new ArrayList<ReleaseAdvisor>());
		
		service.findMatchingCriteria(criteria);
		
		verify(repo).findMatchingCriteria(criteria);
	}
	
}
