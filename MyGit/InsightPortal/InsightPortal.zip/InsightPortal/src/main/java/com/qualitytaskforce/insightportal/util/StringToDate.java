package com.qualitytaskforce.insightportal.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class StringToDate {
	
public static Date strToDate(String str){
		
		Date date = null;
		
	    DateFormat dateformat = new SimpleDateFormat("dd-MM-yyyy");
	    
    	try{   
    		
    		date = dateformat.parse(str); 
    		
	    }catch (Exception e ){	
	    	
	    }
	     
	    return date;	
 	}
}
