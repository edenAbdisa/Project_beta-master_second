package com.qualitytaskforce.insightportal.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ArticleUpdate;
import com.qualitytaskforce.insightportal.repository.ArticleUpdateRepository;

@Service
public class ArticleUpdateService {

	@Autowired
	ArticleUpdateRepository articleUpdateRepository;

	public void save(ArticleUpdate articleUpdate) {
		articleUpdateRepository.save(articleUpdate);		
	}
	
	public void delete(ArticleUpdate articleUpdate) {
		articleUpdateRepository.delete(articleUpdate);	
	}
	
	public List<ArticleUpdate> findAllByArticle(Article article) {
		return articleUpdateRepository.findByArticles(article);		
	}
	
	public ArticleUpdate findByUuid (UUID uuid) {
		return articleUpdateRepository.findByUuid(uuid);
	}
	
	public boolean deleteBatch(UUID uuid) {
		ArticleUpdate articleUpdate = articleUpdateRepository.findByUuid(uuid);
		if (articleUpdate != null) {
			articleUpdateRepository.delete(uuid);
			return true;
		} else {
			return false;
		}
	}
	
}
