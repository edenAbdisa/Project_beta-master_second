package com.qualitytaskforce.insightportal.model.users;

import java.util.Date;
import java.util.UUID;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "user_logging")
public class UserLogging implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private User user;
	
	@Column(name = "action", nullable = false, length = 45)
	private String action;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "action_time", nullable = false, length = 19)
	private Date actionTime;
	
	@Column(name = "ip_address", nullable = false)
	private byte[] ipAddress;

	public UserLogging() {
	}

	public UserLogging(UUID uuid, User user, String action, Date actionTime, byte[] ipAddress) {
		this.uuid = uuid;
		this.user = user;
		this.action = action;
		this.actionTime = actionTime;
		this.ipAddress = ipAddress;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAction() {
		return this.action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Date getActionTime() {
		return this.actionTime;
	}

	public void setActionTime(Date actionTime) {
		this.actionTime = actionTime;
	}

	public byte[] getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(byte[] ipAddress) {
		this.ipAddress = ipAddress;
	}

	@Override
	public String toString() {
		return "UserLogging{" +
				"user=" + user.getEmail() +
				", action='" + action + '\'' +
				", actionTime=" + actionTime +
				", ipAddress=" + new String(ipAddress) +
				'}';
	}
}
