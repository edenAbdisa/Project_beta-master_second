package com.qualitytaskforce.insightportal.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.qualitytaskforce.insightportal.model.testadvisor.MobileBrowser;

public interface CloudAdvisorMobileRepository extends JpaRepository<MobileBrowser, Long> {
		
	@Query(value = "SELECT "
			+ "concat(ta_oss.name, ' ', ta_oss.version) "
			+ "FROM ta_oss"
			, nativeQuery = true)
	List<String> findMobileOSs();
	
	@Query(value = "SELECT "
			+ "concat(ta_browsers.name, ' ', ta_browsers.version) "
			+ "FROM ta_ms_mobile_browsers "			
			+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_mobile_browsers.browseruuid"
			, nativeQuery = true)
	List<String> findMobileBrowsers();
}