package com.qualitytaskforce.insightportal.repository.users;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.users.ApiLimit;

public interface ApiLimitRepository extends JpaRepository<ApiLimit, Long> {

	List<ApiLimit> findByName(String name);


}