package com.qualitytaskforce.insightportal.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "subscriptions")
public class Subscription implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", nullable = false)
	private User user;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_level_id", nullable = false)
	private UserLevel userLevel;
	
	@Column(name = "organisation")	
	private String organisation;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "zip")
	private String zip;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "phone", length = 20)
	private String phone;
	
	@Column(name = "fax", length = 20)
	private String fax;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false, length = 19)
	private Date createdAt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "payment_date", length = 19)
	private Date paymentDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_date", length = 19)
	private Date startDate;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "end_date", length = 19)
	private Date endDate;
	
	@Column(name = "base_amount", length = 20)
	private String baseAmount;
	
	@Column(name = "tax_amount", length = 20)
	private String taxAmount;
	
	@Column(name = "discount_amount", length = 20)
	private String discountAmount;
	
	@Column(name = "gross_amount", length = 20)
	private String grossAmount;
	
	@Column(name = "payment_method", length = 20)
	private String paymentMethod;
	
	@Column(name = "transaction_id", length = 100)
	private String transactionId;
	
	@Column(name = "recurring", nullable = false)
	private boolean recurring;

	public Subscription() {
	}

	public Subscription(UUID uuid, UserLevel userLevel, User user, Date createdAt, boolean recurring) {
		this.uuid = uuid;
		this.userLevel = userLevel;
		this.user = user;
		this.createdAt = createdAt;
		this.recurring = recurring;
	}

	public Subscription(UUID uuid, UserLevel userLevel, User user, String organisation, String address,
			String city, String state, String zip, String country, String phone, String fax, Date createdAt,
			Date paymentDate, Date startDate, Date endDate, String baseAmount, String taxAmount, String discountAmount,
			String grossAmount, String paymentMethod, String transactionId, boolean recurring) {
		this.uuid = uuid;
		this.userLevel = userLevel;
		this.user = user;
		this.organisation = organisation;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.country = country;
		this.phone = phone;
		this.fax = fax;
		this.createdAt = createdAt;
		this.paymentDate = paymentDate;
		this.startDate = startDate;
		this.endDate = endDate;
		this.baseAmount = baseAmount;
		this.taxAmount = taxAmount;
		this.discountAmount = discountAmount;
		this.grossAmount = grossAmount;
		this.paymentMethod = paymentMethod;
		this.transactionId = transactionId;
		this.recurring = recurring;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public UserLevel getUserLevel() {
		return this.userLevel;
	}

	public void setUserLevel(UserLevel userLevel) {
		this.userLevel = userLevel;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getOrganisation() {
		return this.organisation;
	}

	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return this.zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getPaymentDate() {
		return this.paymentDate;
	}

	public void setPaymentDate(Date paymentDate) {
		this.paymentDate = paymentDate;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getBaseAmount() {
		return this.baseAmount;
	}

	public void setBaseAmount(String baseAmount) {
		this.baseAmount = baseAmount;
	}

	public String getTaxAmount() {
		return this.taxAmount;
	}

	public void setTaxAmount(String taxAmount) {
		this.taxAmount = taxAmount;
	}

	public String getDiscountAmount() {
		return this.discountAmount;
	}

	public void setDiscountAmount(String discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getGrossAmount() {
		return this.grossAmount;
	}

	public void setGrossAmount(String grossAmount) {
		this.grossAmount = grossAmount;
	}

	public String getPaymentMethod() {
		return this.paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getTransactionId() {
		return this.transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public boolean isRecurring() {
		return this.recurring;
	}

	public void setRecurring(boolean recurring) {
		this.recurring = recurring;
	}
}
