package com.qualitytaskforce.insightportal.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;

import com.qualitytaskforce.insightportal.config.WebConfig;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.DeleteEntityException;
import com.qualitytaskforce.insightportal.error.SaveEntityException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.SefURL;
import com.qualitytaskforce.insightportal.model.post.JsonReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.post.UuidRequest;
import com.qualitytaskforce.insightportal.model.response.*;
import com.qualitytaskforce.insightportal.model.util.ReleaseAdvisorFilterCriteria;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.ReleaseAdvisorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Import(WebConfig.class)
public class ReleaseAdvisorController
{
	private static Logger LOGGER = LoggerFactory.getLogger(ReleaseAdvisorController.class);
	
	@Autowired
	ReleaseAdvisorService releaseAdvisorService;

	@Autowired
	ArticleService articleService;

	@PutMapping(value = "/releaseadvisor/publish")
	public ResponseEntity<?> publish(@RequestBody UuidRequest uuids) {
		List<UUID> uuidsList = uuids.getUuids();
		Iterator<UUID> iterator = uuidsList.iterator();
		while (iterator.hasNext()) {
			releaseAdvisorService.publishToggle(iterator.next(), true);
		}
		String response = "{\"status\":200}";
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	/*****
	 *  Method make an item unpublished
	 * ***/
	@PutMapping(value = "/releaseadvisor/unpublish")
	public ResponseEntity<?> unpublish(@RequestBody UuidRequest uuids) {
		List<UUID> uuidsList = uuids.getUuids();
		Iterator<UUID> iterator = uuidsList.iterator();
		while (iterator.hasNext()) {
			releaseAdvisorService.publishToggle(iterator.next(), false);
		}
		ApiResponse response = new ApiResponse("success", "Article's status has been changed to unpublished");
		return new ResponseEntity<ApiResponse>(response, HttpStatus.OK);
	}

	// delete list of events
	@RequestMapping(value = "/releaseadvisor/bulk-delete", method = RequestMethod.POST)
	public @ResponseBody
	ResponseEntity<?> batchDeleteArticle(@RequestBody UuidRequest uuids) {
		List<UUID> uuidsList = uuids.getUuids();
		Iterator<UUID> iterator = uuidsList.iterator();
		BatchResponse response = new BatchResponse("releaseAdvisor");
		while (iterator.hasNext()) {
			UUID uuidNext = iterator.next();
			boolean isDeleted = releaseAdvisorService.deleteBatch(uuidNext);
			if (!isDeleted) {
				response.push(uuidNext, "failure"); //failure status for non exist article
			} else {
				response.push(uuidNext, "success");
			}
		}

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		return new ResponseEntity<>(response, headers, HttpStatus.OK);
	}

	@GetMapping(value = "/releaseadvisor/{uuid}")
	public ResponseEntity<HashMap<String, Object>> getByUuid(@PathVariable("uuid") String uuidString) throws DataNotFoundException {
		
		ReleaseAdvisor ra = releaseAdvisorService.findByUUIDString(uuidString);
		if (ra == null) {
			throw new DataNotFoundException("ReleaseAdvisor even of the specified UUID does not exist.");
		}
		HashMap<String, Object> map = raToMapUtil(ra);
		return new ResponseEntity<HashMap<String, Object>>(map, HttpStatus.OK);
	}
	
	// 1
	@GetMapping(value = "/releaseadvisor/admin/{uuid}")
	public ResponseEntity<HashMap<String, Object>> getByUuidAdmin(@PathVariable("uuid") String uuidString) throws DataNotFoundException {

		ReleaseAdvisor ra = releaseAdvisorService.findByUUIDString(uuidString);
		if (ra == null) {
			throw new DataNotFoundException("ReleaseAdvisor even of the specified UUID does not exist.");
		}
		HashMap<String, Object> map = raToMapUtil(ra);
		return new ResponseEntity<HashMap<String, Object>>(map, HttpStatus.OK);
	}
	
	// 1
	@GetMapping(value = "/releaseadvisor")
	public ResponseEntity<List<HashMap<String, Object>>> getFilteredEvents(@RequestParam(required=false) HashMap<String, String> requestParams) {
		List<ReleaseAdvisor> listOfEvents;
		
		if (requestParams.isEmpty()) {
			listOfEvents = releaseAdvisorService.findAll();
		} else {
			ReleaseAdvisorFilterCriteria criteria = new ReleaseAdvisorFilterCriteria(requestParams);
			listOfEvents = releaseAdvisorService.findMatchingCriteria(criteria);
		}
		
		List<HashMap<String, Object>> map = raListToMapUtil(listOfEvents);
		return new ResponseEntity<List<HashMap<String, Object>>>(map, HttpStatus.OK);
	}

//	@GetMapping(value = "/releaseadvisor/all")
//	public ResponseEntity<List<HashMap<String, Object>>> getFilteredEventsFromTimeframe(@RequestParam(required=false) HashMap<String, String> requestParams) {
//		List<ReleaseAdvisor> listOfEvents;
//
//		if(requestParams.isEmpty())
//			listOfEvents = releaseAdvisorService.findAll();
//		else {
//			ReleaseAdvisorFilterCriteria criteria = new ReleaseAdvisorFilterCriteria(requestParams);
//			listOfEvents = releaseAdvisorService.findMatchingCriteria(criteria);
//		}
//
//		List<HashMap<String, Object>> map = raListToMapUtil(listOfEvents);
//		return new ResponseEntity<List<HashMap<String, Object>>>(map, HttpStatus.OK);
//	}

	//	//
	@GetMapping(value = "/releaseadvisor/admin")
	public ResponseEntity<List<HashMap<String, Object>>> getFilteredEventsAdmin(
			@RequestParam(required=false) HashMap<String, String> requestParams) {
		List<ReleaseAdvisor> listOfEvents;

		if (requestParams.isEmpty()) {
			listOfEvents = releaseAdvisorService.findAll();
		} else {
			ReleaseAdvisorFilterCriteria criteria = new ReleaseAdvisorFilterCriteria(requestParams);
			listOfEvents = releaseAdvisorService.findMatchingCriteria(criteria);
		}
		
		List<HashMap<String, Object>> map = raListToMapUtil(listOfEvents);
		return new ResponseEntity<List<HashMap<String, Object>>>(map, HttpStatus.OK);
	}

	
	@DeleteMapping(value = "/releaseadvisor/{uuid}")
	public ResponseEntity<Void> deleteEvent(@PathVariable("uuid") String uuidString) throws DeleteEntityException {
		try{
			releaseAdvisorService.deleteByUUIDString(uuidString);
		}catch(EmptyResultDataAccessException e){
			throw new DeleteEntityException("The entity of the provided uuid does not exist.");
		}
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	// 1
	@PostMapping(value = "/releaseadvisor")
	public ResponseEntity<HashMap<String, Object>> createEvent(@RequestBody JsonReleaseAdvisor raReq) throws SaveEntityException {

		LOGGER.info(raReq.toString());
		ReleaseAdvisor createdRa = releaseAdvisorService.create(raReq);
		HashMap<String, Object> map = raToMapUtil(createdRa);
		return new ResponseEntity<HashMap<String, Object>>(map, HttpStatus.CREATED);
	}
	
	@PutMapping(value = "/releaseadvisor/{uuid}")
	public ResponseEntity<Void> updateEvent(@PathVariable("uuid") String uuidString, @RequestBody JsonReleaseAdvisor jra) throws SaveEntityException {

		boolean resorceUpdatedCreatedAndArticleExists = releaseAdvisorService.update(uuidString, jra);
		if (! resorceUpdatedCreatedAndArticleExists) {
			throw new SaveEntityException("Could not create the event: article with provided UUID does not exist.");
		}
		
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	// 2
	@GetMapping(value = "/releaseadvisor/nextarticles/{n}")
	public ResponseEntity<List<HashMap<String, HashMap<?,?>>>> getNextNEventsWithSefUrls(@PathVariable("n") int n) {
		List<ReleaseAdvisorWithSefUrl> eventsWithSefUrls = releaseAdvisorService.getNextEventsWithArticleSefUrls(n);
		
		List<HashMap<String, HashMap<?,?>>> map = raFilterToMapUtil(eventsWithSefUrls);
		return new ResponseEntity<List<HashMap<String, HashMap<?,?>>>>(map, HttpStatus.OK);
	}

	// 1
	@GetMapping(value = "/releaseadvisor/next/{n}")
	public ResponseEntity<List<HashMap<String, Object>>> getNextNEvents(@PathVariable("n") int n) {
		List<ReleaseAdvisor> listOfEvents;
		listOfEvents = releaseAdvisorService.getNextEvents(n);
		List<HashMap<String, Object>> map = raListToMapUtil(listOfEvents);
		return new ResponseEntity<List<HashMap<String, Object>>>(map, HttpStatus.OK);
	}

	// 2
	@GetMapping(value = "/releaseadvisor/sefurls")
	public ResponseEntity<List<HashMap<String, HashMap<?,?>>>> getEventsWithSefUrls() {
		List<ReleaseAdvisorWithSefUrl> eventsWithSefUrls = releaseAdvisorService.getEventsWithArticleSefUrls();
		List<HashMap<String, HashMap<?,?>>> map = raFilterToMapUtil(eventsWithSefUrls);
		return new ResponseEntity<List<HashMap<String, HashMap<?,?>>>>(map, HttpStatus.OK);
	}

	/*** REQUESTED BY TESTPLANT ***/

	@GetMapping(value = "/releaseadvisor/all/{uuid}")
	public ResponseEntity<ReleaseAdvisorWithDetails> getByUuidWithDetails(@PathVariable("uuid") String uuidString) throws DataNotFoundException {

		ReleaseAdvisor event = releaseAdvisorService.findByUUIDString(uuidString);
		ArticleDetails details = null;
		ReleaseAdvisorWithDetails releaseAdvisorWithDetails = null;

		if (event == null) {
			throw new DataNotFoundException("ReleaseAdvisor even of the specified UUID does not exist.");
		} else {
			Article article = event.getArticle();
			if (article != null) {
				details = new ArticleDetails(article);
			}
			releaseAdvisorWithDetails = new ReleaseAdvisorWithDetails(event, details);
		}
		return new ResponseEntity<>(releaseAdvisorWithDetails, HttpStatus.OK);
	}

	@GetMapping(value = "/releaseadvisor/all")
	public ResponseEntity<List<ReleaseAdvisorWithDetails>> getFilteredEventsWithDetails(@RequestParam(required=false) HashMap<String, String> requestParams) {
		List<ReleaseAdvisor> listOfEvents;
		List<ReleaseAdvisorWithDetails> events = new ArrayList<>();

		if (requestParams.isEmpty()) {
			listOfEvents = releaseAdvisorService.findAll();
		} else {
			ReleaseAdvisorFilterCriteria criteria = new ReleaseAdvisorFilterCriteria(requestParams);
			listOfEvents = releaseAdvisorService.findMatchingCriteria(criteria);
		}

		for (ReleaseAdvisor event : listOfEvents) {
			Article article = event.getArticle();
			ArticleDetails details = null;
			if (article != null) {
				details = new ArticleDetails(article);
			}
			events.add(new ReleaseAdvisorWithDetails(event, details));
		}

		return new ResponseEntity<>(events, HttpStatus.OK);
	}

	@GetMapping(value = "/releaseadvisor/all/next/{n}")
	public ResponseEntity<List<ReleaseAdvisorWithDetails>> getNextNEventsWithDetails(@PathVariable("n") int n) {
		List<ReleaseAdvisor> listOfEvents;
		List<ReleaseAdvisorWithDetails> events = new ArrayList<>();

		listOfEvents = releaseAdvisorService.getNextEvents(n);

		for (ReleaseAdvisor event : listOfEvents) {
			Article article = event.getArticle();
			ArticleDetails details = null;
			if (article != null) {
				details = new ArticleDetails(article);
			}
			events.add(new ReleaseAdvisorWithDetails(event, details));
		}

		return new ResponseEntity<>(events, HttpStatus.OK);
	}

	//List of all categories

	@GetMapping(value = "/releaseadvisor/categories")
	public ResponseEntity<?> getCategory() {
		List<Object> categories;
		categories = releaseAdvisorService.getCategories();

		return new ResponseEntity<>(categories, HttpStatus.OK);
	}
	
	
	List<HashMap<String, Object>> raListToMapUtil (List<ReleaseAdvisor> listOfEvents) {
		List<HashMap<String, Object>> raMapList = new ArrayList<HashMap<String, Object>>();
		for (ReleaseAdvisor ra : listOfEvents) {
			
			HashMap<String, Object> raMap = new HashMap<>();
			raMap.put("uuid", ra.getUuid());
			raMap.put("category", ra.getCategory());
			raMap.put("title", ra.getTitle());
			raMap.put("subtitle", ra.getSubtitle());
			raMap.put("published", ra.isPublished());
			raMap.put("start_date", ra.getStartDate().toString());
			raMap.put("end_date", ra.getEndDate().toString());
			Article article = ra.getArticle();
			if (article != null) {
				raMap.put("article_id", article.getUuid().toString());
			} else {
				raMap.put("article_id", null);			
			}
			raMapList.add(raMap);
		}
		return raMapList;
	}
	
	
	HashMap<String, Object> raToMapUtil (ReleaseAdvisor ra) {
		HashMap<String, Object> raMap = new HashMap<String, Object>();
		raMap.put("uuid", ra.getUuid());
		raMap.put("category", ra.getCategory());
		raMap.put("title", ra.getTitle());
		raMap.put("subtitle", ra.getSubtitle());
		raMap.put("published", ra.isPublished());
		raMap.put("start_date", ra.getStartDate().toString());
		raMap.put("end_date", ra.getEndDate().toString());
		Article article = ra.getArticle();
		if (article != null) {
			raMap.put("article_id", article.getUuid().toString());
		} else {
			raMap.put("article_id", null);		
		}
		return raMap;
	}
	
	List<HashMap<String, HashMap<?,?>>> raFilterToMapUtil (List<ReleaseAdvisorWithSefUrl> raWithSefUrlList) {
		
		List<HashMap<String, HashMap<?,?>>> maplist = new ArrayList<HashMap<String, HashMap<?,?>>>();		
		for (ReleaseAdvisorWithSefUrl raWithSefUrl : raWithSefUrlList) {
			
			List<ReleaseAdvisor> raList = new ArrayList<ReleaseAdvisor>();
			raList.add(raWithSefUrl.getReleaseAdvisor());
			HashMap<String, Object> raMap = new HashMap<>();			
			raMap = raToRaMap(raList, raMap);
			
			HashMap<String, HashMap<?,?>> localMap = new HashMap<>();
			localMap.put("releaseAdvisor", raMap);	
			
			SefURL sefurl = raWithSefUrl.getSefUrl();
			if (sefurl == null) {
				localMap.put("sefUrl", null);
			} else if (sefurl != null) {				
				localMap = sefUrlToSefUrlMap(sefurl, localMap);			
			}		
			
			maplist.add(localMap);
		}		
		return maplist;
	}
	
	HashMap<String, Object> raToRaMap (List<ReleaseAdvisor> raList, HashMap<String, Object> raMap) {
		for (ReleaseAdvisor ra : raList) {					
			raMap.put("uuid", ra.getUuid());
			raMap.put("category", ra.getCategory());
			raMap.put("title", ra.getTitle());
			raMap.put("subtitle", ra.getSubtitle());
			raMap.put("published", ra.isPublished());
			raMap.put("start_date", ra.getStartDate().toString());
			raMap.put("end_date", ra.getEndDate().toString());
			Article article = ra.getArticle();
			if (article != null) {
				raMap.put("article_id", article.getUuid().toString());
			} else {
				raMap.put("article_id", null);
			}				
		}		
		return raMap;
	}
	
	
	HashMap<String, HashMap<?,?>> sefUrlToSefUrlMap (SefURL sefurl, HashMap<String, HashMap<?,?>> localMap ) {
		List<SefURL> sefUrlList =  new ArrayList<SefURL>();
		sefUrlList.add(sefurl);
		HashMap<String, Object> sefUrlMap = new HashMap<>();
		for (SefURL sefUrl : sefUrlList) {
			sefUrlMap.put("uuid", sefUrl.getUuid());
			sefUrlMap.put("sefUrl", sefUrl.getSefUrl());
			localMap.put("sefUrl", sefUrlMap);
		}	
		
		return localMap;
	}
}
