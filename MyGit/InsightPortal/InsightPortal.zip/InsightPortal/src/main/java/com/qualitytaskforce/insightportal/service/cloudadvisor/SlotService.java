package com.qualitytaskforce.insightportal.service.cloudadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Slot;
import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid;

import com.qualitytaskforce.insightportal.repository.cloudadvisor.SlotRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.DeviceRepository;


@Service
public class SlotService {

	/** The slot repository. */
	@Autowired
	private SlotRepository slotRepository;
	
	/** The device repository. */
	@Autowired
	private DeviceRepository deviceRepository;
	 
	/**
	 * Saves the slot
	 *
	 * @param slot the slot
	 * @return the slot
	 */
	public Slot save(Slot slot ) {
		return slotRepository.save(slot);
	}
	 
	/**
	 * Saves many slots
	 *
	 * @param slots the slots
	 * @return the list
	 */
	public List<Slot> saveAll(Iterable<Slot> slots){
		return slotRepository.save(slots);	
	}
	
	/**
	 * Find all slots
	 *
	 * @return the list
	 */
	public List<Slot> findAll(){
		return slotRepository.findAll();	
	}
	
	/**
	 * Find slot by a specific cloud advisor
	 *
	 * @param cloudAdvisorUuid the cloud advisor uuid
	 * @return the list
	 */
	public List<Slot> findCloudAdvisor(CloudAdvisor cloudAdvisorUuid){
		return slotRepository.findSlotByCloudAdvisor(cloudAdvisorUuid);
	}
	
	/**
	 * Gets the device 
	 *
	 * @param brand the brand
	 * @param model the model
	 * @return the device
	 */
	public DeviceWithUuid getDevice( String brand,  String model) {
		return deviceRepository.getDevice(brand, model);
	}
	/**
	 * Gets the device 
	 *
	 * @param deviceUuid the Device Uuid
	 * @return the device
	 */
	public DeviceWithUuid getDeviceByUuid( UUID deviceUuid) {
		return deviceRepository.getDeviceByUuid(deviceUuid);
	}

	/**
	 * Find device by uuid.
	 *
	 * @param uuid the uuid
	 * @return the list
	 */
	public List<DeviceWithUuid> findByUuid(DeviceWithUuid  uuid) {
		
		return deviceRepository.findByUuid(uuid.getUuid());
	}

	/**
	 * Find slots by uuid.
	 *
	 * @param slotUuid the slot uuid
	 * @return the slot
	 */
	public Slot findSlotsByUuid(UUID slotUuid ) {
		return slotRepository.findByUuid(slotUuid);
	}
	public Slot findByUuidAndCloudAdvisor(UUID slotUuid,UUID companyUuid ) {
		return slotRepository.findByUuidAndCloudAdvisor(slotUuid,companyUuid);
	}
	public Slot findOne(UUID slotUuid) throws DataNotFoundException {
		Slot slot=slotRepository.findOne(slotUuid);
		if(slot==null) {
			throw new DataNotFoundException("No slot exists with the give slot id.");
		}
		return slot;
	}

	

}
