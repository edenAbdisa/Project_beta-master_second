package com.qualitytaskforce.insightportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.qualitytaskforce.insightportal.model.Team;

public interface TeamRepository extends JpaRepository<Team, Long> {

}