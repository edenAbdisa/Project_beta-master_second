package com.qualitytaskforce.insightportal.repository;

import com.qualitytaskforce.insightportal.model.BlockedIP;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface BlockedIPRepository extends JpaRepository<BlockedIP, UUID> {
    public boolean findBlockedIPByIpAddress(String IP);
}
