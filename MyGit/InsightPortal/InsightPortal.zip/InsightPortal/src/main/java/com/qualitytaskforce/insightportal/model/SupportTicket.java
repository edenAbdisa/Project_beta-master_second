package com.qualitytaskforce.insightportal.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.qualitytaskforce.insightportal.model.users.User;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "support_ticket")
public class SupportTicket implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id", nullable = false)	
	private SupportCategory supportCategory;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "status_id", nullable = false)
	private SupportStatus supportStatus;
	
	@Column(name = "subject", nullable = false, length = 50)
	private String subject;
	
	@Column(name = "email", nullable = false)
	private String email;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;
	
	@Column(name = "content", nullable = false, length = 65535)
	private String content;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false, length = 19)
	private Date createdAt;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "supportTicket")
	private Set<SupportComment> supportComments = new HashSet<>(0);

	public SupportTicket() {
	}

	public SupportTicket(UUID uuid, SupportCategory supportCategory, SupportStatus supportStatus, String subject,
			String email, String content, Date createdAt) {
		this.uuid = uuid;
		this.supportCategory = supportCategory;
		this.supportStatus = supportStatus;
		this.subject = subject;
		this.email = email;
		this.content = content;
		this.createdAt = createdAt;
	}

	public SupportTicket(UUID uuid, SupportCategory supportCategory, SupportStatus supportStatus, User user,
			String subject, String email, String content, Date createdAt, Set<SupportComment> supportComments) {
		this.uuid = uuid;
		this.supportCategory = supportCategory;
		this.supportStatus = supportStatus;
		this.user = user;
		this.subject = subject;
		this.email = email;
		this.content = content;
		this.createdAt = createdAt;
		this.supportComments = supportComments;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public SupportCategory getSupportCategory() {
		return this.supportCategory;
	}

	public void setSupportCategory(SupportCategory supportCategory) {
		this.supportCategory = supportCategory;
	}

	public SupportStatus getSupportStatus() {
		return this.supportStatus;
	}

	public void setSupportStatus(SupportStatus supportStatus) {
		this.supportStatus = supportStatus;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Set<SupportComment> getSupportComments() {
		return this.supportComments;
	}

	public void setSupportComments(Set<SupportComment> supportComments) {
		this.supportComments = supportComments;
	}
}
