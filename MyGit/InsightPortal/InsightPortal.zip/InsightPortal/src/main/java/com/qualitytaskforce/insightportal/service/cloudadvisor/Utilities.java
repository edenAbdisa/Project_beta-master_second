package com.qualitytaskforce.insightportal.service.cloudadvisor;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.UnauthorizedException;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.service.users.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;

@Service
public class Utilities {

    @Autowired
    private UserService userService;

    public String getUserCompanyName(HttpServletRequest request) throws UnauthorizedException, DataNotFoundException {
        Principal loggedInUser = request.getUserPrincipal();
        if (loggedInUser == null) {
            throw new UnauthorizedException("Could not authenticate user.");
        }
        User user = userService.getByEmail(loggedInUser.getName());
        if (user.getCompany() == null){
            throw new DataNotFoundException("The current user has no company.");
        }
        return user.getCompany();
    }
}
