package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import com.qualitytaskforce.insightportal.model.testadvisor.Device;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DashboardRepository extends JpaRepository<Device, Long> {

    @Query(value = "SELECT uuid_v4() AS uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, "
                + "(SUM(IFNULL(ta_ms_mobile_devices.marketpenetration * ta_countries.desktop_users  / :total, 0))) AS marketpen "
                + "FROM ta_ms_mobile_devices "
                + "INNER JOIN ta_devices ON ta_devices.uuid = deviceuuid "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "INNER JOIN ta_oss ON ta_oss.uuid = osuuid "
				+ "WHERE ta_countries.uuid IN :countries "
                + "AND desktop_users > 0 "
                + "AND date = :date "
                + "AND (ta_oss.name = 'Android' OR ta_oss.name = 'iOS') "
                + "GROUP BY ta_devices.brand, ta_devices.model "
                + "ORDER BY marketpen DESC "
                + "LIMIT :l"
				, nativeQuery = true)
    List<Device> topDevicesGlobal(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("l") int limit, @Param("total") long total);
    
    @Query(value = "SELECT uuid_v4() AS uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, "
                + "(SUM(IFNULL(ta_ms_mobile_devices.marketpenetration * ta_countries.desktop_users  / :total, 0))) AS marketpen "
                + "FROM ta_ms_mobile_devices "
                + "INNER JOIN ta_devices ON ta_devices.uuid = deviceuuid "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "INNER JOIN ta_oss ON ta_oss.uuid = osuuid "
				+ "WHERE ta_countries.uuid IN :countries "
                + "AND desktop_users > 0 "
                + "AND date = :date "
                + "AND (ta_oss.name = 'Android' OR ta_oss.name = 'iOS') "
                + "GROUP BY ta_devices.brand, ta_devices.model "
                + "ORDER BY marketpen DESC"
				, nativeQuery = true)
	List<Device> topDevicesGlobalNoLimit(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("total") long total);

    @Query(value = "SELECT uuid_v4() AS uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, "
                + "SUM(marketpenetration) AS marketpen "
                + "FROM ta_ms_mobile_devices "
                + "INNER JOIN ta_devices ON ta_devices.uuid = deviceuuid "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "INNER JOIN ta_oss ON ta_oss.uuid = osuuid "
                + "WHERE ta_countries.code = :code "
                + "AND date = :date "
                + "AND (ta_oss.name = 'Android' OR ta_oss.name = 'iOS') "
                + "GROUP BY ta_devices.brand, ta_devices.model "
                + "ORDER BY marketpen DESC "
                + "LIMIT :l"
                , nativeQuery = true)
    List<Device> topDevicesCountry(@Param("code") String code, @Param("date") String date, @Param("l") int limit);

    @Query(value = "SELECT SUM(desktop_users) "
                + "FROM ta_countries "    
                + "WHERE uuid IN :countries "
                , nativeQuery = true)
    long getUserTotal(@Param("countries") List<UUID> countries);

}