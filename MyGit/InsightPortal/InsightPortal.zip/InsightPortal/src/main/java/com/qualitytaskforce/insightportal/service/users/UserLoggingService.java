package com.qualitytaskforce.insightportal.service.users;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLogging;
import com.qualitytaskforce.insightportal.model.util.UserLoggingAction;
import com.qualitytaskforce.insightportal.repository.users.UserLoggingRepository;
import com.qualitytaskforce.insightportal.s3.services.AmazonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.List;

@Service
public class UserLoggingService {

    @Autowired
    UserLoggingRepository userLoggingRepository;

    @Autowired
    UserService userService;

    @Autowired
    AmazonClient amazonClient;

    public void saveUserLog(String email, String ipAddress, UserLoggingAction action) {
        UserLogging log = new UserLogging();

        log.setAction(action.getValue());
        User user = userService.getByEmail(email);
        log.setUser(user);
        log.setIpAddress(ipAddress.getBytes());
        log.setActionTime(new Date());

        amazonClient.addToLogs(log);
        userLoggingRepository.save(log);
    }

    public String getClientIP(HttpServletRequest request) {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0];
    }
    
    public List<UserLogging> findByUser (User user) {
    	return userLoggingRepository.findByUser(user);
    }
    
    public void delete (UserLogging userLogging) {
    	userLoggingRepository.delete(userLogging);
    }
}
