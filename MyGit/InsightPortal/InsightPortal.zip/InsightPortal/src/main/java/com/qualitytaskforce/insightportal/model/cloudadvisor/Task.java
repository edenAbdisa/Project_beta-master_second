package com.qualitytaskforce.insightportal.model.cloudadvisor;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.Date;
import java.util.UUID;

import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "tasks")
public class Task implements java.io.Serializable{
	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name="uuid")
	private UUID uuid;

    @Column(name="priority")
    private int priority;
	
	@Column(name="task_type")
	@Enumerated(EnumType.STRING)
	private TaskType taskType;
	
	@Column(name="status")
	@Enumerated(EnumType.STRING)
	private Status status;


	@Lob
	@Column(name="status_comment")
	private String statusComment;

	@JsonProperty("created_at")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="created_at")
	private Date createdAt;

	@JsonProperty("updated_at")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name="updated_at")
	private Date updatedAt;

    @JsonProperty("target_date")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
    @Column(name="target_date")
    private Date targetDate;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "slot_uuid")
	private Slot slot;


	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "cloud_uuid")
	private CloudAdvisor cloudAdvisor;


	// Constructors //

    public Task() {
    }

    public Task(int priority, TaskType taskType, Status status, String statusComment, Date createdAt, Date updatedAt,
                Date targetDate, Slot slot, CloudAdvisor cloudAdvisor) {

        this.priority = priority;
        this.taskType = taskType;
        this.status = status;
        this.statusComment = statusComment;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.targetDate = targetDate;
        this.slot = slot;
        this.cloudAdvisor = cloudAdvisor;
    }


    // Getters and Setters //

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

	public TaskType getTaskType() {
		return taskType;
	}

	public void setTaskType(TaskType taskType) {
		this.taskType = taskType;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public String getStatusComment() {
		return statusComment;
	}

	public void setStatusComment(String statusComment) {
		this.statusComment = statusComment;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public Slot getSlot() {
		return slot;
	}

	public void setSlot(Slot slot) {
		this.slot = slot;
	}
    public Date getTargetDate() {
        return targetDate;
    }

    public void setTargetDate(Date targetDate) {
        this.targetDate = targetDate;
    }

    public CloudAdvisor getCloudAdvisor() {
        return cloudAdvisor;
    }

    public void setCloudAdvisor(CloudAdvisor cloudAdvisor) {
        this.cloudAdvisor = cloudAdvisor;
    }


    public enum TaskType{
        UPGRADE_DEVICE, UPGRAGE_BROWSER, UPGRADE_OS
    }

    public enum Status {
        COMPLETED, WAITING, IGNORED, ARCHIVED

    }
	
	
	
}
