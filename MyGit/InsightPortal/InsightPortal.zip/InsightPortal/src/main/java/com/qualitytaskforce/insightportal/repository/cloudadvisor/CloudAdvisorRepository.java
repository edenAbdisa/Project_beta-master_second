package com.qualitytaskforce.insightportal.repository.cloudadvisor;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;



public interface CloudAdvisorRepository extends JpaRepository<CloudAdvisor, UUID>{
	CloudAdvisor findByCompanyName(String companyName);
	CloudAdvisor findCloudAdvisorByCompanyName(String companyName);
	
}
