package com.qualitytaskforce.insightportal.model.util;

import java.util.UUID;

/**
 * This interface enables <em>JSONEntityUuidKeySerializer</em> to accept any
 * object that has UUID in order to serialize it to JSON properly. Any object A to 
 * be serialized, which has reference to another object B which implements this 
 * interface, if its <em>getB()</em> method is annotated with 
 * <em> @JsonSerialize(using=JSONEnitityUuidKeySerializer.class) </em> will
 * be mapped to JSON such that a field B in object A will be mapped to 
 * <em>B.getUuid.toString()</em>, instead of B being mapped to JSON with all
 * its fields.
 * In this particular case: 
 * 		B implements <em>Uuidgetable</em>
 * 		A has field B
 * 		A will be changed to JSON
 * 
 * @author Pawel
 *
 */
public interface Uuidgetable{
	public UUID getUuid();
}
