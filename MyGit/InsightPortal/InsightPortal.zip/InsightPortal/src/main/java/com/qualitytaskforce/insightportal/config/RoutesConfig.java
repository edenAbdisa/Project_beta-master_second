package com.qualitytaskforce.insightportal.config;

import java.util.HashMap;
import java.util.Map;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.qualitytaskforce.insightportal.model.util.Route;
import com.qualitytaskforce.insightportal.model.util.RouteTier;

@Configuration
public class RoutesConfig {

	private static final String UUID = "{[a-fA-F0-9]{8}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{4}-[a-fA-F0-9]{12}}";
	private static final String NUM = "{[0-9]+}";
	private static final String ALPHA = "{[A-z]+}";
	private static final String ALPHANUMERIC = "{[A-z0-9 &]}";
	private static final String SEFURL = "{[A-z0-9-]+}";

	/**
	 * This bean determines the tier level and the permission level of a path
	 * RouteTier is used for rate limiting.
	 * Permission level is used for allowing or denying access to paths.
	 */
	@Bean
	public Multimap<String, Route> routes() {
		final Multimap<String, Route> routes = ArrayListMultimap.create();
		
		// BucketController
		routes.put("/storage/", new Route(RouteTier.LOW, "EDITOR", HttpMethod.POST));
		routes.put("/storage/", new Route(RouteTier.LOW, "ADMIN", HttpMethod.DELETE));
		routes.put("/storage/", new Route(RouteTier.LOW, "EDITOR", HttpMethod.GET));

		// TestAdvisor
		routes.put("/testadvisor/browsers/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/browsers", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.POST));
		routes.put("/testadvisor/top/devices/" + ALPHA + "/" + NUM, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/top/mobileos/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/top/desktopbrowsers/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/top/desktopbrowsers/" + ALPHA + "/" + NUM, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));

		routes.put("/testadvisor/desktopbrowsers/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/desktopbrowsers/", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.POST));

		routes.put("/testadvisor/mobilebrowsers/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/mobilebrowsers/", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.POST));

		routes.put("/testadvisor/mobiledevices/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/mobiledevices/", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.POST));

		routes.put("/testadvisor/operatingsystems/" + ALPHA + "/" + ALPHA, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/testadvisor/operatingsystems/", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.POST));
		routes.put("/devices/bulk", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.POST));
		// Api Limit
		routes.put("/apilimit/create", new Route(RouteTier.LOW, "ADMIN", HttpMethod.POST));

		// Articles
		routes.put("/article/" + UUID, new Route(RouteTier.LOW, "ADMIN", HttpMethod.DELETE));
		routes.put("/article/bulk-delete", new Route(RouteTier.LOW, "ADMIN", HttpMethod.POST));
		routes.put("/article/create-article", new Route(RouteTier.LOW, "ADMIN", HttpMethod.GET));
		routes.put("/article/", new Route(RouteTier.LOW, "EDITOR", HttpMethod.POST));
		routes.put("/article/" + UUID + "/edit", new Route(RouteTier.LOW, "EDITOR", HttpMethod.GET));
		routes.put("/article/" + UUID, new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/article/count-article/" + UUID, new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/article/set-related/" + ALPHANUMERIC, new Route(RouteTier.LOW, "EDITOR", HttpMethod.GET));
		routes.put("/article/generate-related", new Route(RouteTier.LOW, "EDITOR", HttpMethod.POST));
		routes.put("/article/get-related/" + SEFURL, new Route(RouteTier.LOW, "EDITOR", HttpMethod.GET));
		routes.put("/article/publish", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/article/unpublish", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/article/reset_count", new Route(RouteTier.LOW, "ADMIN", HttpMethod.PUT));
		routes.put("/article/featured", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/article/unfeatured", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));

		// Articles - admin specific
		routes.put("/article/admin", new Route(RouteTier.LOW, "EDITOR", HttpMethod.GET));
		
		// Device scraper
		routes.put("/downloaddevicedata/", new Route(RouteTier.LOW, "ADMIN", HttpMethod.GET));
		routes.put("/downloaddeviceimages/", new Route(RouteTier.LOW, "ADMIN", HttpMethod.GET));
		
		// Releaseadvisor
		routes.put("/releaseadvisor/publish", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/releaseadvisor/unpublish", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));
		routes.put("/releaseadvisor/bulk-delete", new Route(RouteTier.LOW, "ADMIN", HttpMethod.POST));
		routes.put("/releaseadvisor/" + UUID, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/releaseadvisor", new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		routes.put("/releaseadvisor/" + UUID, new Route(RouteTier.LOW, "ADMIN", HttpMethod.DELETE));
		routes.put("/releaseadvisor", new Route(RouteTier.LOW, "EDITOR", HttpMethod.POST));
		routes.put("/releaseadvisor/" + UUID, new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));

		// ReleaseAdvisor - admin specific
		routes.put("/releaseadvisor/admin", new Route(RouteTier.LOW, "EDITOR", HttpMethod.GET));
		routes.put("/releaseadvisor/admin/" + UUID, new Route(RouteTier.LOW, "AUTOMATICTRIAL", HttpMethod.GET));
		
		// RichCards
		routes.put("/browsers", new Route(RouteTier.LOW, "EDITOR", HttpMethod.PUT));

		// Users
		routes.put("/user", new Route(RouteTier.LOW, "BUSINESSADMIN", HttpMethod.GET));
		routes.put("/user/company", new Route(RouteTier.LOW, "BUSINESSADMIN", HttpMethod.POST));
		routes.put("/user/companyfilter", new Route(RouteTier.LOW, "BUSINESSADMIN", HttpMethod.POST));
		routes.put("/user/delete", new Route(RouteTier.LOW, "ADMIN", HttpMethod.POST));
		routes.put("/userlevel/create", new Route(RouteTier.LOW, "ADMIN", HttpMethod.POST));

		routes.put("/cloudadvisor/", new Route(RouteTier.LOW, "BUSINESS", HttpMethod.GET));
		routes.put("/cloudadvisor/tasks/" + ALPHA, new Route(RouteTier.LOW, "BUSINESS", HttpMethod.GET));
		routes.put("/cloudadvisor/maxslots/" + ALPHA, new Route(RouteTier.LOW, "BUSINESS", HttpMethod.GET));
		routes.put("/cloudadvisor/tasks/archive" + ALPHA, new Route(RouteTier.LOW, "BUSINESS", HttpMethod.GET));
		
		//Slot
		routes.put("/cloudadvisor/slots/add", new Route(RouteTier.LOW, "BUSINESS", HttpMethod.POST));
		routes.put("/cloudadvisor/slots/edit/"+ UUID, new Route(RouteTier.LOW, "BUSINESS", HttpMethod.POST));
		routes.put("/cloudadvisor/slots/addBrowser/"+ UUID, new Route(RouteTier.LOW, "BUSINESS", HttpMethod.POST));
		routes.put("/cloudadvisor/slots/deleteBrowser/"+ UUID, new Route(RouteTier.LOW, "BUSINESS", HttpMethod.DELETE));
		routes.put("/cloudadvisor/slots/fetchSlots", new Route(RouteTier.LOW, "BUSINESS", HttpMethod.GET));
		return routes;
	}
}