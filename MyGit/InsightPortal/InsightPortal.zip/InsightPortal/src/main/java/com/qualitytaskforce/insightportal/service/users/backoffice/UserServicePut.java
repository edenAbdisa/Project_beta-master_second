package com.qualitytaskforce.insightportal.service.users.backoffice;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.put.JsonUpdateUser;
import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.ApiLimit;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.service.users.ApiKeyService;
import com.qualitytaskforce.insightportal.service.users.ApiLimitService;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;
import com.qualitytaskforce.insightportal.util.AddPrecisionTime;

@Service
public class UserServicePut {
	
	@Autowired
    private UserLevelService userLevelService;
	
	@Autowired
    private UserService userService;
	
	@Autowired
    private UserTrialService userTrialService;
	
	@Autowired
    private ApiLimitService apiLimitService;

    @Autowired
    private ApiKeyService apiKeyService;
	
	public void update (JsonUpdateUser inputDetails, UUID uuidUser) throws DataNotFoundException, ParseException {
		UserLevel userLevel = userLevelService.findByName(inputDetails.getUserLevel()).get(0);
       	User user = getUserLocal(inputDetails, uuidUser, userLevel);
        
        manageUserTrial(inputDetails, user);
        manageApiLimitKey(inputDetails, user);
	}
	
	User getUserLocal (JsonUpdateUser inputDetails, UUID uuidUser, UserLevel userLevel) throws DataNotFoundException {
		User user = userService.findByUUID(uuidUser);
        if (user == null) {
			throw new DataNotFoundException("User with such uuid was not found.");
		}

        user.setName(inputDetails.getName());
        user.setSurname(inputDetails.getSurname());
        user.setEmail(inputDetails.getEmail());
        String phoneNumber = inputDetails.getPhoneNumber();
        if (phoneNumber != null && phoneNumber.length() > 0) {
        	user.setPhoneNumber(phoneNumber);
		} else {
        	user.setPhoneNumber(null);
		}
        user.setCompany(inputDetails.getCompany());
        user.setUserLevel(userLevel); 
        
        if (!inputDetails.getPassword().isEmpty() && inputDetails.getPassword() != null) {
			user.setPassword(BCrypt.hashpw(inputDetails.getPassword(), BCrypt.gensalt(10)));
		}
        return user;
	}
	
	void manageUserTrial (JsonUpdateUser inputDetails, User user) throws ParseException {
		String expireAtString = inputDetails.getExpireAt();
		if (inputDetails.getUserLevel().indexOf("Trial") > -1 && expireAtString != null && expireAtString.length() > 0) {
	    	UserTrial userTrial = userTrialService.findByUser(user);
	    	Date expireAt = new SimpleDateFormat("yyyy-MM-dd").parse(expireAtString);
	    	
	    	UserTrial userTrialLast = userTrialService.findByUser(user);
	    	Date lastExpireAt = userTrialLast.getExpireAt();
	    	AddPrecisionTime addPrecisionTime = new AddPrecisionTime();
	    	Date correctExpireAt = addPrecisionTime.add(expireAt, lastExpireAt);
	    	userTrial.setExpireAt(correctExpireAt);
	    	userTrialService.save(userTrial);
	    }
	}
	
	void manageApiLimitKey (JsonUpdateUser inputDetails, User user) {
		List<ApiLimit> apiLimitList = apiLimitService.findByName(inputDetails.getApiKeyLimit());
        ApiLimit apiLimit = apiLimitList.get(0);
        ApiKey apiKey = apiKeyService.findByUser(user).get(0);
        apiKey.setApiLimit(apiLimit);
        apiKeyService.save(apiKey);
	}
}
