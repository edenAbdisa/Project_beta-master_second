package com.qualitytaskforce.insightportal.controller;
import java.util.List;

import com.qualitytaskforce.insightportal.model.ImpactRating;
import com.qualitytaskforce.insightportal.service.ImpactRatingService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/impact-rating")
public class ImpactRatingController {
    private static Logger LOGGER = LoggerFactory.getLogger(ImpactRatingController.class);

    @Autowired
    private ImpactRatingService impactRatingService;

    /**
     * Endpoint to retreive a list of impact ratings
     * @return
     */
    @GetMapping("")
    public ResponseEntity<List<ImpactRating>> getAllCategory(){
        LOGGER.trace("Getting all impact ratings.");
        List<ImpactRating> impactRatings = impactRatingService.findAll();
        LOGGER.trace("Found {} impact ratings", impactRatings);
        return new ResponseEntity<List<ImpactRating>>(impactRatings, HttpStatus.OK);
    }
}
