package com.qualitytaskforce.insightportal.model;


import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "related_articles")
public class RelatedArticles implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="id", nullable=false)
	private int id;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "original_article_id", nullable = false)
	private Article articleByOriginalArticleId; 
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "related_article")
	private Article articleByRelatedArticle;	

	public RelatedArticles() {
	}

	public RelatedArticles(UUID uuid, int id, Article articleByOriginalArticleId) {
		this.id = id;
		this.uuid = uuid;
		this.articleByOriginalArticleId = articleByOriginalArticleId;
	}

	public RelatedArticles(UUID uuid, int id, Article articleByRelatedArticle,					
			Article articleByOriginalArticleId) {
		this.uuid = uuid;
		this.id = id;
		this.articleByRelatedArticle = articleByRelatedArticle;
		this.articleByOriginalArticleId = articleByOriginalArticleId;
	}
	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}	

	public Article getArticleByRelatedArticle() {
		return this.articleByRelatedArticle;
	}

	public void setArticleByRelatedArticle(Article articleByRelatedArticle) {
		this.articleByRelatedArticle = articleByRelatedArticle;
	}	

	public Article getArticleByOriginalArticleId() {
		return this.articleByOriginalArticleId;
	}

	public void setArticleByOriginalArticleId(Article articleByOriginalArticleId) {
		this.articleByOriginalArticleId = articleByOriginalArticleId;
	}
}
