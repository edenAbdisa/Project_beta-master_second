package com.qualitytaskforce.insightportal.model.cloudadvisor;
 
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;

import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table; 
import org.hibernate.annotations.GenericGenerator;

import com.qualitytaskforce.insightportal.model.BrowserRichCard;
import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid; 
@Entity
@Table(name = "slots")
public class Slot implements java.io.Serializable{
	
	private static final long serialVersionUID = -1865259691093309584L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "cloud_advisor_uuid",nullable = false)
	private CloudAdvisor cloudAdvisor;
	
	@Column(name = "slot_id",nullable = false)
	private int slotId;

	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "device_uuid")
	private DeviceWithUuid deviceUuid;
	
	@OneToOne(fetch=FetchType.EAGER)
	@JoinColumn(name = "os_uuid", nullable = true)
	private TestAdvisorOperatingSystem taOperatingSystem;
	

	
	@ManyToMany(targetEntity=BrowserRichCard.class,fetch = FetchType.EAGER,
            cascade = {
                    CascadeType.PERSIST,
                    CascadeType.MERGE
                } )
	@JoinTable(name = "slot_browsers",joinColumns = @JoinColumn(name = "slot_uuid"),
	        inverseJoinColumns = @JoinColumn(name = "browser_uuid"))
	private List<BrowserRichCard> browserRichCard=new ArrayList<>();
	

	public UUID getUuid() {
		return uuid;
	}
	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	public CloudAdvisor getCloudAdvisor() {
		return cloudAdvisor;
	}
	public void setCloudAdvisor(CloudAdvisor cloudAdvisor) {
		this.cloudAdvisor = cloudAdvisor;
	}
	public int getSlotId() {
		return slotId;
	}
	public void setSlotId(int slotId) {
		this.slotId = slotId;
	}
	public DeviceWithUuid getDeviceUuid() {
		return deviceUuid;
	}
	public void setDeviceUuid(DeviceWithUuid deviceUuid) {
		this.deviceUuid = deviceUuid;
	}
	
	public List<BrowserRichCard> getBrowserRichCard() {
		return browserRichCard;
	}
	public void setBrowserRichCard(List<BrowserRichCard> browserRichCard) {
		this.browserRichCard = browserRichCard;
	}

	public TestAdvisorOperatingSystem getTaOperatingSystem() {
		return taOperatingSystem;
	}
	public void setTaOperatingSystem(TestAdvisorOperatingSystem taOperatingSystem) {
		this.taOperatingSystem = taOperatingSystem;
	}

	
	public Slot() {}
	public Slot(UUID uuid, CloudAdvisor cloudAdvisor, int slotId, DeviceWithUuid deviceUuid,
			TestAdvisorOperatingSystem taOperatingSystem, List<BrowserRichCard> browserRichCard) {
	 
		this.uuid = uuid;
		this.cloudAdvisor = cloudAdvisor;
		this.slotId = slotId;
		this.deviceUuid = deviceUuid;
		this.taOperatingSystem = taOperatingSystem;
		this.browserRichCard = browserRichCard;
	}

	
	
}