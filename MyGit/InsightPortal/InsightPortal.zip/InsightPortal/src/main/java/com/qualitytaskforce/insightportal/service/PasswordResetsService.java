package com.qualitytaskforce.insightportal.service;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.users.PasswordResets;
import com.qualitytaskforce.insightportal.repository.PasswordResetsRepository;

@Service
public class PasswordResetsService {

	@Autowired
	PasswordResetsRepository passwordResetsRepository;

	public void save(PasswordResets passwordResets) {
		passwordResetsRepository.save(passwordResets);
	}

	public PasswordResets findByToken(String token) {
		return passwordResetsRepository.findByToken(token);
	}

	public String findEmailByToken(String token) {
		return passwordResetsRepository.findEmailByToken(token);
	}

	public PasswordResets findByResetcode(String resetcode) {
		return passwordResetsRepository.findByResetcode(resetcode);
	}

	public List<PasswordResets> findAll() {
		return passwordResetsRepository.findAll();
	}

	public String[] generateAndSaveResetcodeAndToken(String email, String type) {
		SecureRandom random = new SecureRandom();
		String newResetcode = new BigInteger(130, random).toString(16).substring(0, 16);
		String newToken = new BigInteger(130, random).toString(16);


		List<PasswordResets> listPasswordRess = findAll();
		for (PasswordResets passwordress : listPasswordRess) {
			if (passwordress.getToken().equals(newToken)
					|| passwordress.getResetcode().equals(newResetcode)) {
				generateAndSaveResetcodeAndToken(email, type);
			}
		}

		PasswordResets passresets = new PasswordResets();
		passresets.setEmail(email);
		manageResetCode(type, passresets, newResetcode);
		passresets.setToken(newToken);
		passresets.setActive(true);
		passresets.setCreatedAt(new Date());

		save(passresets);

		return new String[] {newResetcode, newToken};
	}

	void manageResetCode(String type, PasswordResets passresets, String newResetcode) {
		// type: reset, create
		if (type.equals("reset")) {
			passresets.setResetcode(newResetcode);
		} else if (type.equals("create")) {
			passresets.setResetcode("000" + newResetcode.substring(3));
		}
	}


	public boolean verifyTokenActivity(String token) throws DataNotFoundException {

		PasswordResets passresets = findByToken(token);
		if (passresets == null) {
			throw new DataNotFoundException("Not exist record with such token");
		}
		boolean isActiveToken = passresets.isActive();

		return isActiveToken;
	}
}
