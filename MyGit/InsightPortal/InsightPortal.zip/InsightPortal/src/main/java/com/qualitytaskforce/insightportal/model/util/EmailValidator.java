package com.qualitytaskforce.insightportal.model.util;

/**
*	Email validation object 
*
*	@author Mark Greenbank
* 	@version 1.0
* 	@since 2017-07-07
*/

public class EmailValidator {

	private String email;
	private final String localFirstPattern = "^(\\\\.|[A-Za-z0-9!#%&`_=/$\'*+?^\\{}|~.-])+$";
	private final String localSecondPattern = "^\"(\\\\\"|[^\"])+\"$";
	private final String domainFirstPattern = "^[A-Za-z0-9\\\\-\\\\.]+$";

	/**
	*	Constructor
	*	@param email This is the email to be validated.
	*/
	public EmailValidator(String email) {
		this.email = email;
	}

	/**
	*	Validation function
	*	@return boolean True if the email is valid, false if it is invalid.
	*/
	public boolean validateEmail() {

		int atIndex = email.lastIndexOf("@");
		// indexOf returns -1 if it does not find the specified symbol
		if (atIndex != -1) {
			
			// Split the email into local and domain parts - RFC 2822 3.4.1
			String localPart = email.substring(0, atIndex);
			String domainPart = email.substring(atIndex + 1);
			int localLen = localPart.length();
			int domainLen = domainPart.length();

			// Test lengths of local parts - RFC 2821 4.5.3.1
			if (localLen > 0 && localLen <= 64) {
				if (domainLen > 0 && domainLen <= 255) {

					// Local part can have one of two forms
					// It may begin and end quote with no unescaped embedded quotes
					// OR a string of valid characters preceeding and succeeding a dot
					String localTemp = localPart.replace("\\\\", "");
					if (!localTemp.matches(localFirstPattern)) { //  - RFC 2822 3.2.4
						if (!localTemp.matches(localSecondPattern)) { // - RFC 2822 3.2.5
							return false;
						}
					}

					// Check dot placement for local part
					if (localPart.indexOf('.') != 0 && localPart.indexOf('.') != (localLen - 1)) {
						
						// Check if the local part has two consecutive dots
						if (!localPart.contains("..")) {
							
							// Check if the domain part has two consecutive dots
							if (!domainPart.contains("..")) {

								// Check if domain does not end with a dot
								if (!domainPart.endsWith(".")) {

									if (domainPart.matches(domainFirstPattern)) {
										return true;
									}
								}
							}
						}
					}
				}
			}
		}
		return false;
	}
}