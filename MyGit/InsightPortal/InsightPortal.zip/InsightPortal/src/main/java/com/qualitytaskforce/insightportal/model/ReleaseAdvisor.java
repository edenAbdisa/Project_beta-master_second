package com.qualitytaskforce.insightportal.model;

import java.sql.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.qualitytaskforce.insightportal.model.post.JsonReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.util.JSONEnitityUuidKeySerializer;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "release_advisor")
public class ReleaseAdvisor implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "article_id")
	private Article articles;
	
	@Column(name = "category", length = 50)
	private String category;
	
	@Column(name = "title", nullable = false, length = 50)
	private String title;
	
	@Column(name = "subtitle", nullable = false, length = 50)
	private String subtitle;
	
	@Column(name = "published", nullable = false)
	private boolean published;

	@JsonProperty("start_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name = "start_date", nullable = false, length = 19)
	private Date startDate;

	@JsonProperty("end_date")
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd")
	@Column(name = "end_date", nullable = false, length = 19)
	private Date endDate;

	public ReleaseAdvisor() {
	}
	
	public ReleaseAdvisor(JsonReleaseAdvisor jra) {
		this();
		this.category = jra.getCategory();
		this.title = jra.getTitle();
		this.subtitle = jra.getSubtitle();
		this.published = jra.isPublished();
		this.startDate = jra.getStartDate();
		this.endDate = jra.getEndDate();
	}

	public ReleaseAdvisor(UUID uuid, String title, String subtitle, boolean published, Date startDate, Date endDate) {
		this.uuid = uuid;
		this.title = title;
		this.subtitle = subtitle;
		this.published = published;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public ReleaseAdvisor(UUID uuid, Article articles, String category, String title, String subtitle, boolean published,
			Date startDate, Date endDate) {
		this.uuid = uuid;
		this.articles = articles;
		this.category = category;
		this.title = title;
		this.subtitle = subtitle;
		this.published = published;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	@JsonSerialize(using=JSONEnitityUuidKeySerializer.class) 
	@JsonProperty("article_id")
	public Article getArticle() {
		return this.articles;
	}

	public void setArticle(Article articles) {
		this.articles = articles;
	}

	public String getCategory() {
		return this.category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return this.subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public boolean isPublished() {
		return this.published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}


	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}
