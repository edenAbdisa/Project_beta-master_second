package com.qualitytaskforce.insightportal.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.TokenExpiredException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.service.users.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.stereotype.Component;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

@Component
public class JWTAuthorizationFilter extends BasicAuthenticationFilter {
    
    public static final Logger LOGGER = LoggerFactory.getLogger(JWTAuthorizationFilter.class);

    private UserService userService;

    // private JWTAuthorizationFilter() {
    //     super(null);
    // }

    public JWTAuthorizationFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
            FilterChain chain) throws IOException, ServletException {
        String header = req.getHeader(JWTConfig.HEADER_STRING);
        /* Discard the request if there is no "Authorization: Bearer <token>" header */

        if (header == null || !header.startsWith(JWTConfig.TOKEN_PREFIX)) {
            chain.doFilter(req, res);
            return;
        }

        UsernamePasswordAuthenticationToken authentication = getAuthentication(req, res);

        SecurityContextHolder.getContext().setAuthentication(authentication);
        chain.doFilter(req, res);
    }

    private UsernamePasswordAuthenticationToken getAuthentication(HttpServletRequest request,
            HttpServletResponse response) {

        String requestPath = request.getRequestURI();
        boolean isUserLoggingOut = (requestPath.equals("/userlogout/"));

        /* Header structure: "Bearer <token>" - it has to be split to only retrieve pure token */
        String[] header = request.getHeader(JWTConfig.HEADER_STRING).split(" ");
        String token = header[1];
        if (token != null) {

            String userLogin;
            Date expiresAt;
            try {
                Algorithm algorithm = Algorithm.HMAC256(JWTConfig.SECRET);
                JWTVerifier verifier = JWT.require(algorithm).withIssuer(JWTConfig.ISSUER).build();
                DecodedJWT jwt = verifier.verify(token);
                userLogin = jwt.getSubject();
                expiresAt = jwt.getExpiresAt();

                manualAutowire(request);

                List<User> user = userService.findByEmail(userLogin);
                String userPermissions = user.get(0).getUserLevel().getPermissions();
                List<GrantedAuthority> authorities = parseAuthority(userPermissions);

                /*
                 * Check if token should be refreshed and if the request was not issued to
                 * userlogout path (if the user is logging out, there is no need to return JWT)
                 */
                if (shouldRefreshToken(expiresAt) && !isUserLoggingOut) {
                    String refreshToken = getRefreshToken(user.get(0));
                    response.setHeader(JWTConfig.HEADER_STRING,
                            JWTConfig.TOKEN_PREFIX + refreshToken);
                    response.setHeader("Access-Control-Expose-Headers", JWTConfig.HEADER_STRING);
                    response.setHeader("Access-Control-Allow-Headers", JWTConfig.HEADER_STRING);
                }

                /*
                 * No need to check if user is null as it is already taken care of when verifying
                 * the token
                 */

                return new UsernamePasswordAuthenticationToken(user.get(0).getEmail(),
                        user.get(0).getPassword(), authorities);

            } catch (JWTDecodeException e) {
                LOGGER.info("JWTDecode error.", e);
            } catch (UnsupportedEncodingException e) {
                LOGGER.info("Encoding error.", e);
            } catch (TokenExpiredException e) {
                return null;
            }
        }
        return null;
    }

    /**
     * Get a refresh token for the currently expiring one
     */

    private String getRefreshToken(User user) {
        String userLogin = user.getEmail();
        String nameAndSurname = user.getNameAndSurname();
        String userLevelValue = JWTConfig.getUserLevelValue(user.getUserLevel().getName());
        long expirationTime = JWTConfig.EXPIRATION_TIME;
        String token = null;
        try {
            token = JWT.create().withIssuer(JWTConfig.ISSUER).withSubject(userLogin)
                    .withClaim("userLevel", userLevelValue).withClaim("name", nameAndSurname)
                    .withExpiresAt(new Date(System.currentTimeMillis() + expirationTime))
                    .sign(Algorithm.HMAC256(JWTConfig.SECRET));
        } catch (UnsupportedEncodingException e) {
            LOGGER.info("Encoding error.", e);
        }
        return token;
    }

    /**
     * Decide that JWT should be refreshed if the old one is going to expire in [REFRESH_PERIOD]
     * minutes
     * 
     * @return l
     */

    private boolean shouldRefreshToken(Date expiresAt) {
        LocalDateTime expiryDate =
                expiresAt.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        long minutes = ChronoUnit.MINUTES.between(LocalDateTime.now(), expiryDate);
        if (minutes < JWTConfig.REFRESH_PERIOD) {
            return true;
        }
        return false;
    }

    private List<GrantedAuthority> parseAuthority(String userPermissions) {
        List<GrantedAuthority> authorities = new ArrayList<>();
        try {

            Map<String, Object> map = new HashMap<>();

            ObjectMapper mapper = new ObjectMapper();

            map = mapper.readValue(userPermissions, new TypeReference<Map<String, Object>>() {
            });

            for (Map.Entry<String, Object> entry : map.entrySet()) {
                String name = entry.getKey().toUpperCase();
                String value = entry.getValue().toString();

                if (value.equals("1")) {
                    SimpleGrantedAuthority s = new SimpleGrantedAuthority("ROLE_" + name);
                    authorities.add(s);
                }
            }

        } catch (Exception e) {
            e.getMessage();
        }

        return authorities;
    }

    private void manualAutowire(HttpServletRequest request) {
        if (userService == null) {
            ServletContext servletContext = request.getServletContext();
            WebApplicationContext webApplicationContext =
                    WebApplicationContextUtils.getWebApplicationContext(servletContext);
            userService = webApplicationContext.getBean(UserService.class);
        }
    }
}
