package com.qualitytaskforce.insightportal.repository.users;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.User;

public interface ApiKeyRepository extends JpaRepository<ApiKey, Long> {
	
	List<ApiKey> findByUser(User user);

	ApiKey findFirstByUser(User user);
}