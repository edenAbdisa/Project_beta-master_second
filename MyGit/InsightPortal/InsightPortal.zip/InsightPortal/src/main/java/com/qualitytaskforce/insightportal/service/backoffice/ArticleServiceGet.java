package com.qualitytaskforce.insightportal.service.backoffice;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ArticleUpdate;
import com.qualitytaskforce.insightportal.model.RelatedArticles;
import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.put.JsonArticleUpdate;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.BrowserRichCardService;
import com.qualitytaskforce.insightportal.service.MobileDeviceRichCardService;
import com.qualitytaskforce.insightportal.service.RelatedArticlesService;
import com.qualitytaskforce.insightportal.util.DateToString;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ArticleServiceGet {
	
	@Autowired
	ArticleService articleService;
	
	@Autowired
	BrowserRichCardService browserRichCardService;

	@Autowired
	MobileDeviceRichCardService mobileDeviceRichCardService;
	
	@Autowired
	RelatedArticlesService relatedArticleService;

	public Map<String, Object> getExisting (UUID uuid) throws DataNotFoundException {
		Article article = articleService.findByUUID(uuid);

        Map<String, Object> articleMap = new HashMap<>();
        articleMap.put("uuid", article.getUuid());
        articleMap.put("title", article.getTitle());
        articleMap.put("fullText", article.getFullText());
        articleMap.put("metaKeywords", article.getMetaKeywords());
        articleMap.put("summaryText", article.getSummaryText());
        articleMap.put("articleUpdates", convert2JsonArticleUpdate(article.getArticleUpdates()));
        
        Set<ReleaseAdvisor> raSet = article.getReleaseAdvisors();
		List<ReleaseAdvisor> raList = new ArrayList<>(raSet);
		if (raList.size() == 0) {
			articleMap.put("releaseAdvisors", article.getReleaseAdvisors());
		} else {
			raList.get(0);        
			HashMap<String, Object> raMap = raToRaMap (raList);
			List<HashMap<String, Object>> listRaMap = new ArrayList<>();
			listRaMap.add(raMap);
			articleMap.put("releaseAdvisors", listRaMap);
		}
        
        articleMap.put("categoryName", article.getCategory().getName());
        articleMap.put("subcategoryName", article.getSubcategory());
        articleMap.put("categoryId", article.getCategory().getUuid());
        articleMap.put("impactRatingName", article.getImpactRating().getName());
        articleMap.put("impactRatingId", article.getCategory().getUuid());

        if (article.getTestRecommendation() == null) {
            articleMap.put("testRecommendationId", null);
            articleMap.put("testRecommendation", null);
        } else {
            articleMap.put("testRecommendationId", article.getTestRecommendation().getUuid());
            articleMap.put("testRecommendation", article.getTestRecommendation().getContent());
        }

        articleMap.put("richcardType", article.getRichcardType());
        articleMap.put("richcardId", article.getRichcardId());
        
        String rcType = article.getRichcardType();
        String rcBrand = "";
        String rcModel = "";
        
        if (rcType.equals("browsers")) {
        	rcBrand = browserRichCardService.getBrowserBrand(article.getRichcardId());
        	rcModel = browserRichCardService.getBrowserModel(article.getRichcardId());
        					
        } else if (rcType.equals("devices")) {
        	rcBrand = mobileDeviceRichCardService.getMobileDeviceBrand(article.getRichcardId());
        	rcModel = mobileDeviceRichCardService.getMobileDeviceModel(article.getRichcardId());
        }
        
        articleMap.put("richcardBrand", rcBrand);
        articleMap.put("richcardModel", rcModel);
        articleMap.put("artworkUrl", article.getImgLink());
        articleMap.put("published", article.getPublished());
        
        List<RelatedArticles> listOfRelated = relatedArticleService.findByArticle(article);
        if (listOfRelated.isEmpty())
        	throw new DataNotFoundException("List with related articles not found.");
       
        List<String> listOfRelatedtTitles = new ArrayList<String>();        
        for (RelatedArticles relatedArticle : listOfRelated) {
        	Article a = relatedArticle.getArticleByRelatedArticle();
        	if (a != null) {
        		listOfRelatedtTitles.add(a.getTitle());
        	}
        }
        
        articleMap.put("relatedArticles", listOfRelatedtTitles);
        
        return articleMap;
	}
	
	List<JsonArticleUpdate> convert2JsonArticleUpdate (Set<ArticleUpdate> articleUpdates){
		DateToString dateString = new DateToString();
		String dateStr = "";
		
		List<ArticleUpdate> listAU = new ArrayList<>(articleUpdates);
		listAU.sort((u1,u2) -> u2.getUpdatedAt().compareTo(u1.getUpdatedAt()));
				
		List<JsonArticleUpdate> jsonUpdatesList = new ArrayList<JsonArticleUpdate>(); 
		for (ArticleUpdate update : listAU) {
			JsonArticleUpdate jsonUpdate = new JsonArticleUpdate(); 
			jsonUpdate.setUpdateContent(update.getContent());
			String checkinuser = null;
			if (update.getUserByCheckInBy() != null) {			
				checkinuser = new String();
				checkinuser = update.getUserByCheckInBy().getNameAndSurname();
			}
			jsonUpdate.setUpdateCheckBy(checkinuser);
			jsonUpdate.setUuid(update.getUuid());
				dateStr = dateString.dateToString(update.getUpdatedAt());
				System.out.println(("Dates: " + update.getUpdatedAt()));
			jsonUpdate.setUpdateDate(dateStr);
			jsonUpdatesList.add(jsonUpdate);
		}		
		
		return jsonUpdatesList;
	}
	

	HashMap<String, Object> raToRaMap (List<ReleaseAdvisor> raList) {
		HashMap<String, Object> raMap = new HashMap<>();
		for (ReleaseAdvisor ra : raList) {					
			raMap.put("uuid", ra.getUuid());
			raMap.put("category", ra.getCategory());
			raMap.put("title", ra.getTitle());
			raMap.put("subtitle", ra.getSubtitle());
			raMap.put("published", ra.isPublished());
			raMap.put("start_date", ra.getStartDate().toString());
			raMap.put("end_date", ra.getEndDate().toString());
			Article article = ra.getArticle();
			if (article != null) {
				raMap.put("article_id", article.getUuid().toString());
			} else {
				raMap.put("article_id", null);
			}
		}		
		return raMap;
	}
	
	
}
