package com.qualitytaskforce.insightportal.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

//Filter to allow a selectable locale for the future
/* 
 * References -- RFC 7231 5.3.5
 */

@Component
public class LocaleHeaderFilter implements Filter {

	public LocaleHeaderFilter() {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;

		String inputLocale = request.getHeader("Accept-Language");
		List<String> supportedLocales = new ArrayList<>();
		supportedLocales.add("en");
		
		if (supportedLocales.contains(inputLocale)) {
			request.setAttribute("locale", inputLocale);
		} else {
			request.setAttribute("locale", "en");
		}
		chain.doFilter(request, res);
	}

	@Override
	public void init(FilterConfig filterConfig) {
	}

	@Override
	public void destroy() {
	}
}