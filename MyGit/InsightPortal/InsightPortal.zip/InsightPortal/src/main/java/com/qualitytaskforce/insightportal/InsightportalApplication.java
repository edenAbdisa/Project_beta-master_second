package com.qualitytaskforce.insightportal;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.bohnman.squiggly.Squiggly;
import com.github.bohnman.squiggly.web.RequestSquigglyContextProvider;
import com.github.bohnman.squiggly.web.SquigglyRequestFilter;
import com.qualitytaskforce.insightportal.util.ListResponse;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import javax.servlet.http.HttpServletRequest;

@SpringBootApplication
@EnableScheduling
public class InsightportalApplication {

	public static void main(String[] args) {
		SpringApplication.run(InsightportalApplication.class, args);
	}

	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/**").allowedOrigins("*").allowedMethods("*");
			}
		};
	}

	@Bean
	public FilterRegistrationBean squigglyRequestFilter() {
		FilterRegistrationBean filter = new FilterRegistrationBean();
		filter.setFilter(new SquigglyRequestFilter());
		filter.setOrder(1);
		return filter;
	}

	@Bean
	public ObjectMapper objectMapper() {
		return Squiggly.init(new ObjectMapper(), new RequestSquigglyContextProvider() {
			@Override
			protected String customizeFilter(String filter, HttpServletRequest request, Class beanClass) {

				// OPTIONAL: automatically wrap filter expressions in items{} when the object is a ListResponse
				if (filter != null && ListResponse.class.isAssignableFrom(beanClass)) {
					filter = "items{" + filter + "}";
				}

				return filter;
			}
		});
	}


}

