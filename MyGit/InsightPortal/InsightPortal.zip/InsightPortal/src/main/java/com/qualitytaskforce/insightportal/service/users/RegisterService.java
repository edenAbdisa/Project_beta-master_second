package com.qualitytaskforce.insightportal.service.users;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.Team;
import com.qualitytaskforce.insightportal.model.post.TrialUserRegister;
import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.ApiLimit;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.model.util.EmailValidator;
import com.qualitytaskforce.insightportal.service.EmailServiceImpl;
import com.qualitytaskforce.insightportal.service.MessageUtil;

@Service
public class RegisterService {
	
	@Autowired
    private UserService userService;
	
	@Autowired
    private UserLevelService userLevelService;
	
	@Autowired
    private ApiKeyService apiKeyService;
	
	@Autowired
    private ApiLimitService apiLimitService;

	@Autowired
	private TemplateEngine templateEngine;
	
	@Autowired
 	private EmailServiceImpl emailService;

	@Autowired
 	private UserTrialService userTrialService;
	
	@Autowired
    private MessageUtil util;
	
	
	public String register (HttpServletRequest request, HttpServletResponse response, TrialUserRegister inputDetails) throws InvalidParameterFormatException, DataNotFoundException {
		
		String email = inputDetails.getEmail();
		checkEmailExisting(email);
		
        validateParameters(request, inputDetails);
        String token = saveEntitiesGetToken(inputDetails);
        String resp = util.getMessage("success.users.create");
        
        ServletContext ctx = request.getServletContext();
        WebContext context = new WebContext(request, response, ctx, request.getLocale());
        
        context.setVariable("userNameSurname", "User");
        context.setVariable("token", token);
        context.setVariable("host", "https://insightportal.io"); // set host address for link in email
        context.setVariable("automaticTrial", true);
        String body = this.templateEngine.process("VerificationEmail", context);
        
        String emailFrom = "contactus@insightportal.io";
        // DEV
        //String emailTo = "";
        String emailTitle = "InsightPortal – Verify and activate your InsightPortal account";
        emailService.sendEmail(emailFrom, inputDetails.getEmail(), emailTitle, body);
       
        return resp;
	}
	
	private void validateParameters (HttpServletRequest request, TrialUserRegister inputDetails) throws InvalidParameterFormatException {
		EmailValidator ev = new EmailValidator(inputDetails.getEmail());
		List<User> existingUser = userService.findByEmail(inputDetails.getEmail());
		
		 if (!ev.validateEmail()) {
            throw new InvalidParameterFormatException(util.getMessage("error.users.create.invalid-email"));
		 }

         if (!existingUser.isEmpty()) {
        	throw new InvalidParameterFormatException(util.getMessage("error.users.create.exists"));
         }
	}
	
	private Date addDaysToDate (Date inputDate, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}
	
	@Transactional
	public String saveEntitiesGetToken (TrialUserRegister inputDetails) throws DataNotFoundException {
		UUID userUUID = UUID.randomUUID();

        String name = "";
        String surname = "";
        String email = inputDetails.getEmail();
        String password = BCrypt.hashpw(inputDetails.getPassword(), BCrypt.gensalt(10));
        String company = null;
        UserLevel userLevel = userLevelService.findByName("AutomaticTrial").get(0);
        boolean activated = false;
        boolean blocked = false;
        short blockCount = 0;
        Date lastBlockDate = null;
        Date createdAt = new Date();
        Date updatedAt = createdAt;
        Date expireAt = addDaysToDate(createdAt, 7);
        Date lastVisit = null;
        Team teamId = null;
        User user = new User(userUUID, name, surname, email, password, company, userLevel, activated, blocked, blockCount, lastBlockDate, createdAt, updatedAt, lastVisit, teamId);
        
        String token = userTrialService.generateVerificationToken();
        UserTrial userTrial = getLocalUserTrial(user, token, expireAt);
        user.setUserTrial(userTrial);
        
        userService.save(user);
        saveApiKey(email);
        
        return token;
	}
	
	private User getUserByEmailLocally (String email) throws DataNotFoundException {
		List<User> userList = userService.findByEmail(email);
        if (userList.isEmpty()) {
			throw new DataNotFoundException("User with such email not found.");
        }
        return userList.get(0);
	}
	
	private void checkEmailExisting (String email) throws DataNotFoundException {
		List<User> userList = userService.findByEmail(email);
        if (!userList.isEmpty()) {
        	throw new DataNotFoundException("User with such email already exist.");
        }
	}
	
	private UserTrial getLocalUserTrial (User user, String token, Date expireAt) {
		UserTrial userTrial = new UserTrial();
		userTrial.setUser(user);
		userTrial.setConfirmationToken(token);
        userTrial.setSentTrialEmail(false);
        userTrial.setExpireAt(expireAt);
        return userTrial;
	}
	
	private void saveApiKey (String email) throws DataNotFoundException {
		
		UUID uuidApiKey = UUID.randomUUID();
		List<ApiLimit> apiLimitList = apiLimitService.findByName("TRIAL");
        ApiLimit apiLimit = apiLimitList.get(0);
        User user = getUserByEmailLocally(email);
        
		ApiKey apiKey = new ApiKey(uuidApiKey, user, "ACCESSKEY", "SECRET", false, apiLimit, apiLimit.getLowHourly(),
                apiLimit.getLowMonthly(), apiLimit.getMedHourly(), apiLimit.getMedMonthly(),
                apiLimit.getHighHourly(), apiLimit.getHighMonthly());
        apiKeyService.save(apiKey);
	}
}
