package com.qualitytaskforce.insightportal.model.util;

public enum RouteTier {
	
	LOW,
	MEDIUM,
	HIGH;
}