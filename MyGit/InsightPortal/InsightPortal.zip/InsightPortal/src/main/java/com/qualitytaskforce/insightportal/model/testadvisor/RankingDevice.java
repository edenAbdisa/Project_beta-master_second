package com.qualitytaskforce.insightportal.model.testadvisor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RankingDevice {
	
	@Id
	@Column(name = "id")
	private int id;

	@Column(name = "device_brand")
	private String brand;

	@Column(name = "device_model")
	private String model;

	@Column(name = "marketpen")
	private float marketPen;

	public RankingDevice () {
	}

	public RankingDevice(int id, String brand, String model, float marketPen) {
		this.id = id;
		this.brand = brand;
		this.model = model;
		this.marketPen = marketPen;
	}
	
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	public float getMarketPen() {
		return this.marketPen;
	}

	public void setMarketPen(float marketPen) {
		this.marketPen = marketPen;
	}
}