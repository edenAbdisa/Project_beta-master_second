package com.qualitytaskforce.insightportal.service.relatedarticles;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.post.RelatedArticlesRequest;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.util.CalculateRelated;
import com.qualitytaskforce.insightportal.util.GetDateBefore;
import com.qualitytaskforce.insightportal.util.HtmlToString;
import com.qualitytaskforce.insightportal.util.SortMap;

@Service
public class GenerateRelated {
	
	@Autowired
    private ArticleService articleService;    
	
	public List<String> generate (RelatedArticlesRequest input) throws DataNotFoundException {
		String actualFullText = input.getFullText();
        String category = input.getCategoryName();
        List<Article> topRelatedArticles = new ArrayList<>();

        if (category.trim().length() > 0 && actualFullText.trim().length() > 0) {		
			List<Article> list = articleService.findPublishedArticlesByCategoryAndDate(category, input.getUuid());
			topRelatedArticles = calcAndGetTopRelated(list, actualFullText);
        }
        
        List<String> topRelatedArticlesTitles = topRelatedArticles.stream().map(x -> x.getTitle()).collect(Collectors.toList());
		return topRelatedArticlesTitles;
	}
	
	List<Article> removeUnpublished(List<Article> listOfArticles) {
		List<Article> onlyPublished = new ArrayList<Article>();
		for (Article a : listOfArticles) {
			if (a.isPublished()) {
				onlyPublished.add(a);
			}
		}
		return onlyPublished;
	}

	void removeActualDuplicate(RelatedArticlesRequest input, List<Article> listOfArticles) {
		if (input.getUuid() != null) {
            Article actualArticle = articleService.findByUUID(input.getUuid());
            for (Iterator<Article> iter = listOfArticles.listIterator(); iter.hasNext();) {
	            Article article = iter.next();
	            if (article.equals(actualArticle)) {
	                iter.remove();
	            	break;
	            }
            }
        }
	}
	
	List<Article> getArticlesFromCategory (String categoryName) throws DataNotFoundException {
		List<String> categories = new ArrayList<String>(); 
        categories.add(categoryName);
        	
        GetDateBefore gdb = new GetDateBefore();
        Date dateFrom = gdb.getDateWithMonthsBefore(6);
        Date dateTo = new Date();
        
        List<Article> listOfArticles = articleService.filterByDateCategories(dateFrom, dateTo, categories);
        if (listOfArticles == null) {
			throw new DataNotFoundException("No articles in category");
		}
        return listOfArticles;
	}
	
	List<Map.Entry<Integer, Double>> getSortedByValueMap(List<Double> relatedList) {
		Map<Integer, Double> map = new HashMap<>();
	    for (int m = 0; m < relatedList.size(); m++) {
	        map.put(m, relatedList.get(m));
	    }
	    List<Map.Entry<Integer, Double>> sorted = SortMap.entriesSortedByValues(map);
	    return sorted;
	}
	
	List<Article> getTopRelated(List<Double>relatedList, List<Map.Entry<Integer, Double>> srt, List<Article> listOfArticles) {
		List<Article> topRelatedArticles = new ArrayList<Article>();
		int maxOfRelated = 20;
        if (relatedList.size() < 20) {
			maxOfRelated = relatedList.size();
		}

        for (int f = 0; f < maxOfRelated; f++) {            
        	topRelatedArticles.add(listOfArticles.get(srt.get(f).getKey()));
        }
        topRelatedArticles.sort((u1,u2) -> u2.getUpdatedAt().compareTo(u1.getUpdatedAt()));
        return topRelatedArticles;
	}
	
	double getCoefficient(String actualFullText, List<Article> listOfArticles, int j) {
		String s1 = actualFullText;
		s1 = HtmlToString.removeTags(s1);
		String s2 = listOfArticles.get(j).getFullText();
		s2 = HtmlToString.removeTags(s2);

		return CalculateRelated.diceCoefficient(s1, s2);
	}
	
	List<Article> calcAndGetTopRelated(List<Article> listOfArticles, String actualFullText) {
		List<Double> relatedList = new ArrayList<Double>();
		List<Article> topRelatedArticles = new ArrayList<Article>();
		for (int j = 0; j < listOfArticles.size(); j++) {

            double coeff = getCoefficient(actualFullText, listOfArticles, j);
            relatedList.add(coeff);
			
            if (j == listOfArticles.size() - 1) {
				List<Map.Entry<Integer, Double>> srt = getSortedByValueMap(relatedList);
                topRelatedArticles = getTopRelated(relatedList, srt,  listOfArticles);
			}
        }
		return topRelatedArticles;
	}
	
}
