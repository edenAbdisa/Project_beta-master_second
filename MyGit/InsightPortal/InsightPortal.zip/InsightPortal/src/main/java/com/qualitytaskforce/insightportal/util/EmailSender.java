package com.qualitytaskforce.insightportal.util;

public interface EmailSender {
    void sendEmail(String from, String to, String subject, String content);
}
