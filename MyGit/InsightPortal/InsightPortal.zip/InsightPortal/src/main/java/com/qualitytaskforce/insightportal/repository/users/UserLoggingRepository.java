package com.qualitytaskforce.insightportal.repository.users;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLogging;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserLoggingRepository extends JpaRepository<UserLogging, Long> {
	
	List<UserLogging> findByUser(User user);
}
