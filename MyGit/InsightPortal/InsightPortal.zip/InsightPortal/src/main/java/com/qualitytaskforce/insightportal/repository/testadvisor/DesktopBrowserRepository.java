package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.DesktopBrowser;

public interface DesktopBrowserRepository extends JpaRepository<DesktopBrowser, Long> {

	@Query(value = "SELECT ta_ms_desktop_browsers.uuid, ta_oss.name AS os_name, ta_oss.version AS os_version, ta_browsers.name AS browser_name, "
				+ "ta_browsers.version AS browser_version, marketpenetration AS marketpen "
				+ "FROM ta_ms_desktop_browsers "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_desktop_browsers.osuuid "
				+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_desktop_browsers.browseruuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_desktop_browsers.countryuuid "
				+ "WHERE ta_countries.code = :code "
				+ "AND ta_ms_desktop_browsers.date = :date " 
				+ "ORDER BY marketpen DESC"
				, nativeQuery = true)
	List<DesktopBrowser> desktopBrowsers(@Param("code") String code, @Param("date") String date);

	@Query(value = "SELECT * FROM ( "
				+ "SELECT uuid_v4() AS uuid, ta_oss.name AS os_name, ta_oss.version AS os_version, "
				+ "ta_browsers.name AS browser_name, ta_browsers.version AS browser_version, "
				+ "(SUM(ta_ms_desktop_browsers.marketpenetration * ta_countries.desktop_users) / SUM(ta_countries.desktop_users)) AS marketpen "
				+ "FROM ta_ms_desktop_browsers "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_desktop_browsers.osuuid "
				+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_desktop_browsers.browseruuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_desktop_browsers.countryuuid "
				+ "WHERE ta_countries.uuid IN :countries "
				+ "AND ta_ms_desktop_browsers.date = :date "
				+ "GROUP BY os_name, os_version, browser_name, browser_version "
				+ "ORDER BY marketpen DESC "
				+ ") t WHERE marketpen > :threshold"
				, nativeQuery = true)
	List<DesktopBrowser> desktopBrowsersMultiple(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("threshold") float threshold);
}