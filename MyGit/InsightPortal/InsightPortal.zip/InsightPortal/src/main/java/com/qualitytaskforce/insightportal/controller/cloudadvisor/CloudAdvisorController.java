package com.qualitytaskforce.insightportal.controller.cloudadvisor;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.UnauthorizedException;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.repository.cloudadvisor.CloudAdvisorRepository;
import com.qualitytaskforce.insightportal.service.CloudAdvisorMobileService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.CloudAdvisorService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.Utilities;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(value = "/cloudadvisor")
public class CloudAdvisorController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CloudAdvisorController.class);

    @Autowired
    private CloudAdvisorMobileService cloudAdvisorMobileService;

    @Autowired
    private Utilities utilities;


    @Autowired
    private CloudAdvisorService cloudAdvisorService;

    @Autowired
    private CloudAdvisorRepository cloudAdvisorRepository;
    

    @GetMapping(value = "/mobileoss")
    public ResponseEntity<List<String>> getMobileOss() throws DataNotFoundException {
        return new ResponseEntity<List<String>>(cloudAdvisorMobileService.findMobileOSs(), HttpStatus.OK);
    }

    @GetMapping(value = "/mobilebrowsers")
    public ResponseEntity<List<String>> getMobileBrowsers() throws DataNotFoundException {
        return new ResponseEntity<>(cloudAdvisorMobileService.findMobileBrowsers(), HttpStatus.OK);
    }

    /**
     * A method to get the max slot number of an already existing cloud advisor
     *
     * @param request an object of the http request required to get the logged in principal
     * @return the number of max slots of the specific company
     * @throws UnauthorizedException if the user is either not logged in, or is not from the company provided
     */
    @GetMapping(value = "/maxslots")
    public ResponseEntity<Integer> fetchMaxSizeOfSlots(HttpServletRequest request) throws UnauthorizedException, DataNotFoundException {

        /* Expectation: return max slots size from DB
         * Check if list not 0. If so, throws DataNotFoundException
         * Probably find max slots by company of user company.
         */

        CloudAdvisor cloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));

        int maxslot = cloudAdvisor.getMaxSlots();

        // return maxslots
        return new ResponseEntity<>(maxslot, HttpStatus.OK);
    }

    /**
     * A Method to Set the max slot number of an already existing cloud advisor
     *
     * @param payload JSON data required to set/modify max slots of a company - includes max_slots
     * @param request an object of the http request required to get the logged in principal
     * @return the modified cloud advisor object
     * @throws InvalidParameterException if the number of slots provided is less than the already existing max-slots number
     * @throws DataNotFoundException     if a cloud advisor with the provided company name does not exist
     * @throws UnauthorizedException     if the user is either not logged in, or is not from the company provided
     */
    @PostMapping(value = "/setmaxslots")
    public ResponseEntity<CloudAdvisor> setMaxSlots(@RequestBody Map<String, Object> payload, HttpServletRequest request) throws InvalidParameterException, DataNotFoundException, UnauthorizedException {
        /*
          payload =
          {
          	"max_slots" : int,
          }
         */

        //

        CloudAdvisor cloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));
        verifyCompanyExistance(cloudAdvisor);

        int maxSlots = (int) payload.get("max_slots");
        verifyMaxSlots(maxSlots);

        if (cloudAdvisor.getMaxSlots() != 0) {
            if (maxSlots < cloudAdvisor.getMaxSlots()) {
                throw new InvalidParameterException("The number of slots provided can't be less than the already existing maximum number of slot.");
            }
        }

        // Doing the Edits //
        cloudAdvisor.setMaxSlots(maxSlots);

        // Save New Cloud Advisor and Send Response //
        return new ResponseEntity<>(cloudAdvisorRepository.save(cloudAdvisor), HttpStatus.OK);

        // set the max slots for a company
        // Verify requested slot value is <= 128
        // Verify requested slot value is >= 0
        // Verify if the company has already set the max slots, requested slot value is >= existing value
        // Verify the user making the request belongs to the company
    }

    /**
     * A Method to Create a new Cloud Advisor
     *
     * @param payload JSON data required to create new cloud advisor - includes coverage, max-slots, browser_rules, device_rules
     * @param request an object of the http request required to get the logged in principal
     * @return the newly created cloud advisor object
     * @throws InvalidParameterException if the company name is not provided or is empty,
     *                                   if coverage provided is negative or larger than 100,
     *                                   if max-slots provided is negative or larger than 128,
     *                                   if a cloud advisor already exists by the provided company_name,
     *                                   if browser_rules provided cannot parse into the provided enum,
     *                                   if device_rules provided cannot parse into the provided enum
     * @throws UnauthorizedException     if the user is either not logged in, or is not from the company provided
     */
    @PostMapping(value = "/create")
    public ResponseEntity<CloudAdvisor> createCloudAdvisor(@RequestBody Map<String, Object> payload, HttpServletRequest request) throws InvalidParameterException, UnauthorizedException, DataNotFoundException {
        /*
          payload =
           {
               "coverage" : int,
               "max_slots" : int,
          	   "browser_rules": string,
          	   "device_rules": string
           }
         */


        // Doing Verifications //

        String companyName = utilities.getUserCompanyName(request);
        
        verifyCoverage(companyName.length() <= 0, companyName.length() >= 50, "Invalid input length for Company Name.");

        int coverage = (int) payload.get("coverage");
        verifyCoverage(coverage < 0, coverage > 100, "Invalid input value for coverage.");

        int maxSlots = (int) payload.get("max_slots");
        verifyMaxSlots(maxSlots);

        checkCompanyExistance(companyName);

        CloudAdvisor.BrowserRules browserRules = CloudAdvisor.BrowserRules.valueOf(payload.get("browser_rules").toString());
        CloudAdvisor.DeviceRules deviceRules = CloudAdvisor.DeviceRules.valueOf(payload.get("device_rules").toString());

        // Create new CloudAdvisor //
        CloudAdvisor cloudAdvisor = new CloudAdvisor(coverage, maxSlots, companyName, browserRules, deviceRules);

        // Save New Cloud Advisor and Send Response //
        return new ResponseEntity<>(cloudAdvisorRepository.save(cloudAdvisor), HttpStatus.CREATED);
    }


    /**
     * A Method to update an existing Cloud Advisor
     *
     * @param payload JSON data required to create new cloud advisor - includes company_name, coverage, browser_rules, device_rules
     * @param request an object of the http request required to get the logged in principal
     * @return the modified cloud advisor object
     * @throws InvalidParameterException if coverage provided is negative or larger than 100,
     *                                   if browser_rules provided cannot parse into the provided enum,
     *                                   if device_rules provided cannot parse into the provided enum
     * @throws DataNotFoundException     if a cloud advisor with the provided company name does not exist
     * @throws UnauthorizedException     if the user is either not logged in, or is not from the company provided
     */
    @PostMapping(value = "/edit")
    public ResponseEntity<CloudAdvisor> updateCloudAdvisor(@RequestBody Map<String, Object> payload, HttpServletRequest request) throws InvalidParameterException, DataNotFoundException, UnauthorizedException {
        /*
          payload =
          {
           "coverage" : int,
           "browser_rules": string,
           "device_rules": string
          }
         */
        // Retrieve the existing Cloud Advisor //
        CloudAdvisor existingCloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));

        // Doing Verifications //
        int coverage = (int) payload.get("coverage");
        verifyCoverage(coverage < 0, coverage > 100, "Invalid input value for coverage.");

        CloudAdvisor.BrowserRules browserRules = CloudAdvisor.BrowserRules.valueOf(payload.get("browser_rules").toString());
        CloudAdvisor.DeviceRules deviceRules = CloudAdvisor.DeviceRules.valueOf(payload.get("device_rules").toString());


        // Make Modifications
        existingCloudAdvisor.setCoverage(coverage);
        existingCloudAdvisor.setBrowserRules(browserRules);
        existingCloudAdvisor.setDeviceRules(deviceRules);

        // Save New Cloud Advisor and Send Response //
        return new ResponseEntity<>(cloudAdvisorRepository.save(existingCloudAdvisor), HttpStatus.OK);
    }


    /**
     * A method to fetch all cloud advisor objects
     *
     * @return a list of all cloud advisor objects
     * @throws DataNotFoundException if there are no cloud advisors found on the database
     */
    @GetMapping(value = "/find-all")
    public ResponseEntity<List<CloudAdvisor>> fetchAll() throws DataNotFoundException {

        // Retrieve the existing Cloud Advisor //
        List<CloudAdvisor> allCloudAdvisors = cloudAdvisorRepository.findAll();

        if (allCloudAdvisors.isEmpty()) {
            throw new DataNotFoundException("No Cloud Advisors Available.");
        }

        // Send Response //
        return new ResponseEntity<>(allCloudAdvisors, HttpStatus.OK);
    }


    /**
     * A method to fetch a specific cloud advisor matching a company name
     *
     * @param request     an object of the http request required to get the logged in principal
     * @return a specific cloud advisor object with a matching company name as the one provided
     * @throws DataNotFoundException if a cloud advisor with the provided company name does not exist
     * @throws UnauthorizedException if the user is either not logged in, or is not from the company provided
     */
    @GetMapping
    public ResponseEntity<CloudAdvisor> fetchByCompanyName(HttpServletRequest request) throws DataNotFoundException, UnauthorizedException {

        // Retrieve the existing Cloud Advisor //
        CloudAdvisor existingCloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));

        verifyCompanyExistance(existingCloudAdvisor);

        if (existingCloudAdvisor == null) {
            throw new DataNotFoundException("No Company found by that name.");
        }

//        Utilities.authenticateUser(request, existingCloudAdvisor.getCompanyName());

        // Send Response //
        return new ResponseEntity<>(existingCloudAdvisor, HttpStatus.OK);
    }


    /**
     * A method to verify that a cloud advisor exists with a company name
     *
     * @param existingCloudAdvisor the cloud advisor oject to be verified if it exists or not
     * @throws DataNotFoundException if a cloud advisor with the provided company name does not exist
     */
    private void verifyCompanyExistance(CloudAdvisor existingCloudAdvisor) throws DataNotFoundException {
        if (existingCloudAdvisor == null) {
            throw new DataNotFoundException("No company by that name exists");
        }
    }

    /**
     * A method to validate that a coverage is not negative or larger than 100
     *
     * @param b  boolean value of whether the coverage is negative or not
     * @param b2 boolean value of whether the coverage is larger than 100
     * @param s  Exception message
     * @throws InvalidParameterException if coverage provided is negative or larger than 100
     */
    private void verifyCoverage(boolean b, boolean b2, String s) throws InvalidParameterException {
        if (b || b2) {
            throw new InvalidParameterException(s);
        }
    }

    /**
     * A method to check if max_slot provided is not negative or larger than 128
     *
     * @param maxSlots the number of slots to be verified
     * @throws InvalidParameterException if max-slots provided is negative or larger than 128
     */
    private void verifyMaxSlots(int maxSlots) throws InvalidParameterException {
        if (maxSlots >= 128) {
            throw new InvalidParameterException("There can't be more than 128 slots.");
        }
        if (maxSlots <= 0) {
            throw new InvalidParameterException("The maximum number of slots needs to be positive.");
        }
    }
    
    /**
     * Method to check if a company has no cloud advisor before creating one
     * 
     * @param companyName the name of the company whose existence is to be checked 
     * @throws InvalidParameterException if the company already has a cloud advisor
     */
    public void checkCompanyExistance(String companyName) throws InvalidParameterException {
		CloudAdvisor cloudAdvisorByCompanyName = cloudAdvisorRepository.findByCompanyName(companyName);
		if (cloudAdvisorByCompanyName != null) {
			throw new InvalidParameterException("A Cloud Advisor by that Company Name already exists.");
        }
	}


}
