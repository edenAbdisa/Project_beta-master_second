package com.qualitytaskforce.insightportal.model.users;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "password_resets")
public class PasswordResets {
		
	@Id
	@JsonProperty(value = "id")
	@Column(name = "id")
	private int id;
	
	@JsonProperty(value = "email")
	@Column(name = "email")
	private String email;
	
	@JsonProperty(value = "reset_code")
	@Column(name = "reset_code")
	private String resetcode;
	
	@JsonProperty(value = "token")
	@Column(name = "token")
	private String token;
	
	@JsonProperty(value = "is_active")
	@Column(name = "is_active")
	private boolean isActive;
	
	@JsonProperty(value = "created_at")
	@Column(name = "created_at")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;
	
	public PasswordResets() {
	}
	
	public PasswordResets(String email, String resetcode, String token, boolean isActive, Date createdAt) {
		this.email = email;
		this.resetcode = resetcode;
		this.token = token;
		this.isActive = isActive;
		this.createdAt = createdAt;
	}

	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getResetcode() {
		return resetcode;
	}

	public void setResetcode(String resetcode) {
		this.resetcode = resetcode;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	
}
