package com.qualitytaskforce.insightportal.model.util;

import com.qualitytaskforce.insightportal.model.users.User;

public class UserJoomlaCredentials extends User {

    private String oldPassword;

    public String getOldPassword() {
        return this.oldPassword;
    }

}
