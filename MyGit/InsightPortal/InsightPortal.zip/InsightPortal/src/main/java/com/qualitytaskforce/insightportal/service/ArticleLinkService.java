package com.qualitytaskforce.insightportal.service;

/* Ok, so this class is only going to be used once to change old links in articles to new links */

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.SefURL;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.repository.SefURLRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ArticleLinkService {

    @Autowired
    ArticleRepository articleRepository;

    @Autowired
    SefURLRepository sefURLRepository;


    public void scanAllArticles() {
        List<Article> allArticles = articleRepository.findAll();
        List<Article> articlesWithLinks = allArticles.stream().filter(a -> containsSefUrl(a)).collect(Collectors.toList());
        articlesWithLinks.forEach(a -> removeFromUrlAndUpdate(a));
    }

    private boolean containsSefUrl(Article article) {
        List<SefURL> allSefUrls = sefURLRepository.findAll();
        List<SefURL> articleSefUrls = allSefUrls.stream().filter(s -> article.getFullText().
                contains(s.getSefUrl())).
                collect(Collectors.toList());

        if (articleSefUrls.isEmpty()) {
            return false;
        }

        return true;
    }

    private void removeFromUrlAndUpdate(Article article) {
        /* Example patterns to be removed from links:
         *
          * (1) "/os-news/123-"
          * (2) "index.php/os-news/4567-"
          *
          * */
        String patternToRemove = "\"(.{0,40}/[0-9]{3,4}-|index.php/.{0,30}/[0-9]{3,4}-)";

        String fulltext = article.getFullText();
        String newFulltext = fulltext.replaceAll(patternToRemove, "\"");
        if (!newFulltext.equals(fulltext)) {
            article.setFullText(newFulltext);
        }
        articleRepository.save(article);
    }
}
