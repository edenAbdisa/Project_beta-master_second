package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ta_devices")
public class DeviceWithUuid {
	
	@Id
	@Column(name = "uuid")
	private UUID uuid;

	@Column(name = "brand")
	private String brand;

	@Column(name = "model")
	private String model;

	@Column(name="img_link") 
	private String imageLink;
	
	public String getImageLink() {
		return imageLink;
	}

	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}

	public DeviceWithUuid () {
	}

	public DeviceWithUuid(UUID uuid, String brand, String model,String imageLink) {
		this.uuid = uuid;
		this.brand = brand;
		this.model = model;
		this.imageLink=imageLink;
	}

	public UUID getUuid() {
		return this.uuid;
	}
	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}
}