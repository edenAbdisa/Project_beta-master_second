package com.qualitytaskforce.insightportal.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.qualitytaskforce.insightportal.model.users.User;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "newsletter")
public class Newsletter implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "subject", nullable = false, length = 30)
	private String subject;
	
	@Column(name = "content", nullable = false, length = 16777215)
	private String content;
	
	@Column(name = "from_email", nullable = false)
	private String fromEmail;
	
	@Column(name = "published", nullable = false)
	private boolean published;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "publish_date", nullable = false, length = 19)
	private Date publishDate;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by", nullable = false)
	private User userByCreatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false, length = 19)
	private Date createdAt;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "check_in_by")
	private User userByCheckInBy;
	
	public Newsletter() {
	}

	public Newsletter(UUID uuid, User userByCreatedBy, String subject, String content, String fromEmail,
			boolean published, Date publishDate, Date createdAt) {
		this.uuid = uuid;
		this.userByCreatedBy = userByCreatedBy;
		this.subject = subject;
		this.content = content;
		this.fromEmail = fromEmail;
		this.published = published;
		this.publishDate = publishDate;
		this.createdAt = createdAt;		
	}

	public Newsletter(UUID uuid, User userByCreatedBy, User userByCheckInBy, String subject, String content,
			String fromEmail, boolean published, Date publishDate, Date createdAt) {
		this.uuid = uuid;
		this.userByCreatedBy = userByCreatedBy;
		this.userByCheckInBy = userByCheckInBy;
		this.subject = subject;
		this.content = content;
		this.fromEmail = fromEmail;
		this.published = published;
		this.publishDate = publishDate;
		this.createdAt = createdAt;		
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public User getUserByCreatedBy() {
		return this.userByCreatedBy;
	}

	public void setUserByCreatedBy(User userByCreatedBy) {
		this.userByCreatedBy = userByCreatedBy;
	}

	public User getUserByCheckInBy() {
		return this.userByCheckInBy;
	}

	public void setUserByCheckInBy(User userByCheckInBy) {
		this.userByCheckInBy = userByCheckInBy;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getFromEmail() {
		return this.fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public boolean isPublished() {
		return this.published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	public Date getPublishDate() {
		return this.publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}	
}
