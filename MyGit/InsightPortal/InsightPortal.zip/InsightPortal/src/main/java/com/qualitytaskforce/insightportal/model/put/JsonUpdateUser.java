package com.qualitytaskforce.insightportal.model.put;

import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.qualitytaskforce.insightportal.annotation.EqualConstraint;

import org.hibernate.validator.constraints.Email;

@EqualConstraint(message = "Pasword isn't equal", firstFieldName = "password", secondFieldName = "confirmPassword")
public class JsonUpdateUser {

    @NotNull()
    private static UUID uuid;
    // TODO validate

    @Size(min = 3, max = 90)
    @NotNull()
    @JsonProperty("name")
    private String name;

    @Size(min = 3, max = 90)
    @NotNull()
    @JsonProperty("surname")
    private String surname;

    @Email()
    @NotNull()
    @JsonProperty("email")
    private String email;

    @Email()
    @NotNull()
    @JsonProperty("confirmEmail")
    private String confirmEmail;

    @NotNull()
    @JsonProperty("password")
    private String password;

    @NotNull()
    private String confirmPassword;

    @NotNull()
    @JsonProperty("user_level")
    private String userLevel;

    @NotNull()
    @JsonProperty("api_key_limit")
    private String apiKeyLimit;
    
    @Size(min = 3)
    @NotNull()
    @JsonProperty("company")
    private String company;
    
    @JsonProperty("phone_number")
    private String phoneNumber;
    
    @JsonProperty("expire_at")
    private String expireAt;


    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @JsonProperty("confirm_email")
    public String getConfirmEmail() {
        return confirmEmail;
    }

    @JsonProperty("confirm_email")
    public void setConfirmEmail(String confirmEmail) {
        this.confirmEmail = confirmEmail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @JsonProperty("confirm_password")
    public String getConfirmPassword() {
        return confirmPassword;
    }

    @JsonProperty("confirm_password")
    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getApiKeyLimit() {
        return apiKeyLimit;
    }

    public void setApiKeyLimit(String apiKeyLimit) {
        this.apiKeyLimit = apiKeyLimit;
    }

    // TODO check if required to input to string name and surname
    @Override
    public String toString() {
        return "User [name=" + name + ", surname=" + surname + ", email=" + email + ", confirmEmail=" + confirmEmail
                + ", password=" + password + ", confirmPassword=" + confirmPassword
                + "]";
    }

    public boolean checkRequiredNull() {
        if (email == null || confirmEmail == null || password == null || confirmPassword == null) {
            return false;
        }
        return true;
    }

    public boolean comparePasswords() {
        if (password.equals(confirmPassword)) {
            return true;
        }
        return false;
    }

    public String getUserLevel() {
        return userLevel;
    }

    public void setUserLevel(String userLevel) {
        this.userLevel = userLevel;
    }

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getExpireAt() {
		return expireAt;
	}

	public void setExpireAt(String expireAt) {
		this.expireAt = expireAt;
	}
}