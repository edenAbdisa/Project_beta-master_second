package com.qualitytaskforce.insightportal.controller.robots;

import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Profile("staging")
@RestController
public class StagingRobots {	
	private HttpHeaders headers = new HttpHeaders();

	/**
	 * Path for serving robots.txt
	 */
	@RequestMapping(value = "/robots.txt", method = RequestMethod.GET)
	public ResponseEntity<?> robots() {
		headers.setContentType(MediaType.TEXT_PLAIN);
		String robots = "User-agent: * \r\n" +
						"Disallow: /";
		return new ResponseEntity<String>(robots, headers, HttpStatus.OK);
	}
}