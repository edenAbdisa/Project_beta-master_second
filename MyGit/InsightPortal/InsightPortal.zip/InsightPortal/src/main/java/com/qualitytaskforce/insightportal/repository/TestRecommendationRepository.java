package com.qualitytaskforce.insightportal.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import com.qualitytaskforce.insightportal.model.TestRecommendation;

public interface TestRecommendationRepository extends JpaRepository<TestRecommendation, Long> {
	
	TestRecommendation findByUuid(UUID uuid);
}