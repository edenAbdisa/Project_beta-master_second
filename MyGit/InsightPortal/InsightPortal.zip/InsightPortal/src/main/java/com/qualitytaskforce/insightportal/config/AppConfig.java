package com.qualitytaskforce.insightportal.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.qualitytaskforce.insightportal.events.AuthenticationFailureEventListener;
import com.qualitytaskforce.insightportal.events.AuthenticationSuccessEventListener;
import com.qualitytaskforce.insightportal.service.LoginAttemptService;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;

@Configuration
public class AppConfig extends WebMvcConfigurerAdapter {

    @Autowired
    LoginAttemptService loginAttemptService;
    
    @Autowired
    UserService userService;
    
    @Autowired
    UserLevelService userLevelService;
    
    @Bean
    public ApplicationListener loginSuccessListener(){
        return new AuthenticationSuccessEventListener(loginAttemptService);
    }

    @Bean
    public ApplicationListener loginFailureListener(){
        return new AuthenticationFailureEventListener();
    }
    @Bean
    public RequestContextListener requestContextListener(){
        return new RequestContextListener();
    }    
}