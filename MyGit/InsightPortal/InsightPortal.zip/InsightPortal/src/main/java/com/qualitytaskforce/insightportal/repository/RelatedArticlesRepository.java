package com.qualitytaskforce.insightportal.repository;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.RelatedArticles;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RelatedArticlesRepository extends JpaRepository<RelatedArticles, Long>{
	
	List<RelatedArticles> findByArticleByOriginalArticleId(Article articleByOriginalArticleId);
}