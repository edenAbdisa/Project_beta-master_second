package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.List;

public class Response<T> {

	private List<T> inCoverage;

	private List<T> outOfCoverage;

	public Response () {
	}

	public Response(List<T> inCoverage, List<T> outOfCoverage) {
		this.inCoverage = inCoverage;
		this.outOfCoverage = outOfCoverage;
	}

	public List<T> getInCoverage() {
		return this.inCoverage;
	}

	public void setInCoverage(List<T> inCoverage) {
		this.inCoverage = inCoverage;
	}

	public List<T> getOutOfCoverage() {
		return this.outOfCoverage;
	}

	public void setOutOfCoverage(List<T> outOfCoverage) {
		this.outOfCoverage = outOfCoverage;
	}
}