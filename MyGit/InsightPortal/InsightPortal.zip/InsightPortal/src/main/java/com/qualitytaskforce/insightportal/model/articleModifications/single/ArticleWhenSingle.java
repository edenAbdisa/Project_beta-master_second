package com.qualitytaskforce.insightportal.model.articleModifications.single;

import java.util.List;
import java.util.UUID;

public class ArticleWhenSingle {	
	
	String title;
	String summaryText;
	String editorName;
	String editorSurname;
	String dateOfPublished;
	int readTime;
	int impactRating;
	List<ArticleUpdateWhenSingle> articleUpdates;
	String testRecommendation;
	String fullText;
	UUID richcardId;
	String richcardType;
	String category;
	String subcategory;

		public String getEditorName() {
		return editorName;
	}

	public void setEditorName(String editorName) {
		this.editorName = editorName;
	}

	public String getEditorSurname() {
		return editorSurname;
	}

	public void setEditorSurname(String editorSurname) {
		this.editorSurname = editorSurname;
	}
	
	public String getDateOfPublished() {
		return dateOfPublished;
	}

	public void setDateOfPublished(String dateOfPublished) {
		this.dateOfPublished = dateOfPublished;
	}

	public int getReadTime() {
		return readTime;
	}

	public void setReadTime(int readTime) {
		this.readTime = readTime;
	}
		
	public int getImpactRating() {
		return impactRating;
	}

	public void setImpactRating(int impactRating) {
		this.impactRating = impactRating;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummaryText() {
		return summaryText;
	}

	public void setSummaryText(String summaryText) {
		this.summaryText = summaryText;
	}

	public List<ArticleUpdateWhenSingle> getArticleUpdates() {
		return articleUpdates;
	}

	public void setArticleUpdates(List<ArticleUpdateWhenSingle> articleUpdates) {
		this.articleUpdates = articleUpdates;
	}

	public String getTestRecommendation() {
		return testRecommendation;
	}

	public void setTestRecommendation(String testRecommendation) {
		this.testRecommendation = testRecommendation;
	}

	public String getFullText() {
		return fullText;
	}

	public void setFullText(String fullText) {
		this.fullText = fullText;
	}

	public UUID getRichcardId() {
		return richcardId;
	}

	public void setRichcardId(UUID richcardId) {
		this.richcardId = richcardId;
	}

	public String getRichcardType() {
		return richcardType;
	}

	public void setRichcardType(String richcardType) {
		this.richcardType = richcardType;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSubcategory() {
		return subcategory;
	}

	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}

}
