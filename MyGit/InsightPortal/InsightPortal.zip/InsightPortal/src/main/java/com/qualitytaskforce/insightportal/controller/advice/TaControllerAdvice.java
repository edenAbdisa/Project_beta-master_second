package com.qualitytaskforce.insightportal.controller.advice;

import static org.springframework.http.HttpStatus.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.qualitytaskforce.insightportal.model.util.ErrorResponse;
import com.qualitytaskforce.insightportal.error.*;

@ControllerAdvice(basePackages = {"com.qualitytaskforce.insightportal.controller"})
public class TaControllerAdvice {

	private static Logger LOGGER = LoggerFactory.getLogger(TaControllerAdvice.class);
	private static HttpHeaders errorHeaders;
	static {
		errorHeaders = new HttpHeaders();
		errorHeaders.setContentType(MediaType.APPLICATION_JSON_UTF8);
	}

	@ExceptionHandler({ Exception.class	})
	public ResponseEntity<ErrorResponse> handleError(Exception e) {
		return buildDefaultErrorResponse(INTERNAL_SERVER_ERROR, e);
	}

	@ExceptionHandler({ 
		DataNotFoundException.class, HttpRequestMethodNotSupportedException.class, 
		DeleteEntityException.class, SaveEntityException.class
		})
	public ResponseEntity<ErrorResponse> dataNotFoundException(Exception e) {
		return buildDefaultErrorResponse(NOT_FOUND, e);
	}

	@ExceptionHandler({ InvalidParameterException.class, IllegalArgumentException.class	})
	public ResponseEntity<ErrorResponse> invalidParameterException(Exception e) {
		return buildDefaultErrorResponse(BAD_REQUEST, e);
	}

	@ExceptionHandler({ InvalidParameterFormatException.class })
	public ResponseEntity<ErrorResponse> invalidParamterFormatException(Exception e) {
		return buildDefaultErrorResponse(UNPROCESSABLE_ENTITY, e);
	}
	
	private ResponseEntity<ErrorResponse> buildDefaultErrorResponse(HttpStatus httpStatus, Exception e) {
		String errorMessage = e.getMessage();
		LOGGER.error(errorMessage, e);
		ErrorResponse er = new ErrorResponse(httpStatus, errorMessage);
		return new ResponseEntity<ErrorResponse>(er, errorHeaders, httpStatus);
	}
} 