package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Country {
	
	@Id
	@Column(name = "uuid")
	private UUID uuid;

	@Column(name = "code")
	private String code;

	@Column(name = "name")
	private String name;

	@Column(name = "region")
	private String region;

	@Column(name = "mobile_users")
	private int mobileUsers;

	@Column(name = "desktop_users")
	private int desktopUsers;

	public Country () {
	}

	public Country(UUID uuid, String code, String name, String region, int mobileUsers, int desktopUsers) {
		this.uuid = uuid;
		this.code = code;
		this.name = name;
		this.region = region;
		this.mobileUsers = mobileUsers;
		this.desktopUsers = desktopUsers;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRegion() {
		return this.region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public int getMobileUsers() {
		return this.mobileUsers;
	}

	public void setMobileUsers(int mobileUsers) {
		this.mobileUsers = mobileUsers;
	}

	public int getDesktopUsers() {
		return this.desktopUsers;
	}

	public void setDesktopUsers(int desktopUsers) {
		this.desktopUsers = desktopUsers;
	}

}