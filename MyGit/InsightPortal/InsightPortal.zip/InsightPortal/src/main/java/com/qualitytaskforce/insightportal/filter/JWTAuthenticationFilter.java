package com.qualitytaskforce.insightportal.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.util.RequestDetails;
import com.qualitytaskforce.insightportal.model.util.UserCredentials;
import com.qualitytaskforce.insightportal.model.util.UserLoggingAction;
import com.qualitytaskforce.insightportal.service.users.UserLoggingService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class JWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {

    private UserService userService;

    private AuthenticationManager authenticationManager;

    private UserLoggingService userLoggingService;

    public JWTAuthenticationFilter(AuthenticationManager authenticationManager) {
        this.authenticationManager = authenticationManager;
    }

    /*
     * Parse user's email and password and issue them to AuthenticationManager
     */

    @Override
    public Authentication attemptAuthentication(HttpServletRequest req, HttpServletResponse res)
            throws AuthenticationCredentialsNotFoundException {
        try {
            UserCredentials userCredentials = new ObjectMapper().readValue(req.getInputStream(), UserCredentials.class);

            /* No need to check if user is null as it is already taken care of when verifying the token */
            UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(userCredentials.getEmail(), userCredentials.getPassword(), new ArrayList<>());
//            token.setDetails(userCredentials.isKeptLoggedIn());
//            token.setDetails(req.getRemoteAddr());

            token.setDetails(new RequestDetails(userCredentials.isKeptLoggedIn(), req.getRemoteAddr()));
            req.setAttribute("login", userCredentials.getEmail());

            return authenticationManager.authenticate(token);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /* Generate a JWT for authenticated user */

    @Override
    protected void successfulAuthentication(HttpServletRequest req, HttpServletResponse res, FilterChain chain,
                                            Authentication auth) throws IOException {

        /* Retrieve user login and check if user wants to be logged in for an extended period of time */
        String login = auth.getPrincipal().toString();
        RequestDetails requestDetails = (RequestDetails) auth.getDetails();
        boolean keptLoggedIn = requestDetails.isLoggedIn();

        manualAutowire(req);
        List<User> user = userService.findByEmail(login);

        String ip = userLoggingService.getClientIP(req);

        /* Insert longer expiration time if user wants to be kept logged in */
        long expirationTime = keptLoggedIn ? JWTConfig.EXTENDED_EXPIRATION_TIME : JWTConfig.EXPIRATION_TIME;

        String userLevel = user.get(0).getUserLevel().getName();
        String userLevelValue = JWTConfig.getUserLevelValue(userLevel);
        String nameAndSurname = user.get(0).getNameAndSurname();

        /* Create JSON Web Token */
        String token = JWT.create()
                .withIssuer(JWTConfig.ISSUER)
//                .withClaim("userName", user.get(0).getName())
                .withSubject(login)
                .withClaim("userLevel", userLevelValue)
                .withClaim("name", nameAndSurname)
                .withExpiresAt(new Date(System.currentTimeMillis() + expirationTime))
                .sign(Algorithm.HMAC256(JWTConfig.SECRET));

        /* Add generated JWT to response Header and expose this header to the browser */
        res.addHeader(JWTConfig.HEADER_STRING, JWTConfig.TOKEN_PREFIX + token);
        res.setHeader("Access-Control-Expose-Headers", JWTConfig.HEADER_STRING);
        res.setHeader("Access-Control-Allow-Headers", JWTConfig.HEADER_STRING);
        res.setStatus(200);
        
        // Update last visit field
        user.get(0).setLastVisit(new Date());        
        userService.save(user.get(0));

        userLoggingService.saveUserLog(login, ip, UserLoggingAction.LOGIN);
    }

    private void manualAutowire(HttpServletRequest request) {
        if (userService == null) {
            ServletContext servletContext = request.getServletContext();
            WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
            userService = webApplicationContext.getBean(UserService.class);
        }

        if (userLoggingService == null) {
            ServletContext servletContext = request.getServletContext();
            WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
            userLoggingService = webApplicationContext.getBean(UserLoggingService.class);
        }
    }    
}