package com.qualitytaskforce.insightportal.service.users.backoffice;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;

import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.Team;
import com.qualitytaskforce.insightportal.model.post.JsonUser;
import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.ApiLimit;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.model.util.EmailValidator;
import com.qualitytaskforce.insightportal.service.EmailServiceImpl;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import com.qualitytaskforce.insightportal.service.users.ApiKeyService;
import com.qualitytaskforce.insightportal.service.users.ApiLimitService;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;
import com.qualitytaskforce.insightportal.util.AddPrecisionTime;

@Service
public class UserServicePost {
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserLevelService userLevelService;
	
	@Autowired
	UserTrialService userTrialService;
    
    @Autowired
 	private EmailServiceImpl emailService;
    
    @Autowired
    private ApiLimitService apiLimitService;

    @Autowired
    private ApiKeyService apiKeyService;
    
    @Autowired
	private TemplateEngine templateEngine;
	
	public void create(JsonUser inputDetails, MessageUtil util, HttpServletRequest request, HttpServletResponse response) throws InvalidParameterException, InvalidParameterFormatException, ParseException {
		    
	    checkInputVars(inputDetails, util);
	    User user = createUserObject(inputDetails);
	    UserTrial userTrial = null;
	    if (inputDetails.getUserLevel().indexOf("Trial") > -1) {
	    	String password = inputDetails.getPassword();
	    	userTrial = manageTrialUser(inputDetails, user, password, request, response);
	    } else {
	    	user.setUserTrial(null);
	    }
	    user.setUserTrial(userTrial);
	    userService.save(user);
	    manageApiLimitKey(inputDetails);
	}

	void checkInputVars (JsonUser inputDetails, MessageUtil util) throws InvalidParameterException, InvalidParameterFormatException {
		
		EmailValidator ev = new EmailValidator(inputDetails.getEmail());
		List<User> existingUser = userService.findByEmail(inputDetails.getEmail());

	    //Check to see if the json input is missing any variables
	    if (!inputDetails.checkRequiredNull()) {
	        throw new InvalidParameterException(util.getMessage("error.users.create.missing-input"));
		}
	    if (!inputDetails.comparePasswords()) {
	        throw new InvalidParameterFormatException(util.getMessage("error.users.create.password-mismatch"));
		}
	    if (!ev.validateEmail()) {
	        throw new InvalidParameterFormatException(util.getMessage("error.users.create.invalid-email"));
		}
	    if (!existingUser.isEmpty()) {
	        throw new InvalidParameterFormatException(util.getMessage("error.users.create.exists"));
		}
	    if (!inputDetails.compareEmails()) {
			throw new InvalidParameterFormatException(util.getMessage("error.users.create.email-mismatch"));
		}
	}
	
	User createUserObject (JsonUser inputDetails) {
		UUID uuidUser = UUID.randomUUID();
	    String name = inputDetails.getName();
	    String surname = inputDetails.getSurname();
	    String email = inputDetails.getEmail();
	    String password = BCrypt.hashpw(inputDetails.getPassword(), BCrypt.gensalt(10));
	    String phoneNumber = inputDetails.getPhoneNumber();
	    String company = inputDetails.getCompany();
	    UserLevel userLevel = userLevelService.findByName(inputDetails.getUserLevel()).get(0);
	    boolean activated = true;
	    boolean blocked = false;
	    short blockCount = 0;
	    Date lastBlockDate = null;
	    Date createdAt = new Date();
	    Date updatedAt = createdAt;
	    Date lastVisit = null;
	    Team teamId = null;

	    User user = new User(uuidUser, name, surname, email, password, company, userLevel, activated, blocked, blockCount, lastBlockDate, createdAt, updatedAt, lastVisit, teamId);
	    if (phoneNumber.length() > 0) {
			user.setPhoneNumber(phoneNumber);
		}
	    return user;
	}
	
	void sendEmailLocal (String token, User user, String password, HttpServletRequest request, HttpServletResponse response) {
		
		// sendActivationEmail;
		String emailTitle = "InsightPortal - Activate your InsightPortal account";
		String emailFrom = "contactus@insightportal.io";
		
		ServletContext ctx = request.getServletContext();
        WebContext context = new WebContext(request, response, ctx, request.getLocale());
        
        context.setVariable("userNameSurname", user.getNameAndSurname());
        context.setVariable("userPassword", password);
        context.setVariable("token", token);
        context.setVariable("host", "https://insightportal.io"); // set host address for link in email
        context.setVariable("automaticTrial", false);
        String body = this.templateEngine.process("VerificationEmail", context);
		// DEV
		// String devEmail = "";
		emailService.sendEmail(emailFrom, user.getEmail(), emailTitle, body);
	}
	
	UserTrial getUserTrialLocal (JsonUser inputDetails, User user, String token) throws ParseException {
		UserTrial userTrial = new UserTrial();
    	userTrial.setUser(user);
    	userTrial.setConfirmationToken(token);
    	userTrial.setSentTrialEmail(false);
    	Date expireAt = new SimpleDateFormat("yyyy-MM-dd").parse(inputDetails.getExpireAt());
    	AddPrecisionTime addPrecisionTime = new AddPrecisionTime();
    	Date correctExpireAt = addPrecisionTime.add(expireAt, user.getCreatedAt());
    	userTrial.setExpireAt(correctExpireAt);
    	return userTrial;
	}
	
	UserTrial manageTrialUser (JsonUser inputDetails, User user, String password, HttpServletRequest request, HttpServletResponse response) throws ParseException {
		String token = null;
    	if (inputDetails.getUserLevel().equals("ManualTrial")) {
    		// will activated after received activation email
    		user.setActivated(false);
    		token = userTrialService.generateVerificationToken();
    		sendEmailLocal(token, user, password, request, response);
    	}
    	UserTrial userTrial = getUserTrialLocal(inputDetails, user, token);
    	return userTrial;
	}
	
	void manageApiLimitKey (JsonUser inputDetails) {
		List<ApiLimit> apiTemp = apiLimitService.findByName(inputDetails.getApiKeyLimit());
	    ApiLimit apiLimit = apiTemp.get(0);

	    List<User> userTempList = userService.findByEmail(inputDetails.getEmail());
	    User userTemp = userTempList.get(0);

	    UUID uuidApiKey = UUID.randomUUID();
	    ApiKey apiKey = new ApiKey(uuidApiKey, userTemp, "ACCESSKEY", "SECRET", false, apiLimit, apiLimit.getLowHourly(),
	            apiLimit.getLowMonthly(), apiLimit.getMedHourly(), apiLimit.getMedMonthly(),
	            apiLimit.getHighHourly(), apiLimit.getHighMonthly());

	    apiKeyService.save(apiKey);
	}
}
