package com.qualitytaskforce.insightportal.model.articleModifications.single;

public class ArticleUpdateWhenSingle {

	String updateAt;
	String content;
	int readTime;

	public String getUpdateAt() {
		return updateAt;
	}

	public void setUpdateAt(String updateAt) {
		this.updateAt = updateAt;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public int getReadTime() {
		return readTime;
	}

	public void setReadTime(int readTime) {
		this.readTime = readTime;
	}

}