package com.qualitytaskforce.insightportal.model.users;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Api_keys", uniqueConstraints = @UniqueConstraint(columnNames = "user_id"))
public class ApiKey implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.REMOVE)
	@JoinColumn(name = "user_id", unique = true, nullable = false)
	private User user;
	
	@Column(name = "access_key", nullable = false)
	private String accessKey;

	@Column(name = "secret_key", nullable = false)
	private String secretKey;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "limit_tier", nullable = false)
	private ApiLimit apiLimit;
	
	@Column(name = "activated", nullable = false)
	private boolean activated;

	@Column(name = "low_hourly", nullable = false)
	private double lowHourly;

	@Column(name = "low_monthly", nullable = false)
	private int lowMonthly;

	@Column(name = "med_hourly", nullable = false)
	private double medHourly;

	@Column(name = "med_monthly", nullable = false)
	private int medMonthly;

	@Column(name = "high_hourly", nullable = false)
	private double highHourly;

	@Column(name = "high_monthly", nullable = false)
	private int highMonthly;

	@Column(name = "low_reset", nullable = false)
	private Long lowReset;

	@Column(name = "med_reset", nullable = false)
	private Long medReset;

	@Column(name = "high_reset", nullable = false)
	private Long highReset;

	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "ApiKey")
	private Set<ApiLogging> apiLoggings = new HashSet<ApiLogging>(0);

	public ApiKey() {
	}

	public ApiKey(UUID uuid, User user, String accessKey, String secretKey, boolean activated, ApiLimit apiLimit,
					double lowHourly, int lowMonthly, double medHourly, int medMonthly, double highHourly,
					int highMonthly) {
		// Api limiting timers use microtime accuracy
		Long currentTimeMicro = System.currentTimeMillis() / 1000;
		this.uuid = uuid;
		this.user = user;
		this.accessKey = accessKey;
		this.secretKey = secretKey;
		this.activated = activated;
		this.apiLimit = apiLimit;
		this.lowHourly = lowHourly;
		this.lowMonthly = lowMonthly;
		this.medHourly = medHourly;
		this.medMonthly = medMonthly;
		this.highHourly = highHourly;
		this.highMonthly = highMonthly;
		this.lowReset = currentTimeMicro;
		this.medReset = currentTimeMicro;
		this.highReset = currentTimeMicro;
	}

	public ApiKey(UUID uuid, User user, String accessKey, String secretKey,  boolean activated, ApiLimit apiLimit,
					double lowHourly, int lowMonthly, double medHourly, int medMonthly, double highHourly,
					int highMonthly, Set<ApiLogging> apiLoggings) {
		// Api limiting timers use microtime accuracy
		Long currentTimeMicro = System.currentTimeMillis() / 1000;
		this.uuid = uuid;
		this.apiLimit = apiLimit;
		this.user = user;
		this.accessKey = accessKey;
		this.secretKey = secretKey;
		this.activated = activated;
		this.lowHourly = lowHourly;
		this.lowMonthly = lowMonthly;
		this.medHourly = medHourly;
		this.medMonthly = medMonthly;
		this.highHourly = highHourly;
		this.highMonthly = highMonthly;
		this.lowReset = currentTimeMicro;
		this.medReset = currentTimeMicro;
		this.highReset = currentTimeMicro;
		this.apiLoggings = apiLoggings;
	}	

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getAccessKey() {
		return this.accessKey;
	}

	public void setAccessKey(String accessKey) {
		this.accessKey = accessKey;
	}

	public String getSecretKey() {
		return this.secretKey;
	}

	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
	public boolean isActivated() {
		return this.activated;
	}

	public void setActivated(boolean activated) {
		this.activated = activated;
	}
	
	public ApiLimit getApiLimit() {
		return this.apiLimit;
	}

	public void setApiLimit(ApiLimit apiLimit) {
		this.apiLimit = apiLimit;
	}
	
	/**
	 * @return the lowHourly
	 */
	public double getLowHourly() {
		return lowHourly;
	}

	/**
	 * @param lowHourly the lowHourly to set
	 */
	public void setLowHourly(double lowHourly) {
		this.lowHourly = lowHourly;
	}

	/**
	 * @return the lowMonthly
	 */
	public int getLowMonthly() {
		return lowMonthly;
	}

	/**
	 * @param lowMonthly the lowMonthly to set
	 */
	public void setLowMonthly(int lowMonthly) {
		this.lowMonthly = lowMonthly;
	}

	/**
	 * @return the medHourly
	 */
	public double getMedHourly() {
		return medHourly;
	}

	/**
	 * @param medHourly the medHourly to set
	 */
	public void setMedHourly(double medHourly) {
		this.medHourly = medHourly;
	}

	/**
	 * @return the medMonthly
	 */
	public int getMedMonthly() {
		return medMonthly;
	}

	/**
	 * @param medMonthly the medMonthly to set
	 */
	public void setMedMonthly(int medMonthly) {
		this.medMonthly = medMonthly;
	}

	/**
	 * @return the highHourly
	 */
	public double getHighHourly() {
		return highHourly;
	}

	/**
	 * @param highHourly the highHourly to set
	 */
	public void setHighHourly(double highHourly) {
		this.highHourly = highHourly;
	}

	/**
	 * @return the highMonthly
	 */
	public int getHighMonthly() {
		return highMonthly;
	}

	/**
	 * @param highMonthly the highMonthly to set
	 */
	public void setHighMonthly(int highMonthly) {
		this.highMonthly = highMonthly;
	}

	/**
	 * @return the lowReset
	 */
	public Long getLowReset() {
		return lowReset;
	}

	/**
	 * @param lowReset the lowReset to set
	 */
	public void setLowReset(Long lowReset) {
		this.lowReset = lowReset;
	}

	/**
	 * @return the medReset
	 */
	public Long getMedReset() {
		return medReset;
	}

	/**
	 * @param medReset the medReset to set
	 */
	public void setMedReset(Long medReset) {
		this.medReset = medReset;
	}

	/**
	 * @return the highReset
	 */
	public Long getHighReset() {
		return highReset;
	}

	/**
	 * @param highReset the highReset to set
	 */
	public void setHighReset(Long highReset) {
		this.highReset = highReset;
	}
	
	public Set<ApiLogging> getApiLoggings() {
		return this.apiLoggings;
	}

	public void setApiLoggings(Set<ApiLogging> apiLoggings) {
		this.apiLoggings = apiLoggings;
	}
}