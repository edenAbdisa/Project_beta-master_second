package com.qualitytaskforce.insightportal.controller.aws3s;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.qualitytaskforce.insightportal.s3.services.AmazonClient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/storage")
public class BucketController {
    private AmazonClient amazonClient;

    @Autowired
    BucketController(AmazonClient amazonClient) {
        this.amazonClient = amazonClient;
    }

    @PostMapping("")
    public String uploadFile(@RequestParam(value = "file") MultipartFile file) {
        return this.amazonClient.uploadFile(file);
    }

    @PostMapping("/images")
    public String uploadImage(@RequestParam(value = "file") MultipartFile file) {
        return this.amazonClient.uploadFileWithPath(file, "/images/cards/brands");
    }

    @DeleteMapping("")
    public String deleteFile(@RequestPart(value = "url") String fileUrl) {
        return this.amazonClient.deleteFileFromS3Bucket(fileUrl);
    }

    @GetMapping("/files/{dir:.+}")
    public ResponseEntity<?> listFilesFromBucket(@PathVariable(value = "dir") String dir){
        Map<String, Object> requestBody = new HashMap<>();
        List<?> listFiles = amazonClient.listFiles(dir.replace(".","/"));
        requestBody.put("files", listFiles);
        return new  ResponseEntity<Map<String, Object>>(requestBody,HttpStatus.OK);
    }

}
