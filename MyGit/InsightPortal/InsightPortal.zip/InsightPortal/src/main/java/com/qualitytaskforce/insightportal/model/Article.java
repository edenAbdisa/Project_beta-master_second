package com.qualitytaskforce.insightportal.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.util.Uuidgetable;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.search.annotations.DateBridge;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.Resolution;
import org.hibernate.search.annotations.SortableField;

        /*
* @Indexed used for declare persistent class as indexable.
* 
* @AnalyzerDefs contains AnalizerDef with defined parameters of contains analizers
* 
* @AnalyzerDef contains tokenizer class and some filters which used in searching
* 
* @TokenizerDef contains : "WhitespaceTokenizerFactory.class" which divide out sentence on the words by spaces (ex :" ") 
* and on next step this words will be filter by different filters
* 
* @TokenFilterDef - LowerCaseFilterFactory.class - take word and if there are "Up case" letters change it to "Lower case"
* 
* @TokenFilterDef - StopFilterFactory.class -  												
* stops analize word if exist some letters out of searchable word (ex : "work"(original)  - "wors"(input)  won't show as result) 
* 
* @TokenFilterDef - NGramFilterFactory.class -  
* this filter use for searching not only from start word, but in middle of word too (ex: "work"(original) - "ork"(input) it will as result)
*
* Parameter of NGramFilterFactory.class is @Parameter(name = "maxGramSize", value = "15") -  
* 	means that max part of part of word is 15 symbols (ex : "work"(original) - "ork"(input) - is this case used only 3 symbols (as part of word))  
* 
* Were used 2 @AnalyzerDef because analizer with name (name = "customanalyzer_query") was used in ArticleRepository.java to create QueryBuilder 
* 	
* 
* Set by this annotation that field not must be stored 
* @Field(store = Store.NO)
* 
* Set what name of analizer is use to analize this field 
* @Analyzer(definition = "customanalyzer")
* private String title;
* 
* 										
*/

/*@Indexed
@AnalyzerDefs({
	@AnalyzerDef(name = "customanalyzer", tokenizer = @TokenizerDef(factory = WhitespaceTokenizerFactory.class), filters = {
			@TokenFilterDef(factory = LowerCaseFilterFactory.class),
			@TokenFilterDef(factory = StopFilterFactory.class),
			@TokenFilterDef(factory = NGramFilterFactory.class, params = {
					@Parameter(name = "maxGramSize", value = "15") }) }),
	@AnalyzerDef(name = "customanalyzer_query", tokenizer = @TokenizerDef(factory = WhitespaceTokenizerFactory.class), filters = {
			@TokenFilterDef(factory = LowerCaseFilterFactory.class),
			@TokenFilterDef(factory = StopFilterFactory.class), }) })*/

/*@Field(store = Store.YES)
@Analyzer(definition = "customanalyzer")*/

@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
@Entity
@Table(name = "articles", uniqueConstraints = { @UniqueConstraint(columnNames = "sef_url_id"),
		@UniqueConstraint(columnNames = "test_recommendation_id"), @UniqueConstraint(columnNames = "title") })
public class Article implements java.io.Serializable, Uuidgetable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private java.util.UUID uuid;

	/* ========== Analized columns ========= */
	@Column(name = "title", unique = true, nullable = false, length = 100)	
	private String title;

	@Column(name = "summary_text", nullable = false, length = 65535)	
	private String summaryText;

	@Column(name = "full_text", nullable = false, length = 16777215)
	private String fullText;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = false, length = 19)
	@Field
	@SortableField
	@DateBridge(resolution = Resolution.MILLISECOND)
	private Date updatedAt;

	/* ====================================== */
	
	@Column(name = "meta_keywords", length = 45)
	private String metaKeywords;
	
	@Column(name = "read_time", nullable = false)
	private int readTime;

	@Column(name = "img_link", length = 255)
	private String imgLink;

	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinColumn(name = "sef_url_id", unique = true, nullable = false)
	private SefURL sefURL;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "category_id", nullable = false)
	private Category category;
	
	@Column(name = "subcategory", nullable = false)
	private String subcategory;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "impact_id", nullable = false)
	private ImpactRating impactRating;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "test_recommendation_id", unique = true, nullable = false)
	private TestRecommendation testRecommendation;

	@Column(name = "view_count", nullable = false)
	private int viewCount;

	@Column(name = "published", nullable = false)
	private boolean published;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "publish_date", nullable = false, length = 19)
	private Date publishDate;

	@Column(name = "requires_approval", nullable = false)
	private boolean requiresApproval;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false, length = 19)
	private Date createdAt;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by", nullable = false)
	private User userByCreatedBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "updated_by", nullable = false)
	private User userByUpdatedBy;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "check_in_by")
	private User userByCheckInBy;

	@Column(name = "show_explorer_test", nullable = false)
	private boolean showExplorerTest;

	@JsonIgnore
	@OneToMany(mappedBy = "articles", fetch = FetchType.LAZY)
	private Set<ArticleUpdate> articleUpdates = new HashSet<ArticleUpdate>(0);

	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "articles")
	private Set<ReleaseAdvisor> releaseAdvisors = new HashSet<>(0);

	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "articleByRelatedArticle")
	private Set<RelatedArticles> relatedArticlesesForRelatedArticle = new HashSet<>(0);

	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "articleByOriginalArticleId")
	private Set<RelatedArticles> relatedArticlesesForOriginalArticleId = new HashSet<>(0);

    @Column(name = "richcard_id", nullable = false)
	private UUID richcardId;

    @Column(name = "richcard_type", nullable = false)
    private String richcardType;

	@Column(name = "featured", nullable = false)
	private boolean featured;

    public Article() {

	}


	public Article(java.util.UUID uuid, UUID richcardId, String richcardType, Category category, String subcategory, ImpactRating impactRating, SefURL sefURL,
                   TestRecommendation testRecommendation, User userByCreatedBy, User userByUpdatedBy, String title,
                   String summaryText, String fullText, String metaKeywords, String imgLink, int viewCount, boolean published, Date publishDate,
                   boolean requiresApproval, Date createdAt, Date updatedAt, boolean showExplorerTest) {

		this.uuid = uuid;
		this.richcardId = richcardId;
		this.richcardType = richcardType;
		this.category = category;
		this.subcategory = subcategory;
		this.impactRating = impactRating;
		this.sefURL = sefURL;
		this.testRecommendation = testRecommendation;
		this.userByCreatedBy = userByCreatedBy;
		this.userByUpdatedBy = userByUpdatedBy;
		this.title = title;
		this.summaryText = summaryText;
		this.fullText = fullText;
		this.metaKeywords = metaKeywords;
		this.imgLink = imgLink;
		this.viewCount = viewCount;
		this.published = published;
		this.publishDate = publishDate;
		this.requiresApproval = requiresApproval;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.showExplorerTest = showExplorerTest;
	}


	public Article(java.util.UUID uuid, Category category, String subcategory, ImpactRating impactRating, SefURL sefURL,
                   TestRecommendation testRecommendation, User userByCreatedBy, User userByUpdatedBy, User userByCheckInBy,
                   String title, String summaryText, String fullText, String metaKeywords, int readTime, String imgLink, int viewCount,
                   boolean published, Date publishDate, boolean requiresApproval, Date createdAt, Date updatedAt,
                   boolean showExplorerTest, Set<ReleaseAdvisor> releaseAdvisors,
                   Set<RelatedArticles> relatedArticlesesForRelatedArticle,
                   Set<RelatedArticles> relatedArticlesesForOriginalArticleId, Set<ArticleUpdate> articleUpdates) {

		this.uuid = uuid;
		this.category = category;
		this.subcategory = subcategory;
		this.impactRating = impactRating;
		this.sefURL = sefURL;
		this.testRecommendation = testRecommendation;
		this.userByCreatedBy = userByCreatedBy;
		this.userByUpdatedBy = userByUpdatedBy;
		this.userByCheckInBy = userByCheckInBy;
		this.title = title;
		this.summaryText = summaryText;
		this.fullText = fullText;
		this.metaKeywords = metaKeywords;
		this.readTime = readTime;
		this.imgLink = imgLink;
		this.viewCount = viewCount;
		this.published = published;
		this.publishDate = publishDate;
		this.requiresApproval = requiresApproval;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.showExplorerTest = showExplorerTest;
		this.releaseAdvisors = releaseAdvisors;
		this.relatedArticlesesForRelatedArticle = relatedArticlesesForRelatedArticle;
		this.relatedArticlesesForOriginalArticleId = relatedArticlesesForOriginalArticleId;
		this.articleUpdates = articleUpdates;
	}

	public java.util.UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(java.util.UUID uuid) {
		this.uuid = uuid;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummaryText() {
		return this.summaryText;
	}

	public void setSummaryText(String summaryText) {
		this.summaryText = summaryText;
	}

	public String getFullText() {
		return this.fullText;
	}

	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	
	public String getMetaKeywords() {
		return this.metaKeywords;
	}

	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}

	public int getReadTime() {
		return readTime;
	}

	public void setReadTime(int readTime) {
		this.readTime = readTime;
	}

	public String getImgLink() {
		return imgLink;
	}

	public void setImgLink(String imgLink) {
		this.imgLink = imgLink;
	}

	public SefURL getSefURL() {
		return this.sefURL;
	}

	public void setSefURL(SefURL sefURL) {
		this.sefURL = sefURL;
	}

	public Category getCategory() {
		return this.category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
	
	public String getSubcategory() {
		return this.subcategory;
	}

	public void setSubcategory(String subcategory) {
		this.subcategory = subcategory;
	}

	public ImpactRating getImpactRating() {
		return this.impactRating;
	}

	public void setImpactRating(ImpactRating impactRating) {
		this.impactRating = impactRating;
	}

	public TestRecommendation getTestRecommendation() {
		return this.testRecommendation;
	}

	public void setTestRecommendation(TestRecommendation testRecommendation) {
		this.testRecommendation = testRecommendation;
	}

	public int getViewCount() {
		return this.viewCount;
	}

	public void setViewCount(int viewCount) {
		this.viewCount = viewCount;
	}

	public boolean isPublished() {
		return this.published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	public Date getPublishDate() {
		return this.publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	public boolean isRequiresApproval() {
		return this.requiresApproval;
	}

	public void setRequiresApproval(boolean requiresApproval) {
		this.requiresApproval = requiresApproval;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}

	public User getUserByCreatedBy() {
		return this.userByCreatedBy;
	}

	public void setUserByCreatedBy(User userByCreatedBy) {
		this.userByCreatedBy = userByCreatedBy;
	}

	public User getUserByUpdatedBy() {
		return this.userByUpdatedBy;
	}

	public void setUserByUpdatedBy(User userByUpdatedBy) {
		this.userByUpdatedBy = userByUpdatedBy;
	}

	public User getUserByCheckInBy() {
		return this.userByCheckInBy;
	}

	public void setUserByCheckInBy(User userByCheckInBy) {
		this.userByCheckInBy = userByCheckInBy;
	}

	public boolean isShowExplorerTest() {
		return this.showExplorerTest;
	}

	public void setShowExplorerTest(boolean showExplorerTest) {
		this.showExplorerTest = showExplorerTest;
	}

	public Set<ArticleUpdate> getArticleUpdates() {
		return this.articleUpdates;
	}

	public void setArticleUpdates(Set<ArticleUpdate> articleUpdates) {
		this.articleUpdates = articleUpdates;
	}

	public Set<ReleaseAdvisor> getReleaseAdvisors() {
		return this.releaseAdvisors;
	}

	public void setReleaseAdvisors(Set<ReleaseAdvisor> releaseAdvisors) {
		this.releaseAdvisors = releaseAdvisors;
	}

	public Set<RelatedArticles> getRelatedArticlesesForRelatedArticle() {
		return this.relatedArticlesesForRelatedArticle;
	}

	public void setRelatedArticlesesForRelatedArticle(Set<RelatedArticles> relatedArticlesesForRelatedArticle) {
		this.relatedArticlesesForRelatedArticle = relatedArticlesesForRelatedArticle;
	}

	public Set<RelatedArticles> getRelatedArticlesesForOriginalArticleId() {
		return this.relatedArticlesesForOriginalArticleId;
	}

	public void setRelatedArticlesesForOriginalArticleId(Set<RelatedArticles> relatedArticlesesForOriginalArticleId) {
		this.relatedArticlesesForOriginalArticleId = relatedArticlesesForOriginalArticleId;
	}

	public boolean getPublished() {
		return published;
	}

    public UUID getRichcardId() {
        return richcardId;
    }

    public void setRichcardId(UUID richcardId) {
        this.richcardId = richcardId;
    }

    public String getRichcardType() {
        return richcardType;
    }

    public void setRichcardType(String richcardType) {
        this.richcardType = richcardType;
    }

	public boolean isFeatured() {
		return featured;
	}

	public void setFeatured(boolean featured) {
		this.featured = featured;
	}
}
