package com.qualitytaskforce.insightportal.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.qualitytaskforce.insightportal.service.ArticleService;

public class UniqueTitleValidator implements ConstraintValidator<UniqueTitleConstraint, String> {

    ArticleService articleService;

    public UniqueTitleValidator(ArticleService articleService) {
        this.articleService = articleService;
    }

    @Override
    public void initialize(UniqueTitleConstraint constraint) {
        // empty
    }

    @Override
    public boolean isValid(String title, ConstraintValidatorContext context) {
        // if (title != null && !title.isEmpty()) {
        //     return true;
        // } else { 
        //     return false; 
        // }
        return title != null && !title.isEmpty();
    }

}