package com.qualitytaskforce.insightportal.model.util;

public class RequestDetails {

    private boolean isLoggedIn;
    private String ipAddress;

    public RequestDetails(boolean isLoggedIn, String ipAddress) {
        this.isLoggedIn = isLoggedIn;
        this.ipAddress = ipAddress;
    }

    public boolean isLoggedIn() {
        return isLoggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        isLoggedIn = loggedIn;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
        this.ipAddress = ipAddress;
    }
}
