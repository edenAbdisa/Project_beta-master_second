package com.qualitytaskforce.insightportal.util;

import java.util.Date;
import org.joda.time.LocalDate;

public class GetDateBefore {

	
	public Date getDateWithDaysBefore(int days) {
		Date stopDay = new Date();
		LocalDate now = new LocalDate(stopDay);
		LocalDate ndays = now.minusDays( days );
		Date startDay = ndays.toDateTimeAtStartOfDay().toDate();
		return startDay;
	}
	
	public Date getDateWithMonthsBefore(int months) {
		Date stopDay = new Date();
		LocalDate now = new LocalDate(stopDay);
		LocalDate nmonths = now.minusMonths( months );
		Date startDay = nmonths.toDateTimeAtStartOfDay().toDate();
		return startDay;
	}
}
