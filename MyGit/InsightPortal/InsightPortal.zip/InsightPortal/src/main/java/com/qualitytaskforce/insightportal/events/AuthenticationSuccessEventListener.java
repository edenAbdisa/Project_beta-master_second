package com.qualitytaskforce.insightportal.events;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.service.LoginAttemptService;
import com.qualitytaskforce.insightportal.service.users.UserService;

@Component
public class AuthenticationSuccessEventListener
        implements ApplicationListener<AuthenticationSuccessEvent> {
    @Autowired
    private final LoginAttemptService loginAttemptService;
    
    @Autowired
    private UserService userService;
    
    public AuthenticationSuccessEventListener(LoginAttemptService loginAttemptService) {
        this.loginAttemptService = loginAttemptService;
    }

    public void onApplicationEvent(AuthenticationSuccessEvent e) {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();
        System.out.print(loginAttemptService.isBlocked(request.getRemoteAddr()));
        
        try {
        		checkIsActivated(e);
				checkBlockedInDB(e);
				if (!loginAttemptService.isBlocked(request.getRemoteAddr())) {
					loginAttemptService.loginSucceeded(request.getRemoteAddr());
			    }
			
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
    }
    
    User getUser (AuthenticationSuccessEvent e) {
    	// Always not null
    	String email = e.getAuthentication().getPrincipal().toString();
		return userService.findByEmail(email).get(0);
    }
    
    void checkIsActivated (AuthenticationSuccessEvent e) throws IOException {
    	User user = getUser(e);
		boolean isActivated = user.isActivated();
		if (!isActivated) {
			throw new IOException ("User is not activated yet.");
		}
    }    
   
    void checkBlockedInDB (AuthenticationSuccessEvent e) throws IOException {
    	User user = getUser(e);
		boolean isBlockedInDB = user.isBlocked();
		if (isBlockedInDB) {
			throw new IOException ("User was blocked.<a style=\"text-decoration: none;\" href=\"/about-us\">here</a>");
		}
    }
}