package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.MobileBrowser;

public interface MobileBrowserRepository extends JpaRepository<MobileBrowser, Long> {

	@Query(value = "SELECT ta_ms_mobile_browsers.uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, ta_devices.type AS device_type, "
				+ "ta_oss.name AS os_name, ta_browsers.name AS browser_name, ta_browsers.version AS browser_version, "
				+ "ta_oss.version AS os_version, marketpenetration AS marketpen "
				+ "FROM ta_ms_mobile_browsers "
				+ "INNER JOIN ta_devices ON ta_devices.uuid = ta_ms_mobile_browsers.deviceuuid "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_mobile_browsers.osuuid "
				+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_mobile_browsers.browseruuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_mobile_browsers.countryuuid "
				+ "WHERE ta_countries.code = :code "
				+ "AND ta_ms_mobile_browsers.date = :date " 
				+ "AND ta_ms_mobile_browsers.marketpenetration > 0.02 "
				+ "ORDER BY marketpen DESC"
				, nativeQuery = true)
	List<MobileBrowser> mobileBrowsers(@Param("code") String code, @Param("date") String date);
	
	@Query(value = "SELECT * FROM ( "
				+ "SELECT uuid_v4() as uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, "
				+ "ta_devices.type AS device_type, ta_oss.name AS os_name, "
				+ "ta_oss.version AS os_version, ta_browsers.name AS browser_name, ta_browsers.version AS browser_version, "
				+ "(SUM(IFNULL(ta_ms_mobile_browsers.marketpenetration * ta_countries.desktop_users, 0)) / SUM(ta_countries.desktop_users)) AS marketpen "
				+ "FROM ta_ms_mobile_browsers "
				+ "INNER JOIN ta_devices ON ta_devices.uuid = ta_ms_mobile_browsers.deviceuuid "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_mobile_browsers.osuuid "
				+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_mobile_browsers.browseruuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_mobile_browsers.countryuuid "
				+ "WHERE ta_countries.uuid IN :countries "
				+ "AND ta_ms_mobile_browsers.date = :date "
				+ "AND ta_devices.type IN :types "
				+ "GROUP BY device_brand, model, type, os_name, os_version, browser_name, browser_version "
				+ "ORDER BY marketpen DESC "
				+ ") t WHERE marketpen > :threshold"
				, nativeQuery = true)
	List<MobileBrowser> mobileBrowsersMultiple(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("threshold") float threshold, @Param("types") List<String> types);
}