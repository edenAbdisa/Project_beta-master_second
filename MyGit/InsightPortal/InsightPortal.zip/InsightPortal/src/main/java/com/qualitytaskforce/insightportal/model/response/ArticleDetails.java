package com.qualitytaskforce.insightportal.model.response;

import java.text.SimpleDateFormat;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ImpactRating;
import com.qualitytaskforce.insightportal.model.SefURL;

public class ArticleDetails {

    private String title;

    private String summaryText;

    private ImpactRating impactRating;

    private String publishDate;

    private SefURL sefURL;

    public ArticleDetails() {}

    public ArticleDetails(Article article) {
        this.title = article.getTitle();
        this.summaryText = article.getSummaryText();
        this.impactRating = article.getImpactRating();
        SimpleDateFormat sdf = new SimpleDateFormat("YYY-MM-dd hh:mm:ss");
        this.publishDate = sdf.format(article.getPublishDate());
        this.sefURL = article.getSefURL();
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSummaryText(String summaryText) {
        this.summaryText = summaryText;
    }

    public void setImpactRating(ImpactRating impactRating) {
        this.impactRating = impactRating;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }

    public String getTitle() {
        return title;
    }

    public String getSummaryText() {
        return summaryText;
    }

    public ImpactRating getImpactRating() {
        return impactRating;
    }

    public String getPublishDate() {
        return this.publishDate;
    }

    public SefURL getSefURL() {
        return sefURL;
    }

    public void setSefURL(SefURL sefURL) {
        this.sefURL = sefURL;
    }
}
