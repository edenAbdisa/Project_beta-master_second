package com.qualitytaskforce.insightportal.filter;

public class JWTConfig {

    public static final String HEADER_STRING = "Authorization";
    public static final String TOKEN_PREFIX = "Bearer ";

    public static final String ISSUER = "qtf";
    public static final String SECRET = "insightportalsecretkey";

    /* Standard JWT expiration time
    100 000 000 milliseconds = ~28 hours */
    public final static int EXPIRATION_TIME = 100_000_000;

    /* JWT expiration time for users who checked "Keep me logged in" box when logging in
    2 592 000 000 milliseconds = 30 days */
    public final static long EXTENDED_EXPIRATION_TIME = 2_592_000_000L;

    /* How many minutes before JWT expiry date a new token should be issued */
    public final static int REFRESH_PERIOD = 1000000;

    public static String getUserLevelValue(String userLevel) {
        switch (userLevel) {
            case "Admin":
                return "500";
            case "Editor":
                return "400";
            case "BusinessAdmin":
                return "350";
            case "Business":
                return "300";
            case "ManualTrial":
            	return "250";
            case "AutomaticTrial":
                return "200";
            case "Free":
                return "100";
            default:
                return "0";
        }
    }
}
