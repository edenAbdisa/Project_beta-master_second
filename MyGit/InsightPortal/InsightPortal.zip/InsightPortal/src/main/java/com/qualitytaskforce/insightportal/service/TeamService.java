package com.qualitytaskforce.insightportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.model.Team;
import com.qualitytaskforce.insightportal.repository.TeamRepository;

@Service
public class TeamService {

	@Autowired
	TeamRepository repo;	
	
	public Team save(Team team) {
		return repo.save(team);
	}
	
}
