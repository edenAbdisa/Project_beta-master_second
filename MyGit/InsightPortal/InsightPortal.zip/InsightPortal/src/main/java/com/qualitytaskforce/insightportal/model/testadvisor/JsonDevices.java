package com.qualitytaskforce.insightportal.model.testadvisor;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonDevices {
	
	@JsonProperty("brand")
	private String brand;

	@JsonProperty("model")
    private String model;

	@JsonCreator
	public JsonDevices(@JsonProperty("brand") String brand, @JsonProperty("model") String model) {
        this.brand = brand;
        this.model = model;
	}

	public String getBrand() {
		return this.brand;
	}

	public String getModel() {
		return this.model;
	}
}