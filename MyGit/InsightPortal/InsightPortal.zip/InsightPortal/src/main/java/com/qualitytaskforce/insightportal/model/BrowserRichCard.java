package com.qualitytaskforce.insightportal.model;

import java.sql.Date;
import java.util.UUID;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@DiscriminatorValue(value = "browser")
@Table(name = "ta_browsers")
public class BrowserRichCard implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;

	@Column(name = "brand", length = 50)
	private String brand;

	@Column(name = "name", length = 50)
	private String name;
	
	@Size(min = 1, max = 10, message = "The version must be between {min} and {max} characters long")
	@NotNull()
	@Column(name = "version", length = 50)
	private String version;

	@NotNull()
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
	@Column(name = "release_date", length = 19)
	private Date releaseDate;
	
	@Size(min = 1, max = 255, message = "The stable info link must be between {min} and {max} characters long")
	@NotNull()
	@Column(name = "stable_info", length = 255)
	private String stableInfo;

	@Size(min = 1, max = 255, message = "The stable download link must be between {min} and {max} characters long")
	@NotNull()
	@Column(name = "stable_download", length = 255)
	private String stableDownload;

	@Column(name = "beta_info", length = 255)
	private String betaInfo;

	@Column(name = "beta_download", length = 255)
	private String betaDownload;

	@Column(name = "alpha_info", length = 255)
	private String alphaInfo;

	@Column(name = "alpha_download", length = 255)
	private String alphaDownload;

	public BrowserRichCard() {

	}

	public BrowserRichCard(UUID uuid, String brand, String name, String version, Date releaseDate, String stableInfo,
			String stableDownload, String betaInfo, String betaDownload, String alphaInfo, String alphaDownload) {
		this.brand = brand;
		this.name = name;
		this.version = version;
		this.releaseDate = releaseDate;
		this.stableInfo = stableInfo;
		this.stableDownload = stableDownload;
		this.betaInfo = betaInfo;
		this.betaDownload = betaDownload;
		this.alphaInfo = alphaInfo;
		this.alphaDownload = alphaDownload;
	}

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Date getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(Date releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getStableInfo() {
		return stableInfo;
	}

	public void setStableInfo(String stableInfo) {
		this.stableInfo = stableInfo;
	}

	public String getStableDownload() {
		return stableDownload;
	}

	public void setStableDownload(String stableDownload) {
		this.stableDownload = stableDownload;
	}

	public String getBetaInfo() {
		return betaInfo;
	}

	public void setBetaInfo(String betaInfo) {
		this.betaInfo = betaInfo;
	}

	public String getBetaDownload() {
		return betaDownload;
	}

	public void setBetaDownload(String betaDownload) {
		this.betaDownload = betaDownload;
	}

	public String getAlphaInfo() {
		return alphaInfo;
	}

	public void setAlphaInfo(String alphaInfo) {
		this.alphaInfo = alphaInfo;
	}

	public String getAlphaDownload() {
		return alphaDownload;
	}

	public void setAlphaDownload(String alphaDownload) {
		this.alphaDownload = alphaDownload;
	}
}
