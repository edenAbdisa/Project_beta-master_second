package com.qualitytaskforce.insightportal.model.response;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonValue;

public class BatchResponse {
    @JsonValue
    public Map<String, Object> batchEntityMap;
    @JsonIgnore()
    public List<BatchEntity> batchEntityList;
    private String _modelName;

    public class BatchEntity {
        @JsonProperty("id")
        public UUID id;
        @JsonProperty("status")
        public String status;

        @JsonProperty("message")
        public String message;

        public BatchEntity(UUID uuid, String status) {
            this.id = uuid;
            this.status = status;
            this.message = null;
        }
        public BatchEntity(UUID uuid, String status,String message) {
            this.id = uuid;
            this.status = status;
            this.message = message;
        }

        @Override
        public String toString() {
            return "{\"uuid:\" " + this.id + ", \"status:\"" + this.status + "}";
        }
    }
    //end internal class
    public BatchResponse(String name){
        batchEntityMap = new HashMap<String, Object>();
        batchEntityList = new ArrayList<BatchEntity>();
        batchEntityMap.put(name, batchEntityList);
        _modelName = name;
    }
    public void push(UUID uuid, String status) {

        BatchEntity batchEntity = new BatchEntity(uuid, status);
        this.batchEntityList.add(batchEntity);
    }

    public void push(UUID uuid, String status, String message) {

        BatchEntity batchEntity = new BatchEntity(uuid, status, message);
        this.batchEntityList.add(batchEntity);
    }

    public Map<String, Object> get() { return batchEntityMap; }
}
