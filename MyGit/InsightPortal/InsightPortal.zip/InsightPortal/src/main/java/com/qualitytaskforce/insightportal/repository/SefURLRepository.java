package com.qualitytaskforce.insightportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.qualitytaskforce.insightportal.model.SefURL;

public interface SefURLRepository extends JpaRepository<SefURL, Long> {
	
	SefURL findBySefUrl(String sefUrl);

}