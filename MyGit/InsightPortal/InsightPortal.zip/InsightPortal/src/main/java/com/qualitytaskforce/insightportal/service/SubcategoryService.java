package com.qualitytaskforce.insightportal.service;

import java.util.List;

import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.Subcategory;
import com.qualitytaskforce.insightportal.repository.SubcategoryRepository;
import com.qualitytaskforce.insightportal.util.SefURLToString;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SubcategoryService {

	@Autowired
	SubcategoryRepository subcategoryRepository;

	public Subcategory save(Subcategory subcategory) {
		return subcategoryRepository.save(subcategory);
	}	

	public void delete(Subcategory subcategory) {
		subcategoryRepository.delete(subcategory);
	}
	
	public List<Subcategory> findByName2 (String subcategoryName) {
		String result = SefURLToString.sefUrlToString(subcategoryName);	
		return subcategoryRepository.findByName(result);
	}
	
	public List<Subcategory> findAllSubcategories() {
		return subcategoryRepository.findAll();
	}
	
	public List<Subcategory> findAllByCategory(Category category) {
		return subcategoryRepository.findAllByCategories(category);		
	}
}