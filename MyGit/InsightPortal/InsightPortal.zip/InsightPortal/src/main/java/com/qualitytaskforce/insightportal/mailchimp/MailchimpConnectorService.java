package com.qualitytaskforce.insightportal.mailchimp;

import java.util.List;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.service.users.UserService;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class MailchimpConnectorService {

    @Autowired
    UserService userService;

    @Value("${mailchimp-username}")
    private String USERNAME;

    @Value("${mailchimp-password}")
    private String PASSWORD;

    @Value("${mailchimp-url}")
    private String MAILCHIMP_URL;

    @Value("${mailchimp-test-list-id}")
    private String TEST_LIST_ID;

    @Value("${mailchimp-list-id}")
    private String LIST_ID;

    @Value("${mailchimp-enable-production-list}")
    private boolean ENABLE_PRODUCTION_LIST;

    public String subscribe(String email) throws JSONException {
        List<User> user = userService.findByEmail(email);

        /* Set Basic Auth credentials */
        RestTemplateBuilder builder = new RestTemplateBuilder();
        RestTemplate restTemplate = builder.basicAuthorization(USERNAME, PASSWORD).build();

        /* Only use test mailchimp list in testing environment */
        String listId = ENABLE_PRODUCTION_LIST ? LIST_ID : TEST_LIST_ID;

        if (user.size() > 0) {
            return subscribeExistingUser(user.get(0), restTemplate, listId);
        } else {
            return subscribeNewUser(email, restTemplate, listId);
        }
    }

    private String subscribeExistingUser(User user, RestTemplate restTemplate, String listId) throws JSONException {

        String email = user.getEmail();
        String name = user.getName();
        String surname = user.getSurname();

        String req = "{\"members\":\\[\\{\"email_address\":\" " + email + "\",\"status\":\"subscribed\", \"merge_fields\": {\"FNAME\": \" " + name + "\",\n \"LNAME\": \"" + surname + "\"} }],\"update_existing\":false}";
        req = req.replace("\\", "");

        ResponseEntity<String> response = restTemplate.postForEntity(MAILCHIMP_URL + listId, req, String.class);
        JSONObject jsonObj = new JSONObject(response.getBody());
        JSONArray errors = jsonObj.getJSONArray("errors");

        String subscriptionResponse;

        if (errors.length() == 0) {
            subscriptionResponse = "You have been successfully subscribed.";
        } else {
            subscriptionResponse = "You are already subscribed to InsightPortal newsletter.";
        }

        return subscriptionResponse;

    }

    private String subscribeNewUser(String email, RestTemplate restTemplate, String listId) throws JSONException {

        String req = "{\"members\":\\[\\{\"email_address\":\" " + email + "\",\"status\":\"subscribed\"}],\"update_existing\":false}";
        req = req.replace("\\", "");

        ResponseEntity<String> response = restTemplate.postForEntity(MAILCHIMP_URL + listId, req, String.class);
        JSONObject jsonObj = new JSONObject(response.getBody());
        JSONArray errors = jsonObj.getJSONArray("errors");

        String subscriptionResponse;

        if (errors.length() == 0) {
            subscriptionResponse = "You have been successfully subscribed.";
        } else {
            subscriptionResponse = "You are already subscribed to InsightPortal newsletter.";
        }

        return subscriptionResponse;
    }
}