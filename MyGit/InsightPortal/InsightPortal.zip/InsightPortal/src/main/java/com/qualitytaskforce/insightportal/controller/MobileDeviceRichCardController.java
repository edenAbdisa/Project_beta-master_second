package com.qualitytaskforce.insightportal.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import javax.servlet.http.HttpServletRequest;
import com.qualitytaskforce.insightportal.config.WebConfig;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.MobileDeviceRichCard;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid;
import com.qualitytaskforce.insightportal.model.testadvisor.JsonDevices;
import com.qualitytaskforce.insightportal.repository.MobileDeviceRichCardRepository;
import com.qualitytaskforce.insightportal.service.MobileDeviceRichCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Import(WebConfig.class)
@RequestMapping(value = "/devices")
public class MobileDeviceRichCardController {

	@Autowired
	private MobileDeviceRichCardService mobileDeviceService;

	@Autowired
	private MobileDeviceRichCardRepository mobileDeviceRichCardRepository;

	private HttpHeaders headers = new HttpHeaders();

	@GetMapping(value = "/{uuid}")
	public ResponseEntity<MobileDeviceRichCard> getByUuid(@PathVariable("uuid") String uuidString)
			throws DataNotFoundException {

		MobileDeviceRichCard mb = mobileDeviceService.findByUUIDString(uuidString);
		if (mb == null) {
			throw new DataNotFoundException("RichCard even of the specified UUID does not exist.");
		}
		return new ResponseEntity<MobileDeviceRichCard>(mb, HttpStatus.OK);
	}

	@GetMapping(value = "/")
	public ResponseEntity<List<MobileDeviceRichCard>> getAll() throws DataNotFoundException {
		List<MobileDeviceRichCard> mb = mobileDeviceService.getAll();
		return new ResponseEntity<List<MobileDeviceRichCard>>(mb, HttpStatus.OK);
	}

	@GetMapping(value = "/brands")
	public ResponseEntity<?> getDeviceBrands() throws DataNotFoundException {
		List<String> mb = mobileDeviceService.getDeviceBrands();
		ArrayList<Object> queryResult = new ArrayList<>();
		HashMap<String, String> brand = null;
		for (String item : mb) {
			brand = new HashMap<>();
			brand.put("name", item);
			queryResult.add(brand);
		}
		return new ResponseEntity<>(queryResult, HttpStatus.OK);
	}

	@GetMapping(value = "/{brand}/models")
	public ResponseEntity<?> getDeviceModels(@PathVariable("brand") String brand)
			throws DataNotFoundException {
		List<String> mb = mobileDeviceService.getDeviceModels(brand);
		ArrayList<Object> queryResult = new ArrayList<>();
		HashMap<String, String> model = null;
		for (String item : mb) {
			model = new HashMap<>();
			model.put("name", item);
			queryResult.add(model);
		}
		return new ResponseEntity<>(queryResult, HttpStatus.OK);
	}

	@GetMapping(value = "/{brand}/{model}/data")
	public ResponseEntity<?> getDeviceModelx(@PathVariable("brand") String brand,
			@PathVariable("model") String model) throws DataNotFoundException {

		MobileDeviceRichCard mb = mobileDeviceService.getDeviceModelx(brand, model);
		return new ResponseEntity<>(mb, HttpStatus.OK);
	}

	@GetMapping(value = "/{brand}/{model}")
	public ResponseEntity<?> getDeviceUuid(@PathVariable("brand") String brand,
			@PathVariable("model") String model) {
		UUID id = mobileDeviceService.getDeviceUuid(brand, model);
		HashMap<String, UUID> item = new HashMap<>();
		item.put("RichCardUuid", id);
		return new ResponseEntity<>(item, HttpStatus.OK);
	}

	@PutMapping(value = "")
	public ResponseEntity<?> updateMobileDevice(
			@RequestBody MobileDeviceRichCard mobileDeviceRichCard) throws DataNotFoundException {

		MobileDeviceRichCard mobileDeviceRichCards = new MobileDeviceRichCard();

		mobileDeviceRichCards.setBrand(mobileDeviceRichCard.getBrand());
		mobileDeviceRichCards.setModel(mobileDeviceRichCard.getModel());
		mobileDeviceRichCards.setReleaseDate(mobileDeviceRichCard.getReleaseDate());
		mobileDeviceRichCards.setDisplaySize(mobileDeviceRichCard.getDisplaySize());
		mobileDeviceRichCards.setDisplayRes(mobileDeviceRichCard.getDisplayRes());
		mobileDeviceRichCards.setChipset(mobileDeviceRichCard.getChipset());
		mobileDeviceRichCards.setRam(mobileDeviceRichCard.getRam());
		mobileDeviceRichCards.setImgLink(mobileDeviceRichCard.getImgLink());
		mobileDeviceRichCards.setType(mobileDeviceRichCard.getType());

		mobileDeviceRichCardRepository.save(mobileDeviceRichCard);
		ApiResponse apiResponse = new ApiResponse("success", "The data has been updated");
		return new ResponseEntity<>(apiResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "/bulk", method = RequestMethod.POST)
	public ResponseEntity<?> getBulkDevices(@RequestBody List<JsonDevices> input,
			HttpServletRequest request) {
		List<String> brands = new ArrayList<>();
		List<String> models = new ArrayList<>();
		for (JsonDevices d : input) {
			brands.add(d.getBrand());
			models.add(d.getModel());
		}
		List<DeviceWithUuid> list = mobileDeviceService.getBulkDevices(brands, models);
		return new ResponseEntity<List<DeviceWithUuid>>(list, headers, HttpStatus.OK);
	}
}
