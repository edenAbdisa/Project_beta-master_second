package com.qualitytaskforce.insightportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.qualitytaskforce.insightportal.model.users.PasswordResets;

public interface PasswordResetsRepository extends JpaRepository<PasswordResets, Integer> {

	PasswordResets findByToken(String token);
	
	String findEmailByToken(String token);
	
	PasswordResets findByResetcode(String resetcode);
}
