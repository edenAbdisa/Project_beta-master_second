package com.qualitytaskforce.insightportal.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.MobileDeviceRichCard;
import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid;
import com.qualitytaskforce.insightportal.repository.MobileDeviceRichCardRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.DeviceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MobileDeviceRichCardService {

	@Autowired
	MobileDeviceRichCardRepository mobileDeviceRepository;

	@Autowired
	DeviceRepository deviceRepo;

	public MobileDeviceRichCard findByUUIDString(String uuidString)
			throws DataNotFoundException {
		UUID uuid = UUID.fromString(uuidString);
		return mobileDeviceRepository.findByUuid(uuid);
	}

	public List<MobileDeviceRichCard> getAll() {
		return mobileDeviceRepository.findAll();
	}

	public List<String> getDeviceBrands() {
		return mobileDeviceRepository.getDeviceBrands();
	}

	public List<String> getDeviceModels(String choosenBrand) {
		return mobileDeviceRepository.getDeviceModels(choosenBrand);
	}
	
	public MobileDeviceRichCard getDeviceModelx(String choosenBrand, String model) {
		return mobileDeviceRepository.getDeviceModelx(choosenBrand, model);
	}


	public UUID getDeviceUuid(String brand, String model) {
		return UUID.fromString(mobileDeviceRepository.getDeviceUuid(brand, model));
	}
	
	public String getMobileDeviceBrand(UUID uuid) {
		return mobileDeviceRepository.findByUuid(uuid).getBrand();
	}
	
	public String getMobileDeviceModel(UUID uuid) {
		return mobileDeviceRepository.findByUuid(uuid).getModel();
	}

	public List<DeviceWithUuid> getBulkDevices(List<String> brands, List<String> models) {
		return deviceRepo.getBulkDevices(brands, models);
	}
}