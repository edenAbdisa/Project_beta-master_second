package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Browser {
	
	@Id
	private UUID uuid;

	@Column(name = "browser_name")
	private String browserName;

	@Column(name = "marketpen")
	private float marketPen;

	public Browser () {
	}

	public Browser(UUID uuid, String browserName, float marketPen) {
		this.uuid = uuid;
		this.browserName = browserName;
		this.marketPen = marketPen;
	}

	public String getBrowserName() {
		return this.browserName;
	}

	public void setBrowserName(String browserName) {
		this.browserName = browserName;
	}

	public float getMarketPen() {
		return this.marketPen;
	}

	public void setMarketPen(float marketPen) {
		this.marketPen = marketPen;
	}
}