package com.qualitytaskforce.insightportal.service.relatedarticles;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.RelatedArticles;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.RelatedArticlesService;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;

@Service
public class GetRelatedBySefUrl {
	
	@Autowired
    private ArticleService articleService;
	
	@Autowired
    private RelatedArticlesService relatedArticlesService;	
		
	public List<ArticleWhenList> getRelated (String sefUrl) {
		
		Article article = articleService.findBySefURL(sefUrl);
        List<RelatedArticles> related = relatedArticlesService.findByArticle(article);

        List<Article> articles = related.stream()
						                .map(ra -> ra.getArticleByRelatedArticle())
						                .collect(Collectors.toList());

        Collections.sort(articles, (o1, o2) -> o2.getUpdatedAt()
                								  .compareTo(o1.getUpdatedAt()));

        return PrepareToShowInList.prepare(articles);       
	}
}
