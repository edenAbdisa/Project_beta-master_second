package com.qualitytaskforce.insightportal.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qualitytaskforce.insightportal.config.WebConfig;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.BrowserRichCard;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.repository.BrowserRichCardRepository;
import com.qualitytaskforce.insightportal.service.BrowserRichCardService;

@RestController
@Import(WebConfig.class)
@RequestMapping(value = "/browsers")
public class BrowserRichCardController {

	@Autowired
	private BrowserRichCardService browserService;

	@Autowired
	private BrowserRichCardRepository browserRichCardRepository;
	@GetMapping(value = "/{uuid}")
	public ResponseEntity<BrowserRichCard> getByUuid(@PathVariable("uuid") String uuidString)
			throws DataNotFoundException {

		BrowserRichCard br = browserService.findByUUIDString(uuidString);
		if (br == null) {
			throw new DataNotFoundException("RichCard even of the specified UUID does not exist.");
		}
		return new ResponseEntity<BrowserRichCard>(br, HttpStatus.OK);
	}

	@GetMapping(value = "/")
	public ResponseEntity<List<BrowserRichCard>> getAll() throws DataNotFoundException {
		List<BrowserRichCard> br = browserService.getAll();
		return new ResponseEntity<List<BrowserRichCard>>(br, HttpStatus.OK);
	}

	@GetMapping(value = "/brands")
	public ResponseEntity<?> getBrowserBrands() throws DataNotFoundException {
		List<String> mb = browserService.getBrowserBrands();
		ArrayList<Object> queryResult = new ArrayList<>();
		HashMap<String, String> brand = null;
		for (String item : mb) {
			brand = new HashMap<>();
			brand.put("name", item);
			queryResult.add(brand);
		}
		return new ResponseEntity<>(queryResult, HttpStatus.OK);
	}

	@GetMapping(value = "/{brand}/versions")
	public ResponseEntity<?> getBrowserModels(@PathVariable("brand") String brand) throws DataNotFoundException {
		List<String> mb = browserService.getBrowserModels(brand);
		ArrayList<Object> queryResult = new ArrayList<>();
		HashMap<String, String> model = null;
		for (String item : mb) {
			model = new HashMap<>();
			model.put("name", item);
			queryResult.add(model);
		}
		return new ResponseEntity<>(queryResult, HttpStatus.OK);
	}
	
	@GetMapping(value = "/{brand}/data")
	public ResponseEntity<?> getBrowserModelx(@PathVariable("brand") String brand) throws DataNotFoundException {
		
		BrowserRichCard mb = browserService.getBrowserModelx(brand);
		return new ResponseEntity<>(mb, HttpStatus.OK);
	}
	
	@PutMapping(value = "")
	public ResponseEntity<?> updatedBrowser(@RequestBody BrowserRichCard browserRichCard) throws DataNotFoundException {
		
		BrowserRichCard browserRichCards = browserService.findByUUIDString(String.valueOf(browserRichCard.getUuid()));
		
		browserRichCards.setVersion(browserRichCard.getVersion());
		browserRichCards.setReleaseDate(browserRichCard.getReleaseDate());
		browserRichCards.setStableInfo(browserRichCard.getStableInfo());
		browserRichCards.setStableDownload(browserRichCard.getStableDownload());
		browserRichCards.setBetaInfo(browserRichCard.getBetaInfo());
		browserRichCards.setBetaDownload(browserRichCard.getBetaDownload());
		browserRichCards.setAlphaInfo(browserRichCard.getAlphaInfo());
		browserRichCards.setAlphaDownload(browserRichCard.getAlphaDownload());
		
		browserRichCardRepository.save(browserRichCard);
		ApiResponse apiResponse = new ApiResponse("success", "The data has been updated");
		return new ResponseEntity<>(apiResponse, HttpStatus.OK);
	}

	@GetMapping(value = "/{brand}/{version}")
	public ResponseEntity<?> getBrowserUuid(@PathVariable("brand") String brand,
			@PathVariable("version") String version) {
		UUID id = browserService.getBrowserUuid(brand, version);
		HashMap<String, UUID> item = new HashMap<>();
		item.put("RichCardUuid", id);
		return new ResponseEntity<>(item, HttpStatus.OK);
	}
}
