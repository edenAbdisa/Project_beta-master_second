package com.qualitytaskforce.insightportal.model.response;

import java.util.List;

public class SearchSuggestions {
	
	private List<String> suggestions;

	public List<String> getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(List<String> suggestions) {
		this.suggestions = suggestions;
	}
}
