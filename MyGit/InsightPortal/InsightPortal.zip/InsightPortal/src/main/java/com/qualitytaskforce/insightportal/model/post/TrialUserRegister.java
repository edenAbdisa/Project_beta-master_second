package com.qualitytaskforce.insightportal.model.post;

public class TrialUserRegister {
    private String email;
    private String Password;

    public String getPassword() {
        return Password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        Password = password;
    }
}
