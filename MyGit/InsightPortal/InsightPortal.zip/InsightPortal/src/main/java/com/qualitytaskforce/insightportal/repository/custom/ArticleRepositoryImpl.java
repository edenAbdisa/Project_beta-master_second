/* package com.qualitytaskforce.insightportal.repository.custom;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.qualitytaskforce.insightportal.model.Article;

import org.apache.lucene.search.Query;
import org.apache.lucene.search.Sort;
import org.apache.lucene.search.SortField;
import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.FullTextQuery;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;

public class ArticleRepositoryImpl implements ArticleRepositoryCustom{

	@PersistenceContext
	private EntityManager entityManager;

	private List<Article> registeredUsers = new LinkedList<>();
	
	
	//>>>> PARAMETER FOR ALL METHODS - SELECTED FIELD TO SORT IN TIME <<<<<
	
	   private static final String sortByField = "updatedAt";
	
	// =============================================================================
	//
	 * @text - matched text
	 * @typeSearchField - 1 is by title
	 * 					  2 is by summaryText
	 *  				  3 is by fullText
	 *  				  4 is by All (title and summaryText and fullText) 
	 *  				  5 is by title and summaryText
	 *  				  6 is by summaryText and fullText
	 *  				  7 is by title and fullText
	 * @typeSymbol - true means within data range
	 *  	 		- false means without data range
	 * 
	 * @isSortedByDate - true means results will sorted
	 *  				- false means results won't sorted
	 * 
	 * @isPaginated - true means will use paginated
	 * 				- false means won't use paginated
	 * 
	 * @dateFrom - will used if typeSymbol will true
	 * @dateTo
	 * 
	 * @rangeFrom - means from which position of results will return
	 * @results - means how many results will be returned started from position of "rangeFrom"
	 * 
	 

	@SuppressWarnings("unchecked")
	public List<Article> search(String text, int typeSearchField, boolean typeSymbol, 
								boolean isSortedByDate, boolean isPaginated, 
								Date dateFrom, Date dateTo, int rangeFrom, int results ) {
		
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		
		//int typeSearchField = 1;
		String typeSymbolString = "N";
		if (typeSymbol) typeSymbolString = "Y";
		String typeWithSymbol = String.valueOf(typeSearchField)+ typeSymbolString;
		//boolean isSortedByDate = false;
		//boolean isPaginated = false;
		
		QueryBuilder queryBuilder = getQueryBuilder(typeSearchField, fullTextEntityManager);		
		Query luceneQuery = getLuceneQuery(text, dateFrom, dateTo, typeWithSymbol, queryBuilder);
		
		FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, Article.class);
		
		if(isSortedByDate){
			Sort sort = new Sort(new SortField(sortByField, SortField.Type.LONG, true ));
			query.setSort( sort );
		}

		System.out.println(query.toString());
		
		List<Article> resultSearch;
		if(isPaginated) {			
			resultSearch = query.setFirstResult(rangeFrom)
										 	  .setMaxResults(results)
										 	  .getResultList();
		} else {			
			resultSearch = query.getResultList();
			System.out.println(query.getResultList().toString());
		}
		
		System.out.println(resultSearch.size());
		resultSearch = verifyNextWords(text,typeSearchField,resultSearch);	
		
		return resultSearch;
		
	}

	public List<Article> searchByTitle(String text) {
		FullTextEntityManager fullTextEntityManager = Search.getFullTextEntityManager(entityManager);
		
		QueryBuilder queryBuilder = fullTextEntityManager.getSearchFactory()
									.buildQueryBuilder().forEntity(Article.class)
			    					.overridesForField("title", "customanalyzer_query")
			    					.overridesForField("fullText", "customanalyzer_query")
			    					.get();
			
		Query luceneQuery = queryBuilder.keyword()
													.onFields("title","fullText")
													.matching(text)
													.createQuery();

		FullTextQuery query = fullTextEntityManager.createFullTextQuery(luceneQuery, Article.class);
		
		@SuppressWarnings("unchecked")
		List<Article> results = query.getResultList();
		
		//Modyfied query - cause with this better result
		List<Article> resultsModyfied = new ArrayList<Article>();
		for(int i=0;i<results.size();i++){
			if(results.get(i).getTitle().toLowerCase().contains(text.toLowerCase())){
				resultsModyfied.add(results.get(i));
			}
		}		
		
		return resultsModyfied;
			    
	}
	public Optional<Article> findByTitle(String title) {
		return registeredUsers.stream()
				.filter(user -> user.getTitle().equals(title))
				.findFirst();
	}

	
	private QueryBuilder getQueryBuilder(int typeSearchField, FullTextEntityManager fullTextEntityManager){
		
		QueryBuilder queryBuilder = null;
		
		switch (typeSearchField) {			
		case 1:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)
										.overridesForField("title", "customanalyzer_query")				
										.get();				
		break;
		case 2:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)											
										.overridesForField("summaryText", "customanalyzer_query")											
										.get();
			break;
		case 3:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)
										.overridesForField("fullText", "customanalyzer_query")
										.get();	
			break;
		case 4:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)
										.overridesForField("title", "customanalyzer_query")
										.overridesForField("summaryText", "customanalyzer_query")
										.overridesForField("fullText", "customanalyzer_query")
										.get();	
			break;
		case 5:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)
										.overridesForField("title", "customanalyzer_query")
										.overridesForField("summaryText", "customanalyzer_query")											
										.get();	
			break;
		case 6:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)
										.overridesForField("summaryText", "customanalyzer_query")
										.overridesForField("fullText", "customanalyzer_query")
										.get();	
			break;
		case 7:
			queryBuilder = fullTextEntityManager.getSearchFactory().buildQueryBuilder()
										.forEntity(Article.class)
										.overridesForField("title", "customanalyzer_query")
										.overridesForField("fullText", "customanalyzer_query")
										.get();	
			break;
		default:							
		break;		
	}
		return queryBuilder;
	}
	
	
	private Query getLuceneQuery(String text, Date dateFrom, Date dateTo, String typeWithSymbol, QueryBuilder queryBuilder) {
		
		Query luceneQuery = null;	
		
		switch (typeWithSymbol) {
			case "1N":
				luceneQuery = queryBuilder.keyword().onFields("title").matching(text).createQuery();				
			break;
			case "1Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("title").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())				
												.createQuery();			
			break;
			case "2N":
				luceneQuery = queryBuilder.keyword().onFields("summaryText").matching(text).createQuery();				
			break;
			case "2Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("summaryText").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())				
												.createQuery();
			case "3N":
				luceneQuery = queryBuilder.keyword().onFields("fullText").matching(text).createQuery();				
			break;
			case "3Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("fullText").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())
												.createQuery();				
			break;
			case "4N":
				luceneQuery = queryBuilder.keyword().onFields("title", "summaryText", "fullText").matching(text).createQuery();				
			break;
			case "4Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("title", "summaryText", "fullText").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())
												.createQuery();
			break;
			case "5N":
				luceneQuery = queryBuilder.keyword().onFields("title", "summaryText").matching(text).createQuery();
				break;
			case "5Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("title", "summaryText").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())
												.createQuery();
			break;
			case "6N":
				luceneQuery = queryBuilder.keyword().onFields("summaryText", "fullText").matching(text).createQuery();
				break;
			case "6Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("summaryText", "fullText").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())
												.createQuery();
			break;
			case "7N":
				luceneQuery = queryBuilder.keyword().onFields("title", "fullText").matching(text).createQuery();
				break;
			case "7Y":
				luceneQuery = queryBuilder.bool()
												.must(queryBuilder.keyword().onFields("title", "fullText").matching(text).createQuery())
												.must(queryBuilder.range().onField(sortByField).ignoreFieldBridge()
											            .from(dateFrom)
											            .to(dateTo)
											            .excludeLimit().createQuery())
												.createQuery();
			break;
			
			
			default:
			break;
		}
		
		
		
		return luceneQuery;
	}

	
	private List<Article> verifyNextWords (String text, int typeSearchField, List<Article> articles){
		
		List<Article> modified = new ArrayList<Article>();
		
		for(int k=0;k<articles.size();k++){
		
				switch(typeSearchField) {
				
					case 1:						
						if(articles.get(k).getTitle().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					case 2:						
						if(articles.get(k).getSummaryText().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					case 3:						
						if(articles.get(k).getFullText().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					case 4:						
						if(articles.get(k).getTitle().toLowerCase().contains(text.toLowerCase()) ||
							articles.get(k).getSummaryText().toLowerCase().contains(text.toLowerCase()) ||
							 articles.get(k).getFullText().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					case 5:						
						if(articles.get(k).getTitle().toLowerCase().contains(text.toLowerCase()) ||
							articles.get(k).getSummaryText().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					case 6:						
						if(articles.get(k).getSummaryText().toLowerCase().contains(text.toLowerCase()) ||
							articles.get(k).getFullText().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					case 7:						
						if(articles.get(k).getTitle().toLowerCase().contains(text.toLowerCase()) ||
							articles.get(k).getFullText().toLowerCase().contains(text.toLowerCase()))
							modified.add(articles.get(k));						
					break;
					default:
					break;
				}
		}
		
		return modified;
	}
} */