package com.qualitytaskforce.insightportal.model.testadvisor;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CountryWithName implements Comparable<CountryWithName> {
	
	private String code;

	private String name;

	@JsonProperty("region_code")
	private String regionCode;

	public CountryWithName () {
	}

	public CountryWithName(String code, String name, String regionCode) {
		this.code = code;
		this.name = name;
		this.regionCode = regionCode;
	}

	public String getCode() {
		return this.code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * @return the regionCode
	 */
	public String getRegionCode() {
		return regionCode;
	}
	
	/**
	 * @param regionCode the regionCode to set
	 */
	public void setRegionCode(String regionCode) {
		this.regionCode = regionCode;
	}

	@Override
	public int compareTo(CountryWithName country) {
		return this.name.compareTo(country.name);
	}
}