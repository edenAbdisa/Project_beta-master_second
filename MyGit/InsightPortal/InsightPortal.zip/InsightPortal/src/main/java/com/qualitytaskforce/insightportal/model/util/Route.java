package com.qualitytaskforce.insightportal.model.util;

import org.springframework.http.HttpMethod;

public class Route {
	
	private final RouteTier RATE_TIER;
	private final String PRIVILEGE_TIER;
	private final HttpMethod METHOD;

	public Route(RouteTier rateTier, String privilegeTier) {
		this.RATE_TIER = rateTier;
		this.PRIVILEGE_TIER = privilegeTier;
		this.METHOD = HttpMethod.GET;
	}
	public Route(RouteTier rateTier, String privilegeTier, HttpMethod method) {
		this.RATE_TIER = rateTier;
		this.PRIVILEGE_TIER = privilegeTier;
		this.METHOD = method;
	}

	public RouteTier getRateTier() {
		return this.RATE_TIER;
	}

	public String getPrivilegeTier() {
		return this.PRIVILEGE_TIER;
	}

	public HttpMethod getMethod() {
		return this.METHOD;
	}
}