package com.qualitytaskforce.insightportal.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.util.PositionFrom;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/search")
public class SearchControllerLight {

	@Autowired
	ArticleService articleService;

	@Autowired
	ArticleRepository articleRepository;

	@GetMapping("/suggestion-tags")
	public ResponseEntity<List<SearchSuggestion>> getSuggestions(
			@RequestParam(value = "title") String inputText) throws Exception {

		String text = inputText;
		List<SearchSuggestion> suggs = new ArrayList<>();

		if (isContainsUnexpectedChar(text)) {
			return new ResponseEntity<List<SearchSuggestion>>(
					Collections.<SearchSuggestion>emptyList(), HttpStatus.OK);
		} else {
			int minLength = 2;
			suggs = fetchTitles(minLength, text);
			if (suggs.isEmpty()) {
				return new ResponseEntity<List<SearchSuggestion>>(
						Collections.<SearchSuggestion>emptyList(), HttpStatus.OK);
			}
		}

		List<SearchSuggestion> suggsWithEmpty = new ArrayList<SearchSuggestion>();
		SearchSuggestion emptySugg = new SearchSuggestion();
		suggsWithEmpty.add(emptySugg);
		suggsWithEmpty.addAll(suggs);

		return new ResponseEntity<List<SearchSuggestion>>(suggsWithEmpty, HttpStatus.OK);
	}

	boolean isContainsUnexpectedChar(String text) {
		return text.matches("[^a-zA-Z0-9\\s]");
	}

	List<SearchSuggestion> fetchTitles(int minLength, String text) {

		List<SearchSuggestion> result = new ArrayList<>();
		if (text.trim().length() > minLength) {
			List<Article> articles = articleService.searchPaginWithSQL(text, 0, 7);
			if (!articles.isEmpty()) {
				for (Article a : articles) {
					SearchSuggestion ss = new SearchSuggestion();
					ss.setSuggestion(a.getTitle());
					ss.setSuggestionSefUrl(a.getSefURL().getSefUrl());
					result.add(ss);
				}
			}
		}
		return result;
	}



	@GetMapping("/get-articles-in-list")
	public ResponseEntity<List<ArticleWhenList>> getArticlesInList(
			@RequestParam(value = "keywords") String keywords,
			@RequestParam(value = "part") String partStr) {

		String text = keywords.replaceAll("-", " ");
		int part = Integer.valueOf(partStr);
		int quantity = 7;
		int from = PositionFrom.getPositionFrom(part, quantity);

		if (isContainsUnexpectedChar(keywords)) {
			return new ResponseEntity<List<ArticleWhenList>>(
					Collections.<ArticleWhenList>emptyList(), HttpStatus.OK);
		}
		List<Article> foundArticles = articleService.searchPaginWithSQL(text, from, quantity + 1);

		if (foundArticles.size() < 1) {
			return new ResponseEntity<List<ArticleWhenList>>(
					Collections.<ArticleWhenList>emptyList(), HttpStatus.OK);
		}

		List<ArticleWhenList> articlesCutted = PrepareToShowInList.prepare(foundArticles);
		return new ResponseEntity<List<ArticleWhenList>>(articlesCutted, HttpStatus.OK);
	}



}


class SearchSuggestion {

	String suggestion;
	String suggestionSefUrl;

	public String getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}

	public String getSuggestionSefUrl() {
		return suggestionSefUrl;
	}

	public void setSuggestionSefUrl(String suggestionSefUrl) {
		this.suggestionSefUrl = suggestionSefUrl;
	}
}
