package com.qualitytaskforce.insightportal.controller;

import com.qualitytaskforce.insightportal.model.EmailContact;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.service.EmailServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping(value = "/email")
public class EmailController {
    @Autowired
    EmailServiceImpl emailService;

    @PostMapping("")
    public ResponseEntity<?> sendContactEmail(@RequestBody EmailContact emailContact){
        
    	String emailTo = "contactus@insightportal.io";
        String emailTitle = "Message from contact form "+emailContact.getFirstName() +" "+ emailContact.getLastName();
    	String emailBody = emailContact.getFirstName() +" "+ emailContact.getLastName()+"<br><br>"
    						+emailContact.getCompany()+"<br>"
							+emailContact.getEmail() +"<br>"
							+emailContact.getEnquiry();
        emailService.sendEmail(emailTo, emailTo, emailTitle, emailBody); 
                
        return new ResponseEntity<ApiResponse>(new ApiResponse("success", "message has been sent"), HttpStatus.OK);
    }
}