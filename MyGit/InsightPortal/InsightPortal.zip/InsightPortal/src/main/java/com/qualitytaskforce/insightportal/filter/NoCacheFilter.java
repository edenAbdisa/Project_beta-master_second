package com.qualitytaskforce.insightportal.filter;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;

import java.io.IOException;

import javax.servlet.Filter;

@Component
public class NoCacheFilter implements Filter{	
	
	public NoCacheFilter() {
	}
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) req;
		HttpServletResponse response = (HttpServletResponse) resp;
		response.addHeader("Cache-control", "no-cache, max-age=0");
		chain.doFilter(request, response);		
	}

	@Override
	public void destroy() {
	}
}
