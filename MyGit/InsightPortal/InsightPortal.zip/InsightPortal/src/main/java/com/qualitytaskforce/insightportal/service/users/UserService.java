package com.qualitytaskforce.insightportal.service.users;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.qualitytaskforce.insightportal.annotation.FieldValueExists;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.repository.users.UserRepository;

@Service
public class UserService implements FieldValueExists {

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserLevelService userLevelService;

    @Autowired
    UserDetailsServiceImpl userDetailsService;
    
    @Autowired
    UserTrialService userTrialService;

    public User save(User user) {
        return userRepository.save(user);
    }

    public List<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getByEmail(String email) {
        return userRepository.getByEmail(email);
    }

    public User findByName(String name) {
        return userRepository.findByName(name);
    }

    public List<User> findByUserLevel(UserLevel userLevel) {
        return userRepository.findByUserLevel(userLevel);
    }

    public User findByUUID(UUID uuid) {
        return userRepository.findByUuid(uuid);
    }
    
    public List<User> findByCompany(String company) {
        return userRepository.findByCompany(company);
    }

    public boolean block(UUID uuid) {
        User user = userRepository.findByUuid(uuid);
        if (user == null) {
            return false;
        }
        short blockCount = user.getBlockCount();

        user.setBlocked(true);
        user.setBlockCount(blockCount++);
        userRepository.save(user);
        return true;
    }

    public boolean unblock(UUID uuid) {
        User user = userRepository.findByUuid(uuid);
        if (user == null) {
            return false;
        }
        user.setBlocked(false);
        userRepository.save(user);
        return true;
    }

    public boolean fieldValueExists(Object value, String fieldName, UUID uuidUser) throws UnsupportedOperationException {
        Assert.notNull(fieldName, "fieldName must not be null");
        if (value == null) {
            return false;
        }

        User user = this.userRepository.findByEmail(value.toString()).get(0);

        if (!fieldName.equals("email")) {
            throw new UnsupportedOperationException("Field name not supported");
        }

        return this.userRepository.existsByEmail(value.toString()) && user.getUuid() != uuidUser;
    }

    public boolean fieldValueExists(Object value, String fieldName) throws UnsupportedOperationException {
        Assert.notNull(fieldName, "fieldName must not be null");
        if (value == null) {
            return false;
        }

        if (!fieldName.equals("email")) {
            throw new UnsupportedOperationException("Field name not supported");
        }

        return this.userRepository.existsByEmail(value.toString());
    }

    public void delete (User user) {
    	userRepository.delete(user);
    }
}
