package com.qualitytaskforce.insightportal.model.post;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonUserLevel {
	
	@JsonProperty("name")
	private String name;

	@JsonProperty("permissions")
	private String permissions;

	private String permissionsPattern = "\\{(\"[A-Za-z]+\":[ ]*[0,1][ ]*,)*(\"[A-Za-z]+\":[ ]*[0,1][ ]*)\\}";

	public String getName(){
		return this.name;
	}

	public String getPermissions(){
		return this.permissions;
	}

	@Override
	public String toString() {
		return "User [name=" + this.name + ", permissions=" + this.permissions
				+ "]";
	}

	public boolean checkRequiredNull() {
		if (this.name == null || this.permissions == null) {
			return false;
		}
		return true;
	}

	public boolean checkPermissionPattern() {
		if (this.permissions.matches(permissionsPattern)) {
			return true;
		}
		return false;
	}
}