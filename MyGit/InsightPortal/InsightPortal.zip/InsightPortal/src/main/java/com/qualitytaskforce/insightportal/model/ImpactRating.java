package com.qualitytaskforce.insightportal.model;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.qualitytaskforce.insightportal.model.users.User;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "impact_rating", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
public class ImpactRating implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "name", unique = true, nullable = false, length = 1)
	private int name;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "check_in_by")
	@JsonIgnore
	private User user;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "impactRating")
	private Set<Article> articles = new HashSet<Article>(0);

	public ImpactRating() {
	}

	public ImpactRating(UUID uuid, int name) {
		this.uuid = uuid;
		this.name = name;		
	}

	public ImpactRating(UUID uuid, User user, int name, Set<Article> articles) {
		this.uuid = uuid;
		this.user = user;
		this.name = name;		
		this.articles = articles;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
	public int getName() {
		return this.name;
	}

	public void setName(int name) {
		this.name = name;
	}	
	
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Set<Article> getArticles() {
		return this.articles;
	}

	public void setArticles(Set<Article> articles) {
		this.articles = articles;
	}
}
