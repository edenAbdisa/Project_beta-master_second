package com.qualitytaskforce.insightportal.controller;

import com.qualitytaskforce.insightportal.model.response.SimpleResponse;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MainController {
	
	private HttpHeaders headers = new HttpHeaders();

	@Autowired
	private MessageUtil util;

	/**
	 * Root path for api
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ResponseEntity<SimpleResponse> root(HttpServletRequest request) {
		SimpleResponse response = new SimpleResponse(HttpStatus.OK, util.getMessage("root.welcome"));
		return new ResponseEntity<>(response, headers, response.getHttpStatus());
	}
}