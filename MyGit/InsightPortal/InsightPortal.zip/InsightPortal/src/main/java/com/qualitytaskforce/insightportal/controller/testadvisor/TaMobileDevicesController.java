package com.qualitytaskforce.insightportal.controller.testadvisor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.testadvisor.Country;
import com.qualitytaskforce.insightportal.model.testadvisor.MobileDevice;
import com.qualitytaskforce.insightportal.model.testadvisor.JsonTestAdvisor;
import com.qualitytaskforce.insightportal.model.testadvisor.Response;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import com.qualitytaskforce.insightportal.service.TestAdvisorService;

@RestController
@RequestMapping(value = "/testadvisor")
public class TaMobileDevicesController {

	@Autowired
	private TestAdvisorService service;

	private HttpHeaders headers = new HttpHeaders();

	@Autowired
	private MessageUtil util;

	@RequestMapping(value = "/mobiledevices/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> mobileDevices(@PathVariable String code) throws Exception{
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		List<MobileDevice> list = service.mobileDevices(code, getDateNow());
		if(list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-country-data"));
		}
		return new ResponseEntity<List<MobileDevice>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/mobiledevices/", method = RequestMethod.POST)
	public ResponseEntity<?> mobileDevicesMultiple(@RequestBody JsonTestAdvisor input) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		if (input.getDate().equals("")) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-date"));
		}
		StringBuilder date = new StringBuilder(input.getDate());
		List<String> inputRegions = input.getRegions();
		List<String> inputCountries = input.getCountries();
		int coverage = input.getCoverage();
		float threshold = input.getThreshold();
		List<String> regions = getRegions();
		List<String> inputTypes = input.getTypes();
		
		List<String> types = new ArrayList<>();

		if (inputTypes == null) {
			types.add("Tablet");
			types.add("Smartphone");
		} else {
			for (String t : inputTypes) {
				types.add(t);
			}
		}

		List<MobileDevice> inCoverage = new ArrayList<>();
		List<MobileDevice> outOfCoverage = new ArrayList<>();		
		List<Country> countriesByRegion = new ArrayList<>();
		List<UUID> countryuuids = new ArrayList<>();
		List<MobileDevice> list = new ArrayList<>();
		List<Country> countries = new ArrayList<>();

		if (checkRequiredNull(inputRegions, inputCountries)) {
			throw new InvalidParameterException(util.getMessage("error.ta.generic.no-country-or-region"));
		}
		if (!alterDate(date)) {
			throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.bad-date-format"));
		}

		boolean worldRegion = false;
		//Check World region first, if world is specified countries parameter cant be ignored
		if (inputRegions != null) {
			if (inputRegions.contains("WWW")) {
				countries = service.getAllCountries();
				worldRegion = true;
			} else {
				if (!regions.containsAll(inputRegions)) {
					throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.incorrect-region"));
				}
				countriesByRegion = service.getCountriesByRegion(inputRegions);
				if (countriesByRegion.isEmpty()) {
					throw new DataNotFoundException(util.getMessage("error.ta.generic.no-region-data"));
				}
				countries.addAll(countriesByRegion);
			}
		}

		addCountries(inputCountries, countries, worldRegion);
		countryuuids = getCountryUuids(countries);

		if (threshold < 0 && threshold > 100) {
			throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.bad-threshold"));
		}

		list = service.mobileDevicesMultiple(countryuuids, date.toString(), threshold, types);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		if (coverage != 0) {
			int count = buildInCoverage(list, inCoverage, coverage);
			if (!input.getHide()) {
				outOfCoverage.addAll(list.subList(count,list.size()));
				Response<MobileDevice> response = new Response<MobileDevice>(inCoverage, outOfCoverage);
				return new ResponseEntity<Response<MobileDevice>>(response, headers, HttpStatus.OK);
			} else {
				return new ResponseEntity<List<MobileDevice>>(inCoverage, headers, HttpStatus.OK);
			}
		}
		return new ResponseEntity<List<MobileDevice>>(list, headers, HttpStatus.OK);
	}


	private String getDateNow() {
		String date = new SimpleDateFormat("yyyy-MM").format(new Date());
		date = date + "-01";
		return date;
	}

	private List<String> getRegions() {
		List<String> regions = new ArrayList<>();
		regions.add("AF");
		regions.add("AN");
		regions.add("AS");
		regions.add("EU");
		regions.add("NA");
		regions.add("OC");
		regions.add("SA");
		return regions;
	}

	private boolean checkRequiredNull(List<String> regions, List<String> countries) {
		if (regions == null && countries == null) {
			return true;
		}
		return false;
	}

	private boolean alterDate(StringBuilder date) {
		String dateTemp = date.toString();
		if (dateTemp.matches("([0-9]{4}-[0-9]{2})(-[0-9]{2})?")) {
			// Change the day of the date to 01 for monthly data
			dateTemp = dateTemp.substring(0,7);
			dateTemp = dateTemp.concat("-01");
			date.delete(0, date.length());
			date.append(dateTemp);
			return true;
		}
		return false;
	}

	private void addCountries(List<String> inputCountries, List<Country> countries, boolean worldRegion) {
		if (inputCountries != null && worldRegion == false) {
			for (int i = 0; i < countries.size(); i++) {
				if (inputCountries.contains(countries.get(i).getCode())) {
					inputCountries.remove(countries.get(i).getCode());
				}
			}
			if (!inputCountries.isEmpty()) {
				countries.addAll(service.getCountries(inputCountries));
			}
		}
	}

	private List<UUID> getCountryUuids(List<Country> countries) {
		List<UUID> countryuuids = new ArrayList<>();
		for (int i = 0; i < countries.size(); i++) {
			countryuuids.add(countries.get(i).getUuid());
		}
		return countryuuids;
	}

	private int buildInCoverage(List<MobileDevice> list, List<MobileDevice> inCoverage, int coverage) {
		float sum = 0;
		int count = 0;
		for (int i = 0; i < list.size(); i++) {
			count++;
			sum += list.get(i).getMarketPen();
			inCoverage.add(list.get(i));
			if (sum >= coverage) {
				break;
			}
		}
		return count;
	}
}