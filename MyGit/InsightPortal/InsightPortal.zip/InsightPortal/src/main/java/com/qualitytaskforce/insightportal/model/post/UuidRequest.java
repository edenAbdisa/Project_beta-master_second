package com.qualitytaskforce.insightportal.model.post;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
import java.util.UUID;

public class UuidRequest {

    @JsonProperty("uuids")
    private List<UUID> uuids;

    public List<UUID> getUuids() {
        return uuids;
    }

    public void setUuids(List<UUID> uuids) {
        this.uuids = uuids;
    }

}
