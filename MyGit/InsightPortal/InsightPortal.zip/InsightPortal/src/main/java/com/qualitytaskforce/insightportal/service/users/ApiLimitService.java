package com.qualitytaskforce.insightportal.service.users;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.model.users.ApiLimit;
import com.qualitytaskforce.insightportal.repository.users.ApiLimitRepository;

@Service
public class ApiLimitService {

	@Autowired
	ApiLimitRepository repo;

	public ApiLimit save(ApiLimit apiLimit) {
		return repo.save(apiLimit);
	}

	public List<ApiLimit> findByName(String name) {
		return repo.findByName(name);
	}

	public void delete(ApiLimit apiLimit) {
		repo.delete(apiLimit);
	}

    public List<ApiLimit> getAll() {
        return repo.findAll();
    }
}