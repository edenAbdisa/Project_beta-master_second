package com.qualitytaskforce.insightportal.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.qualitytaskforce.insightportal.model.ImpactRating;

public interface ImpactRatingRepository extends JpaRepository<ImpactRating, Long> {
	
	ImpactRating findByName (int name);
}