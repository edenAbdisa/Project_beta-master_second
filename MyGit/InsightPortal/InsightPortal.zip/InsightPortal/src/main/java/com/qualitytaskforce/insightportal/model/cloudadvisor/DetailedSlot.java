package com.qualitytaskforce.insightportal.model.cloudadvisor;

import java.util.List;

public class DetailedSlot {	
	private String ImageLink;
	 private Slot slot;
	 private List<TaskWithOutSlotList> listTask;
	 
	 public DetailedSlot(String imageLink, Slot slot, List<TaskWithOutSlotList> listTask) {
		ImageLink = imageLink;
		this.slot = slot;
		this.listTask = listTask;
	}
	 public DetailedSlot() {}

	 public String getImageLink() {
		return ImageLink;
	}
	public void setImageLink(String imageLink) {
		ImageLink = imageLink;
	}
	public Slot getSlot() {
		return slot;
	}
	public void setSlot(Slot slot) {
		this.slot = slot;
	}
	public List<TaskWithOutSlotList> getListTask() {
		return listTask;
	}
	public void setListTask(List<TaskWithOutSlotList> listTask) {
		this.listTask = listTask;
	}
	
}
