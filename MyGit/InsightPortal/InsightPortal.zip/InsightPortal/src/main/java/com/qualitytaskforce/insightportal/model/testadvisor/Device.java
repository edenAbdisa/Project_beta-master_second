package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Device {
	
	@Id
	private UUID uuid;

	@Column(name = "device_brand")
	private String brand;

	@Column(name = "device_model")
	private String model;

	@Column(name = "marketpen")
	private float marketPen;

	public Device () {
	}

	public Device(UUID uuid, String brand, String model, float marketPen) {
		this.uuid = uuid;
		this.brand = brand;
		this.model = model;
		this.marketPen = marketPen;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	public float getMarketPen() {
		return this.marketPen;
	}

	public void setMarketPen(float marketPen) {
		this.marketPen = marketPen;
	}
}