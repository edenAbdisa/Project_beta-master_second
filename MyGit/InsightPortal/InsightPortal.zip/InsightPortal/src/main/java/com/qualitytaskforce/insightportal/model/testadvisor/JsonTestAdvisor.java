package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;

public class JsonTestAdvisor {
	
	@JsonProperty("country_codes")
	private List<String> countries;

	@JsonProperty("date")
	private String date;

	@JsonProperty("regions")
	private List<String> regions;

	@JsonProperty("coverage")
	private int coverage;

	@JsonProperty("hide_out_of_coverage")
	private boolean hide;

	@JsonProperty("threshold")
	private float threshold;

	@JsonProperty("types")
	private List<String> types;

	@JsonCreator
	public JsonTestAdvisor(@JsonProperty("country_codes") List<String> countries, @JsonProperty("date") String date, 
							@JsonProperty("regions") List<String> regions, @JsonProperty("coverage") int coverage, 
							@JsonProperty("hide_outofcoverage") boolean hide, @JsonProperty("threshold") float threshold,
							@JsonProperty("types") List<String> types) {
		if (date == null) {
			date = "";
		}
		if (types == null) {
			this.types = new ArrayList<String>();
		}
		this.countries = countries;
		this.date = date;
		this.regions = regions;
		this.coverage = coverage;
		this.hide = hide;
		this.threshold = threshold;
		this.types = types;
	}

	public List<String> getCountries() {
		return this.countries;
	}

	public String getDate() {
		return this.date;
	}

	public List<String> getRegions() {
		return this.regions;
	}

	public int getCoverage() {
		return this.coverage;
	}

	public boolean getHide() {
		return this.hide;
	}

	public float getThreshold() {
		return this.threshold;
	}

	public List<String> getTypes() {
		return this.types;
	}
}