package com.qualitytaskforce.insightportal.jsoupcrawler;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "ta_devices")
public class DetailModel implements java.io.Serializable {

  private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;

  @Column(name = "model", length = 255 )
  public String   model;
  @Column(name = "brand", length = 50 )
  public String   brand;
  
  @Column(name = "img_link", length = 255 )
  public String   imgLink;
  @Column(name = "general_status", length = 255 )
  public String   GENERALstatus;
  @Column(name = "general_os", length = 255 )
  public String   GENERALos;
  @Column(name = "general_size", length = 50 )
  public String   GENERALsize;
  @Column(name = "general_resolution", length = 100 )
  public String   GENERALresolution;
  @Column(name = "ram", length = 50 )
  public String   GENERALram;
  @Column(name = "general_chipset", length = 50 )
  public String   GENERALchipset;
  @Column(name = "battery", length = 50 )
  public String   GENERALbattery;
	
  @Column(name = "technology", length = 50 )
  public String   NETWORK_Technology;
  @Column(name = "2g_bands", length = 255 )
  public String   NETWORK_2GBands;
  @Column(name = "3g_bands", length = 255 )
  public String   NETWORK_3GBands;
  @Column(name = "4g_bands", length = 255 )
  public String   NETWORK_4GBands;
  @Column(name = "network_speed", length = 255 )
  public String   NETWORK_Speed;
  @Column(name = "gprs", length = 50 )
  public String   NETWORK_GPRS;
  @Column(name = "edge", length = 50 )
  public String   NETWORK_EDGE;

  @Column(name = "announced_date", length = 255 )
  public String   LAUNCH_Announced;
  @Column(name = "status", length = 255 )
  public String   LAUNCH_Status;

  @Column(name = "dimensions", length = 255 )
  public String   BODY_Dimensions;
  @Column(name = "weight", length = 50 )
  public String   BODY_Weight;
  @Column(name = "build", length = 255 )
  public String   BODY_Build;
  @Column(name = "sim", length = 255 )
  public String   BODY_SIM;

  @Column(name = "display_type", length = 255 )
  public String   DISPLAY_Type;
  @Column(name = "display_size", length = 255 )
  public String   DISPLAY_Size;
  @Column(name = "display_res", length = 255 )
  public String   DISPLAY_Resolution;
  @Column(name = "multi_touch", length = 255 )
  public String   DISPLAY_Multitouch;
  @Column(name = "display_protection", length = 255 )
  public String   DISPLAY_Protection;

  @Column(name = "os", length = 255 )
  public String   PLATFORM_OS;
  @Column(name = "chipset", length = 255 )
  public String   PLATFORM_Chipset;
  @Column(name = "cpu", length = 255 )
  public String   PLATFORM_CPU;
  @Column(name = "gpu", length = 255 )
  public String   PLATFORM_GPU;

  @Column(name = "card_slot", length = 255 )
  public String   MEMORY_CardSlot;
  @Column(name = "internal_storage", length = 255 )
  public String   MEMORY_Internal;

  @Column(name = "primary_camera", length = 255 )
  public String   CAMERA_Primary;
  @Column(name = "camera_features", length = 255 )
  public String   CAMERA_Features;
  @Column(name = "video_features", length = 255 )
  public String   CAMERA_Video;
  @Column(name = "secondary_camera", length = 255 )
  public String   CAMERA_Secondary;

  @Column(name = "alert_types", length = 255 )
  public String   SOUND_AlertTypes;
  @Column(name = "loudspeaker", length = 255 )
  public String   SOUND_Loudspeaker;
  @Column(name = "3_5mm_jack", length = 50 )
  public String   SOUND_35mmjack;

  @Column(name = "wlan", length = 255 )
  public String   COMMS_WLAN;
  @Column(name = "bluetooth", length = 255 )
  public String   COMMS_Bluetooth;
  @Column(name = "gps", length = 255 )
  public String   COMMS_GPS;
  @Column(name = "nfc", length = 50 )
  public String   COMMS_NFC;
  @Column(name = "infrared_port", length = 50 )
  public String   COMMS_InfraredPort;
  @Column(name = "radio", length = 50 )
  public String   COMMS_Radio;
  @Column(name = "usb", length = 255 )
  public String   COMMS_USB;

  @Column(name = "sensors", length = 255 )
  public String   FEATURES_Sensors;
  @Column(name = "messaging", length = 255 )
  public String   FEATURES_Messaging;
  @Column(name = "browser", length = 255 )
  public String   FEATURES_Browser;

  @Column(name = "stand_by", length = 255 )
  public String   BATTERY_StandBy;
  @Column(name = "talk_time", length = 255 )
  public String   BATTERY_TalkTime;
  @Column(name = "music_time", length = 255 )
  public String   BATTERY_MusicPlay;

  @Column(name = "colours", length = 255 )
  public String   MISC_Colors;
  @Column(name = "sar", length = 255 )
  public String   MISC_SAR;
  @Column(name = "sar_eu", length = 255 )
  public String   MISC_SAR_EU;
  @Column(name = "price", length = 50 )
  public String   MISC_PriceGroup;
  @Column(name = "performance", length = 255 )
  public String   TESTS_Performance;
  
  @Column(name = "other_body_features", length = 255 )
  public String   otherBodyFeatures;
  @Column(name = "other_display_features", length = 350 )
  public String   otherDisplayFeatures;
  @Column(name = "other_sound_features", length = 255 )
  public String   otherSoundFeatures;
  @Column(name = "other_features", length = 500 )
  public String   otherFeatures;
  @Column(name = "battery_details", length = 255 )
  public String   batteryDetails;
  
  public UUID getUuid() {
	  return uuid;
  }
  
  public void setUuid(UUID uuid) {
	  this.uuid = uuid;
  }
  
  public String getModel() {
	return model;
}

public void setModel(String model) {
	this.model = model;
}

public String getBrand() {
	return brand;
}

public void setBrand(String brand) {
	this.brand = brand;
}

public String getNETWORK_Technology() {
    return NETWORK_Technology;
  }

  public void setNETWORK_Technology(String NETWORK_Technology) {
    this.NETWORK_Technology = NETWORK_Technology;
  }

  public String getNETWORK_2GBands() {
    return NETWORK_2GBands;
  }

  public void setNETWORK_2GBands(String NETWORK_2GBands) {
    this.NETWORK_2GBands = NETWORK_2GBands;
  }

  public String getNETWORK_3GBands() {
    return NETWORK_3GBands;
  }

  public void setNETWORK_3GBands(String NETWORK_3GBands) {
    this.NETWORK_3GBands = NETWORK_3GBands;
  }

  public String getNETWORK_4GBands() {
    return NETWORK_4GBands;
  }

  public void setNETWORK_4GBands(String NETWORK_4GBands) {
    this.NETWORK_4GBands = NETWORK_4GBands;
  }

  public String getNETWORK_Speed() {
    return NETWORK_Speed;
  }

  public void setNETWORK_Speed(String NETWORK_Speed) {
    this.NETWORK_Speed = NETWORK_Speed;
  }

  public String getNETWORK_GPRS() {
    return NETWORK_GPRS;
  }

  public void setNETWORK_GPRS(String NETWORK_GPRS) {
    this.NETWORK_GPRS = NETWORK_GPRS;
  }

  public String getNETWORK_EDGE() {
    return NETWORK_EDGE;
  }

  public void setNETWORK_EDGE(String NETWORK_EDGE) {
    this.NETWORK_EDGE = NETWORK_EDGE;
  }

  public String getLAUNCH_Announced() {
    return LAUNCH_Announced;
  }

  public void setLAUNCH_Announced(String LAUNCH_Announced) {
    this.LAUNCH_Announced = LAUNCH_Announced;
  }

  public String getLAUNCH_Status() {
    return LAUNCH_Status;
  }

  public void setLAUNCH_Status(String LAUNCH_Status) {
    this.LAUNCH_Status = LAUNCH_Status;
  }

  public String getBODY_Dimensions() {
    return BODY_Dimensions;
  }

  public void setBODY_Dimensions(String BODY_Dimensions) {
    this.BODY_Dimensions = BODY_Dimensions;
  }

  public String getBODY_Weight() {
    return BODY_Weight;
  }

  public void setBODY_Weight(String BODY_Weight) {
    this.BODY_Weight = BODY_Weight;
  }

  public String getBODY_Build() {
	return BODY_Build;
  }

  public void setBODY_Build(String BODY_Build) {
	this.BODY_Build = BODY_Build;
  }

public String getBODY_SIM() {
    return BODY_SIM;
  }

  public void setBODY_SIM(String BODY_SIM) {
    this.BODY_SIM = BODY_SIM;
  }

  public String getDISPLAY_Type() {
    return DISPLAY_Type;
  }

  public void setDISPLAY_Type(String DISPLAY_Type) {
    this.DISPLAY_Type = DISPLAY_Type;
  }

  public String getDISPLAY_Size() {
    return DISPLAY_Size;
  }

  public void setDISPLAY_Size(String DISPLAY_Size) {
    this.DISPLAY_Size = DISPLAY_Size;
  }

  public String getDISPLAY_Resolution() {
    return DISPLAY_Resolution;
  }

  public void setDISPLAY_Resolution(String DISPLAY_Resolution) {
    this.DISPLAY_Resolution = DISPLAY_Resolution;
  }

  public String getDISPLAY_Multitouch() {
    return DISPLAY_Multitouch;
  }

  public void setDISPLAY_Multitouch(String DISPLAY_Multitouch) {
    this.DISPLAY_Multitouch = DISPLAY_Multitouch;
  }

  public String getDISPLAY_Protection() {
    return DISPLAY_Protection;
  }

  public void setDISPLAY_Protection(String DISPLAY_Protection) {
    this.DISPLAY_Protection = DISPLAY_Protection;
  }

  public String getPLATFORM_OS() {
    return PLATFORM_OS;
  }

  public void setPLATFORM_OS(String PLATFORM_OS) {
    this.PLATFORM_OS = PLATFORM_OS;
  }

  public String getPLATFORM_Chipset() {
    return PLATFORM_Chipset;
  }

  public void setPLATFORM_Chipset(String PLATFORM_Chipset) {
    this.PLATFORM_Chipset = PLATFORM_Chipset;
  }

  public String getPLATFORM_CPU() {
    return PLATFORM_CPU;
  }

  public void setPLATFORM_CPU(String PLATFORM_CPU) {
    this.PLATFORM_CPU = PLATFORM_CPU;
  }

  public String getPLATFORM_GPU() {
    return PLATFORM_GPU;
  }

  public void setPLATFORM_GPU(String PLATFORM_GPU) {
    this.PLATFORM_GPU = PLATFORM_GPU;
  }

  public String getMEMORY_CardSlot() {
    return MEMORY_CardSlot;
  }

  public void setMEMORY_CardSlot(String MEMORY_CardSlot) {
    this.MEMORY_CardSlot = MEMORY_CardSlot;
  }

  public String getMEMORY_Internal() {
    return MEMORY_Internal;
  }

  public void setMEMORY_Internal(String MEMORY_Internal) {
    this.MEMORY_Internal = MEMORY_Internal;
  }

  public String getCAMERA_Features() {
    return CAMERA_Features;
  }

  public void setCAMERA_Features(String CAMERA_Features) {
    this.CAMERA_Features = CAMERA_Features;
  }

  public String getCAMERA_Primary() {
    return CAMERA_Primary;
  }

  public void setCAMERA_Primary(String CAMERA_Primary) {
    this.CAMERA_Primary = CAMERA_Primary;
  }

  public String getCAMERA_Video() {
    return CAMERA_Video;
  }

  public void setCAMERA_Video(String CAMERA_Video) {
    this.CAMERA_Video = CAMERA_Video;
  }

  public String getCAMERA_Secondary() {
    return CAMERA_Secondary;
  }

  public void setCAMERA_Secondary(String CAMERA_Secondary) {
    this.CAMERA_Secondary = CAMERA_Secondary;
  }

  public String getSOUND_AlertTypes() {
    return SOUND_AlertTypes;
  }

  public void setSOUND_AlertTypes(String SOUND_AlertTypes) {
    this.SOUND_AlertTypes = SOUND_AlertTypes;
  }

  public String getSOUND_Loudspeaker() {
    return SOUND_Loudspeaker;
  }

  public void setSOUND_Loudspeaker(String SOUND_Loudspeaker) {
    this.SOUND_Loudspeaker = SOUND_Loudspeaker;
  }

  public String getSOUND_35mmjack() {
    return SOUND_35mmjack;
  }

  public void setSOUND_35mmjack(String SOUND_35mmjack) {
    this.SOUND_35mmjack = SOUND_35mmjack;
  }

  public String getCOMMS_WLAN() {
    return COMMS_WLAN;
  }

  public void setCOMMS_WLAN(String COMMS_WLAN) {
    this.COMMS_WLAN = COMMS_WLAN;
  }

  public String getCOMMS_Bluetooth() {
    return COMMS_Bluetooth;
  }

  public void setCOMMS_Bluetooth(String COMMS_Bluetooth) {
    this.COMMS_Bluetooth = COMMS_Bluetooth;
  }

  public String getCOMMS_GPS() {
    return COMMS_GPS;
  }

  public void setCOMMS_GPS(String COMMS_GPS) {
    this.COMMS_GPS = COMMS_GPS;
  }
  
  public String getCOMMS_NFC() {
    return COMMS_NFC;
  }

  public void setCOMMS_NFC(String COMMS_NFC) {
    this.COMMS_NFC = COMMS_NFC;
  }

  public String getCOMMS_InfraredPort() {
	return COMMS_InfraredPort;
}

public void setCOMMS_InfraredPort(String COMMS_InfraredPort) {
	this.COMMS_InfraredPort = COMMS_InfraredPort;
}

public String getCOMMS_Radio() {
    return COMMS_Radio;
  }

  public void setCOMMS_Radio(String COMMS_Radio) {
    this.COMMS_Radio = COMMS_Radio;
  }

  public String getCOMMS_USB() {
    return COMMS_USB;
  }

  public void setCOMMS_USB(String COMMS_USB) {
    this.COMMS_USB = COMMS_USB;
  }

  public String getFEATURES_Sensors() {
    return FEATURES_Sensors;
  }

  public void setFEATURES_Sensors(String FEATURES_Sensors) {
    this.FEATURES_Sensors = FEATURES_Sensors;
  }

  public String getFEATURES_Messaging() {
    return FEATURES_Messaging;
  }

  public void setFEATURES_Messaging(String FEATURES_Messaging) {
    this.FEATURES_Messaging = FEATURES_Messaging;
  }

  public String getFEATURES_Browser() {
    return FEATURES_Browser;
  }

  public void setFEATURES_Browser(String FEATURES_Browser) {
    this.FEATURES_Browser = FEATURES_Browser;
  }

  public String getBATTERY_StandBy() {
    return BATTERY_StandBy;
  }

  public void setBATTERY_StandBy(String BATTERY_StandBy) {
    this.BATTERY_StandBy = BATTERY_StandBy;
  }

  public String getBATTERY_TalkTime() {
    return BATTERY_TalkTime;
  }

  public void setBATTERY_TalkTime(String BATTERY_TalkTime) {
    this.BATTERY_TalkTime = BATTERY_TalkTime;
  }

  public String getBATTERY_MusicPlay() {
    return BATTERY_MusicPlay;
  }

  public void setBATTERY_MusicPlay(String BATTERY_MusicPlay) {
    this.BATTERY_MusicPlay = BATTERY_MusicPlay;
  }

  public String getMISC_Colors() {
    return MISC_Colors;
  }

  public void setMISC_Colors(String MISC_Colors) {
    this.MISC_Colors = MISC_Colors;
  }
  
  public String getMISC_SAR() {
	return MISC_SAR;
  }

  public void setMISC_SAR(String MISC_SAR) {
	this.MISC_SAR = MISC_SAR;
  }

  public String getMISC_SAR_EU() {
	return MISC_SAR_EU;
  }

  public void setMISC_SAR_EU(String MISC_SAR_EU) {
	this.MISC_SAR_EU = MISC_SAR_EU;
  }

  public String getMISC_PriceGroup() {
    return MISC_PriceGroup;
  }

  public void setMISC_PriceGroup(String MISC_PriceGroup) {
    this.MISC_PriceGroup = MISC_PriceGroup;
  }

  public String getImgLink() {
	return imgLink;
  }

  public void setImgLink(String imgLink) {
	this.imgLink = imgLink;
  }

  public String getGENERALstatus() {
	return GENERALstatus;
  }

  public void setGENERALstatus(String GENERALstatus) {
	this.GENERALstatus = GENERALstatus;
  }

  public String getGENERALos() {
	return GENERALos;
  }

  public void setGENERALos(String GENERALos) {
	this.GENERALos = GENERALos;
  }

  public String getGENERALsize() {
	return GENERALsize;
  }

  public void setGENERALsize(String GENERALsize) {
	this.GENERALsize = GENERALsize;
  }

  public String getGENERALresolution() {
	return GENERALresolution;
  }

  public void setGENERALresolution(String GENERALresolution) {
	this.GENERALresolution = GENERALresolution;
  }

  public String getGENERALram() {
	return GENERALram;
  }

  public void setGENERALram(String GENERALram) {
	this.GENERALram = GENERALram;
  }

  public String getGENERALchipset() {
	return GENERALchipset;
  }

  public void setGENERALchipset(String GENERALchipset) {
	this.GENERALchipset = GENERALchipset;
  }

  public String getGENERALbattery() {
	return GENERALbattery;
  }

  public void setGENERALbattery(String GENERALbattery) {
	this.GENERALbattery = GENERALbattery;
  }

  public String getTESTS_Performance() {
	return TESTS_Performance;
  }

  public void setTESTS_Performance(String TESTS_Performance) {
	this.TESTS_Performance = TESTS_Performance;
  }

public String getOtherBodyFeatures() {
	return otherBodyFeatures;
}

public void setOtherBodyFeatures(String otherBodyFeatures) {
	this.otherBodyFeatures = otherBodyFeatures;
}

public String getOtherDisplayFeatures() {
	return otherDisplayFeatures;
}

public void setOtherDisplayFeatures(String otherDisplayFeatures) {
	this.otherDisplayFeatures = otherDisplayFeatures;
}

public String getOtherSoundFeatures() {
	return otherSoundFeatures;
}

public void setOtherSoundFeatures(String otherSoundFeatures) {
	this.otherSoundFeatures = otherSoundFeatures;
}

public String getOtherFeatures() {
	return otherFeatures;
}

public void setOtherFeatures(String otherFeatures) {
	this.otherFeatures = otherFeatures;
}

public String getBatteryDetails() {
	return batteryDetails;
}

public void setBatteryDetails(String batteryDetails) {
	this.batteryDetails = batteryDetails;
}
  
  
  
}