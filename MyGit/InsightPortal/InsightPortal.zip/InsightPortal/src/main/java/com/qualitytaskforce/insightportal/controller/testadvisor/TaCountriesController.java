package com.qualitytaskforce.insightportal.controller.testadvisor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.testadvisor.Country;
import com.qualitytaskforce.insightportal.model.testadvisor.CountryWithName;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import com.qualitytaskforce.insightportal.service.TestAdvisorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/testadvisor")
public class TaCountriesController {

	@Autowired
	private TestAdvisorService service;

	private HttpHeaders headers = new HttpHeaders();

	@Autowired
	private MessageUtil util;

	@RequestMapping(value = "/countries", method = RequestMethod.GET)
	public ResponseEntity<?> countries() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		List<Country> countries = service.getAllCountries();
		List<CountryWithName> details = new ArrayList<>();
		details = getCountryDetails(countries);
		return new ResponseEntity<List<CountryWithName>>(details, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/regions", method = RequestMethod.GET)
	public ResponseEntity<?> regions() {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		List<String> regions = service.getAllRegions();
		regions.add("WWW");
		return new ResponseEntity<List<String>>(regions, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/countriesbyregion/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> countriesByRegion(@PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		List<Country> countries = new ArrayList<>();
		List<CountryWithName> details = new ArrayList<>();
		if (code.equals("WWW")) {
			countries = service.getAllCountries();
		} else {
			List<String> region = new ArrayList<>();
			region.add(code);

			countries = service.getCountriesByRegion(region);
		}
		details = getCountryDetails(countries);
		if (details.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.country.no-region-data"));
		}
		return new ResponseEntity<List<CountryWithName>>(details, headers, HttpStatus.OK);
	}

	private List<CountryWithName> getCountryDetails(List<Country> countries) {
		List<CountryWithName> list = new ArrayList<>();
		CountryWithName temp = new CountryWithName();
		for (int i = 0; i < countries.size(); i++) {
			temp = new CountryWithName(countries.get(i).getCode(), countries.get(i).getName(), countries.get(i).getRegion());
			list.add(temp);
		}
		Collections.sort(list);
		return list;
	}

}