package com.qualitytaskforce.insightportal.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.validation.Valid;
import com.qualitytaskforce.insightportal.service.*;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.error.SaveEntityException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ArticleUpdate;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.Subcategory;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleCrudList;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.model.articleModifications.single.ArticleUpdateWhenSingle;
import com.qualitytaskforce.insightportal.model.articleModifications.single.ArticleWhenSingle;
import com.qualitytaskforce.insightportal.model.post.ArticleCombinedRequest;
import com.qualitytaskforce.insightportal.model.post.RelatedArticlesRequest;
import com.qualitytaskforce.insightportal.model.post.UuidRequest;
import com.qualitytaskforce.insightportal.model.put.ArticleCombinedRequestUpdate;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.model.response.BatchResponse;
import com.qualitytaskforce.insightportal.service.backoffice.ArticleServiceGet;
import com.qualitytaskforce.insightportal.service.backoffice.ArticleServicePost;
import com.qualitytaskforce.insightportal.service.backoffice.ArticleServicePut;
import com.qualitytaskforce.insightportal.service.relatedarticles.GenerateRelated;
import com.qualitytaskforce.insightportal.service.relatedarticles.GetRelatedBySefUrl;
import com.qualitytaskforce.insightportal.service.relatedarticles.SaveRelatedByCategory;
import com.qualitytaskforce.insightportal.util.DateToString;
import com.qualitytaskforce.insightportal.util.HtmlToString;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;
import com.qualitytaskforce.insightportal.util.VerifyUUID;

@RestController
@RequestMapping(value = "/article")
public class ArticleController {

    private static final Logger LOGGER = LoggerFactory.getLogger(ArticleController.class);

    @Autowired
    private ArticleService articleService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ArticleServicePut acPut;

    @Autowired
    private ArticleServicePost acPost;

    @Autowired
    private ArticleUpdateService articleUpdateService;

    @Autowired
    private SubcategoryService subcategoryService;

    @Autowired
    private SaveRelatedByCategory saveRelatedByCategory;

    @Autowired
    private GenerateRelated generateRelated;

    @Autowired
    private GetRelatedBySefUrl getRelatedBySefUrl;

    @Autowired
    private ArticleServiceGet articleServiceGet;

    @Autowired
    private ArticleLinkService articleLinkService;
    
    private HttpHeaders headers = new HttpHeaders();


    private List<ArticleCrudList> prepareCrudList(List<Article> articles) {

        ArticleCrudList article;
        List<ArticleCrudList> articlesCutted = new ArrayList<>();
        SimpleDateFormat sdf = new SimpleDateFormat("YYY-MM-dd");

        for (int i = 0; i < articles.size(); i++) {

            article = new ArticleCrudList();
            String dateStr = sdf.format(articles.get(i).getCreatedAt());
            article.setReadTime(articles.get(i).getViewCount());
            article.setTitle(articles.get(i).getTitle());
            article.setAuthor(articles.get(i).getUserByCreatedBy().getName(),
                    articles.get(i).getUserByCreatedBy().getSurname());
            article.setUuid(articles.get(i).getUuid());
            article.setPublished(articles.get(i).getPublished());
            article.setImpactRating(articles.get(i).getImpactRating().getName());
            article.setSefURL(articles.get(i).getSefURL());
            article.setFeature(articles.get(i).isFeatured());
            article.setCreatedAt(dateStr);
            article.setCategory(articles.get(i).getCategory().getName());
            article.setSubcategory(articles.get(i).getSubcategory());
            article.setUpdatedAt(sdf.format(articles.get(i).getUpdatedAt()));
            articlesCutted.add(article);
        }

        return articlesCutted;
    }

    @GetMapping(value = "/{uuid}")
    public ResponseEntity<Article> getByUuid(@PathVariable("uuid") String uuidString)
            throws DataNotFoundException {

        Article article = articleService.findByUUIDString(uuidString);
        if (article == null) {
            throw new DataNotFoundException("Article with the specified UUID does not exist.");
        }
        return new ResponseEntity<>(article, HttpStatus.OK);
    }

    // delete single article
    @RequestMapping(value = "{uuid}", method = RequestMethod.DELETE)
    public @ResponseBody ResponseEntity<String> deleteArticle(@PathVariable("uuid") UUID uuid)
            throws Exception {
        articleService.deleteArticle(uuid);
        String response = "{\"status\":200}";
        
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }

    // delete list of article
    @RequestMapping(value = "bulk-delete", method = RequestMethod.POST)
    public @ResponseBody ResponseEntity<?> batchDeleteArticle(@RequestBody UuidRequest uuids)
            throws Exception {
        List<UUID> uuidsList = uuids.getUuids();
        Iterator<UUID> iterator = uuidsList.iterator();
        BatchResponse response = new BatchResponse("Article");
        while (iterator.hasNext()) {
            UUID uuidNext = iterator.next();
            boolean isDeleted = articleService.deleteArticle(uuidNext);
            if (!isDeleted) {
                LOGGER.info("this article not exist");
                LOGGER.info(String.valueOf(uuidNext));
                response.push(uuidNext, "failure"); // failure status for non exist article
            } else {
                response.push(uuidNext, "success");
                LOGGER.info(String.valueOf(uuidNext));
            }
        }

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }

    /**
     * Methods which associated with - CREATE NEW ARTICLE
     */

    @PostMapping(value = "")
    public ResponseEntity<ArticleCombinedRequest> createArticlePost(
            @Valid @RequestBody ArticleCombinedRequest articleCombinedRequest)
            throws SaveEntityException {

        acPost.backofficePost(articleCombinedRequest);
        return new ResponseEntity<>(articleCombinedRequest, HttpStatus.OK);
    }

    /**
     * Methods which associated with - EDIT EXIST ARTICLE
     *
     * @throws DataNotFoundException
     */

    @GetMapping("/{uuid}/edit")
    public ResponseEntity<?> editArticleGet(@PathVariable("uuid") UUID uuid)
            throws DataNotFoundException {

        Map<String, Object> articleMap = articleServiceGet.getExisting(uuid);
        return new ResponseEntity<>(articleMap, HttpStatus.OK);
    }

    @PutMapping(value = "/{uuid}")
    public ResponseEntity<?> editArticlePost(
            @Valid @RequestBody ArticleCombinedRequestUpdate articleCombinedRequest)
            throws SaveEntityException, DataNotFoundException {


        acPut.backofficePut(articleCombinedRequest);
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    /**
     * Methods which associated with - TEST COUNTER OF ARTICLES
     *
     * @throws DataNotFoundException
     * @throws InvalidParameterFormatException
     * @throws NumberFormatException
     */

    @PutMapping("/count-article/{uuid}")
    public ResponseEntity<String> incrementViewCountArticle(@PathVariable("uuid") String uuidString)
            throws InvalidParameterFormatException, NumberFormatException, DataNotFoundException {

        UUID uuid = VerifyUUID.verifyUUID(uuidString);
        boolean isExistArticle = articleService.updateCounter(uuid);
        if (isExistArticle == false) {
            throw new InvalidParameterFormatException("UUID is invalid");
        }

        return new ResponseEntity<>(uuidString, HttpStatus.OK);
    }

    @GetMapping("/set-related/{category-name}")
    public ResponseEntity<String> createRelated(@PathVariable("category-name") String categoryName)
            throws Exception {

        saveRelatedByCategory.saveRelated(categoryName);
        return new ResponseEntity<>("Related was saved successfully", HttpStatus.OK);
    }

    @PostMapping("/generate-related")
    public ResponseEntity<List<String>> getRelatedByArticleSefUrl(
            @RequestBody RelatedArticlesRequest input) throws DataNotFoundException {

        List<String> topRelatedArticlesTitles = generateRelated.generate(input);
        return new ResponseEntity<List<String>>(topRelatedArticlesTitles, HttpStatus.OK);
    }

    @GetMapping("/get-related/{sef-url}")
    public ResponseEntity<List<ArticleWhenList>> getRelatedByArticle(
            @PathVariable("sef-url") String sefUrl) throws Exception {

        List<ArticleWhenList> relatedList = getRelatedBySefUrl.getRelated(sefUrl);
        return new ResponseEntity<List<ArticleWhenList>>(relatedList, HttpStatus.OK);
    }

    /**
     * Get ArticleWhenSingle by its UUID (used in ReleaseAdvisor front-end component)
     *
     * @param uuid
     * @return
     * @throws Exception
     */

    @GetMapping("/get-article-by-uuid/{uuid}")
    public ResponseEntity<ArticleWhenSingle> getArticleByUuid(@PathVariable("uuid") String uuid)
            throws Exception {
        DateToString dateString = new DateToString();
        Article article = articleService.findByUUID(UUID.fromString(uuid));
        if (article == null) {
            throw new DataNotFoundException("Not found article by sefUrl");
        }

        article.setViewCount(article.getViewCount() + 1);
        articleService.save(article);

        List<ArticleUpdate> artUpdates = articleUpdateService.findAllByArticle(article);
        List<ArticleUpdateWhenSingle> listOfUpdatesMod = new ArrayList<ArticleUpdateWhenSingle>();

        for (int i = 0; i < artUpdates.size(); i++) {
            ArticleUpdateWhenSingle artUpdateMod = new ArticleUpdateWhenSingle();
            String dateStr = dateString.dateToString(artUpdates.get(i).getUpdatedAt());
            artUpdateMod.setUpdateAt(dateStr);
            artUpdateMod.setContent(artUpdates.get(i).getContent());
            artUpdateMod.setReadTime(artUpdates.get(i).getReadTime());
            listOfUpdatesMod.add(artUpdateMod);
        }

        ArticleWhenSingle mod = new ArticleWhenSingle();
        mod.setTitle(article.getTitle());
        mod.setEditorName(article.getUserByCreatedBy().getName());
        mod.setEditorSurname(article.getUserByCreatedBy().getSurname());
        mod.setReadTime(article.getReadTime());
        mod.setImpactRating(article.getImpactRating().getName());
        String dateStr = dateString.dateToString(article.getPublishDate());
        mod.setDateOfPublished(dateStr);
        mod.setReadTime(article.getReadTime());
        mod.setSummaryText(article.getSummaryText());
        mod.setArticleUpdates(listOfUpdatesMod);

        if (article.getTestRecommendation() != null) {
            mod.setTestRecommendation(article.getTestRecommendation().getContent());
        }
        mod.setFullText(article.getFullText());
        mod.setRichcardId(article.getRichcardId());
        mod.setRichcardType(article.getRichcardType());
        mod.setCategory(article.getCategory().getName());
        mod.setSubcategory(article.getSubcategory());

        return new ResponseEntity<ArticleWhenSingle>(mod, HttpStatus.OK);
    }


    @GetMapping("/get-article/{sef-url}")
    public ResponseEntity<ArticleWhenSingle> getArticleBySefUrl(
            @PathVariable("sef-url") String sefUrl) throws Exception, DataNotFoundException {

        DateToString dateString = new DateToString();
        Article article = articleService.findBySefURL(sefUrl);

        if (article == null || !article.getPublished()) {
            throw new DataNotFoundException("Not found article by sefUrl");
        }

        article.setViewCount(article.getViewCount() + 1);
        articleService.save(article);

        List<ArticleUpdate> artUpdates = articleUpdateService.findAllByArticle(article);
        artUpdates.sort((u1, u2) -> u2.getUpdatedAt().compareTo(u1.getUpdatedAt()));

        List<ArticleUpdateWhenSingle> listOfUpdatesMod = new ArrayList<ArticleUpdateWhenSingle>();

        for (ArticleUpdate au : artUpdates) {
            ArticleUpdateWhenSingle artUpdateMod = new ArticleUpdateWhenSingle();
            String dateStr = dateString.dateToString(au.getUpdatedAt());
            artUpdateMod.setUpdateAt(dateStr);
            artUpdateMod.setContent(au.getContent());
            artUpdateMod.setReadTime(au.getReadTime());
            listOfUpdatesMod.add(artUpdateMod);
        }

        ArticleWhenSingle mod = new ArticleWhenSingle();

        mod.setTitle(article.getTitle());
        mod.setEditorName(article.getUserByCreatedBy().getName());
        mod.setEditorSurname(article.getUserByCreatedBy().getSurname());
        mod.setReadTime(article.getReadTime());
        mod.setImpactRating(article.getImpactRating().getName());
        String dateStr = dateString.dateToString(article.getPublishDate());

        mod.setDateOfPublished(dateStr);
        mod.setReadTime(article.getReadTime());
        mod.setSummaryText(article.getSummaryText());
        mod.setArticleUpdates(listOfUpdatesMod);

        if (article.getTestRecommendation() != null) {
            mod.setTestRecommendation(article.getTestRecommendation().getContent());
        }

        mod.setFullText(article.getFullText());
        mod.setRichcardId(article.getRichcardId());
        mod.setRichcardType(article.getRichcardType());
        mod.setCategory(article.getCategory().getName());
        mod.setSubcategory(article.getSubcategory());

        return new ResponseEntity<ArticleWhenSingle>(mod, HttpStatus.OK);
    }

    @GetMapping("/get-subcategories")
    public ResponseEntity<List<String>> getSubcategories(
            @RequestParam(value = "category") String categoryResponse)
            throws Exception, DataNotFoundException {

        List<Subcategory> subcategoriesObj = new ArrayList<Subcategory>();
        HashSet<String> subcategHashSet = new HashSet<String>();
        List<String> subcategoriesStr = new ArrayList<String>();

        if (categoryResponse.trim().length() < 1) {
            throw new Exception("Category param is empty");
        }

        if (categoryResponse.equals("All News")) {
            subcategoriesObj = subcategoryService.findAllSubcategories();
            if (subcategoriesObj.size() < 1) {
                throw new DataNotFoundException("No subcategories found");
            }
        } else if (categoryResponse.equals("Rumours & Trends")) {
            return new ResponseEntity<List<String>>(subcategoriesStr, HttpStatus.NO_CONTENT);
        } else {
            Category category = categoryService.findByName(categoryResponse);
            if (category == null) {
                throw new DataNotFoundException("No category found");
            }
            subcategoriesObj = subcategoryService.findAllByCategory(category);
            if (subcategoriesObj.size() < 1) {
                throw new DataNotFoundException("No subcategory found");
            }
        }


        boolean isOtherExist = false;
        for (Subcategory subcategory : subcategoriesObj) {
            String subcategoryName = subcategory.getName();
            if (!subcategoryName.equals("Other") && subcategHashSet.add(subcategoryName)) {
                subcategoriesStr.add(subcategoryName);
            } else {
                isOtherExist = true;
            }
        }
        subcategoriesStr.sort((p1, p2) -> p1.compareTo(p2));

        if (isOtherExist) {
            subcategoriesStr.add("Other");
        }

        return new ResponseEntity<List<String>>(subcategoriesStr, HttpStatus.OK);
    }

    @GetMapping("/get-recent")
    public ResponseEntity<List<ArticleWhenList>> getRecent() {

        List<Category> categories = categoryService.getAllCategories();
        List<Article> recentArticles = articleService.findByLimit(categories, "desc", 0, 7);
        List<ArticleWhenList> prepared = PrepareToShowInList.prepare(recentArticles);

        return new ResponseEntity<List<ArticleWhenList>>(prepared, HttpStatus.OK);
    }

    @GetMapping("/get-most-popular")
    public ResponseEntity<List<ArticleWhenList>> getMostPopular() {
        Date stop = new Date();
        LocalDate now = new LocalDate(stop);
        LocalDate thirty = now.minusDays(60);
        Date start = thirty.toDateTimeAtStartOfDay().toDate();

        List<Article> articles = articleService.findByDateViewCountAscDesc(start, stop, true);
        List<ArticleWhenList> prepared = PrepareToShowInList.prepare(articles);

        return new ResponseEntity<List<ArticleWhenList>>(prepared, HttpStatus.OK);
    }

    @GetMapping(value = "")
    public ResponseEntity<List<ArticleCrudList>> index() {
        List<Article> articles = articleService.getSortedDateAscDesc("desc");
        List<ArticleCrudList> articlesCutted = prepareCrudList(articles);
        return new ResponseEntity<List<ArticleCrudList>>(articlesCutted, HttpStatus.OK);
    }

    @GetMapping(value = "/admin")
    public ResponseEntity<List<ArticleCrudList>> getAllArticlesForAdmin() {
        List<Article> articles = articleService.getSortedDateAscDesc("desc");
        List<ArticleCrudList> articlesCutted = prepareCrudList(articles);
        return new ResponseEntity<List<ArticleCrudList>>(articlesCutted, HttpStatus.OK);
    }

    /*****
     * Method make an Articles publish
     ***/

    @PutMapping(value = "/publish")
    public ResponseEntity<?> publish(@RequestBody UuidRequest uuids) {
        List<UUID> uuidsList = uuids.getUuids();
        Iterator<UUID> iterator = uuidsList.iterator();
        while (iterator.hasNext()) {
            articleService.publishToggle(iterator.next(), true);
        }
        String response = "{\"status\":200}";
        return new ResponseEntity<String>(response, HttpStatus.OK);
    }

    /*****
     * Method make an Articles unpublished
     ***/
    @PutMapping(value = "/unpublish")
    public ResponseEntity<?> unpublish(@RequestBody UuidRequest uuids) {
        List<UUID> uuidsList = uuids.getUuids();
        Iterator<UUID> iterator = uuidsList.iterator();
        while (iterator.hasNext()) {
            articleService.publishToggle(iterator.next(), false);
        }
        ApiResponse response = new ApiResponse("success", "Articles has been marked as unfeatured");
        return new ResponseEntity<ApiResponse>(response, HttpStatus.OK);
    }

    /*****
     * Method archive Articles
     ***/
    @PutMapping(value = "/reset_count")
    public ResponseEntity<?> archive(@RequestBody UuidRequest uuids) {
        List<UUID> uuidsList = uuids.getUuids();
        Iterator<UUID> iterator = uuidsList.iterator();
        while (iterator.hasNext()) {
            boolean isExist = articleService.resetCount(iterator.next());
            LOGGER.info(String.valueOf(isExist));
        }
        ApiResponse apiResponse =
                new ApiResponse("success", "Article's status has been changed to unpublished");

        return new ResponseEntity<>(apiResponse, HttpStatus.OK);
    }

    @PutMapping(value = "/featured")
    public ResponseEntity<?> featured(@RequestBody UuidRequest uuids) {
        List<UUID> uuidsList = uuids.getUuids();
        Iterator<UUID> iterator = uuidsList.iterator();
        BatchResponse response = new BatchResponse("Article");
        while (iterator.hasNext()) {
            UUID uuid = iterator.next();
            if (articleService.isPublish(uuid) && articleService.featureCount() < 3) {
                articleService.featureToggle(uuid, true);
                response.push(uuid, "success");
            } else {
                String responseText = "{"
                        + "\"message\": \"Max 3 feature is available and Article must be Publish.\""
                        + "}";
                return new ResponseEntity<>(responseText, HttpStatus.BAD_REQUEST);
            }
        }

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PutMapping(value = "/unfeatured")
    public ResponseEntity<?> unfeatured(@RequestBody UuidRequest uuids) {
        List<UUID> uuidsList = uuids.getUuids();
        Iterator<UUID> iterator = uuidsList.iterator();
        while (iterator.hasNext()) {
            articleService.featureToggle(iterator.next(), false);
        }
        ApiResponse response = new ApiResponse("success", "Articles has been marked as featured");
        return new ResponseEntity<ApiResponse>(response, HttpStatus.OK);
    }

    @GetMapping("/featured-articles")
    public ResponseEntity<?> getFeaturedArticles() throws DataNotFoundException {

        List<Article> featuredlist = articleService.findFeaturedArticles();
        if (featuredlist.isEmpty()) {
            throw new DataNotFoundException("Featured articles was not found.");
        }

        List<HashMap<?, ?>> map = new ArrayList<HashMap<?, ?>>();

        for (int i = 0; i < featuredlist.size(); i++) {
            HashMap<String, Object> articlemap = new HashMap<>();
            articlemap.put("title", featuredlist.get(i).getTitle());
            articlemap.put("subtitle", featuredlist.get(i).getSummaryText());
            articlemap.put("preview", HtmlToString.convert(featuredlist.get(i).getFullText()));
            articlemap.put("url", findArticleUrl(featuredlist.get(i)));
            articlemap.put("image", featuredlist.get(i).getImgLink());
            map.add(articlemap);
        }
        return new ResponseEntity<>(map, HttpStatus.OK);
    }

    static String findArticleUrl(Article a) {
        String articlelink = "/news/";

        articlelink = articlelink + a.getCategory().getSefURL().getSefUrl() + "/";
        articlelink = articlelink + a.getSefURL().getSefUrl();
        return articlelink;
    }

    /* To be called after full article migration */

    @GetMapping(value = "/removelinks")
    public void removeOldJoomlaLinks() {
        articleLinkService.scanAllArticles();
    }
}
