package com.qualitytaskforce.insightportal.service.users;

import java.util.List;

import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.repository.users.ApiKeyRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ApiKeyService {

	@Autowired
	ApiKeyRepository repo;

	public ApiKey save(ApiKey apiKey) {
		return repo.save(apiKey);
	}

	public List<ApiKey> findByUser(User user) {
		return repo.findByUser(user);
	}

	public ApiKey findFirstByUser(User user) {
		return repo.findFirstByUser(user);
	}
	@Transactional
	public void delete(ApiKey apiKey) {
		repo.delete(apiKey);
	}
}