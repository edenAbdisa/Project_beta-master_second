package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.ChartData;

public interface ChartRepository extends JpaRepository<ChartData, Long> {

    @Query(value = "SELECT uuid_v4() AS uuid, ta_oss.name, "
                + "SUM(marketpenetration) AS marketpen "
                + "FROM ta_ms_mobile_devices "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "INNER JOIN ta_oss ON ta_oss.uuid = osuuid "
                + "WHERE ta_countries.code = :code "
                + "AND date = :date "
                + "GROUP BY ta_oss.name "
                + "ORDER BY marketpen DESC "
                , nativeQuery = true)
    List<ChartData> osBarChartCountry(@Param("code") String code, @Param("date") String date);

    @Query(value = "SELECT uuid_v4() AS uuid, ta_oss.name, "
                + "(SUM(IFNULL(ta_ms_mobile_devices.marketpenetration * ta_countries.desktop_users  / :total, 0))) AS marketpen "
                + "FROM ta_ms_mobile_devices "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "INNER JOIN ta_oss ON ta_oss.uuid = osuuid "
                + "WHERE ta_countries.uuid IN :countries "
                + "AND date = :date "
                + "GROUP BY ta_oss.name "
                + "ORDER BY marketpen DESC "
                , nativeQuery = true)
    List<ChartData> osBarChartGlobal(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("total") long total);

    @Query(value = "SELECT uuid_v4() AS uuid, ta_browsers.name AS name, SUM(marketpenetration) AS marketpen "
                + "FROM ta_ms_browsers "
                + "INNER JOIN ta_browsers ON ta_browsers.uuid = browseruuid "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "WHERE ta_countries.code = :code "
                + "AND date = :date "
                + "GROUP BY ta_browsers.name "
                + "ORDER BY marketpen DESC "
                , nativeQuery = true)
    List<ChartData> desktopBrowserChartCountry(@Param("code") String code, @Param("date") String date);
    
    @Query(value = "SELECT uuid_v4() AS uuid, ta_browsers.name AS name, "
                + "(SUM(IFNULL(marketpenetration * ta_countries.desktop_users / :total, 0))) AS marketpen "
                + "FROM ta_ms_browsers "
                + "INNER JOIN ta_browsers ON ta_browsers.uuid = browseruuid "
                + "INNER JOIN ta_countries ON ta_countries.uuid = countryuuid "
                + "WHERE ta_countries.uuid IN :countries "
                + "AND date = :date "
                + "GROUP BY ta_browsers.name "
                + "ORDER BY marketpen DESC "
                , nativeQuery = true)
    List<ChartData> desktopBrowserChartGlobal(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("total") long total);
}