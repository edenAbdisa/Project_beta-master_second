package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OperatingSystem {
	
	@Id
	private UUID uuid;

	@Column(name = "os_version")
	private String osVersion;

	@Column(name = "date")
	private String date;

	@Column(name = "marketpen")
	private float marketPen;

	public OperatingSystem () {
	}

	public OperatingSystem(UUID uuid, String osVersion, String date, float marketPen) {
		this.uuid = uuid;
		this.osVersion = osVersion;
		this.date = date;
		this.marketPen = marketPen;
	}

	public String getOsVersion() {
		return this.osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getDate() {
		return this.date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public float getMarketPen() {
		return this.marketPen;
	}

	public void setMarketPen(float marketPen) {
		this.marketPen = marketPen;
	}
}