package com.qualitytaskforce.insightportal.model.articleModifications.list;

public class ArticleWhenList {		
	
	String lastUpdate;
	int readTime;
	String title;
	String summaryText;
	String sefURL;
	String category;
	String imgLink;
	boolean published;
	

	public String getLastUpdate() {
		return lastUpdate;
	}

	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}

	public int getReadTime() {
		return readTime;
	}

	public void setReadTime(int readTime) {
		this.readTime = readTime;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummaryText() {
		return summaryText;
	}

	public void setSummaryText(String summaryText) {
		this.summaryText = summaryText;
	}
	
	public String getSefURL() {
		return sefURL;
	}

	public void setSefURL(String sefURL) {
		this.sefURL = sefURL;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
	public void setImgLink(String imgLink) {
		this.imgLink = imgLink;
	}

	public String getImgLink() {
		return imgLink;
	}
	
	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}	
	
}