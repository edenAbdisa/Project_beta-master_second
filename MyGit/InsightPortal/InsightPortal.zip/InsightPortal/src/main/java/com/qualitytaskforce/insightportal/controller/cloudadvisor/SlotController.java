package com.qualitytaskforce.insightportal.controller.cloudadvisor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.SaveEntityException;
import com.qualitytaskforce.insightportal.error.UnauthorizedException;
import com.qualitytaskforce.insightportal.model.BrowserRichCard;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.DetailedSlot;
import com.qualitytaskforce.insightportal.model.cloudadvisor.JsonSlot;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Slot;
import com.qualitytaskforce.insightportal.model.cloudadvisor.TestAdvisorOperatingSystem;
import com.qualitytaskforce.insightportal.model.response.ValidationErrorDTO;
import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid;
import com.qualitytaskforce.insightportal.service.BrowserRichCardService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.CloudAdvisorService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.SlotService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.TaskService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.TestAdvisorOperatingSystemService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.Utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
// TODO: Auto-generated Javadoc

/**
 * The Class SlotController.
 */
@RestController
@RequestMapping(value = "/cloudadvisor/slots")
public class SlotController {

	/** The slot service. */
	@Autowired
	private SlotService slotService;

	/** The cloud advisor service. */
	@Autowired
	private CloudAdvisorService cloudAdvisorService;

	/** The test advisor operating system service. */
	@Autowired
	private TestAdvisorOperatingSystemService testAdvisorOperatingSystemService;

	/** The browser rich card service. */
	@Autowired
	private BrowserRichCardService browserRichCardService;
	
	@Autowired
	private TaskService taskService;
	
	@Autowired
	private Utilities utilities;

	/** The Constant LOGGER. */
	private static final Logger LOGGER = LoggerFactory.getLogger(SlotController.class);

	/**
	 * Adds the slot.
	 *
	 * @param payload the payload
	 * @param errors  the errors
	 * @return the response entity
	 * @throws DataNotFoundException     the data not found exception
	 * @throws InvalidParameterException the invalid parameter exception
	 * @throws UnauthorizedException
	 * @throws SaveEntityException
	 */
	@PostMapping(value = "/add", consumes = "application/json")
	public ResponseEntity<?> addSlot(@Valid @RequestBody JsonSlot payload, Errors errors, HttpServletRequest request)
			throws DataNotFoundException, InvalidParameterException, UnauthorizedException, SaveEntityException {
		BrowserRichCard browser = null;
		TestAdvisorOperatingSystem taOS = null;
		ValidationErrorDTO error=new ValidationErrorDTO();
		if (errors.hasErrors()) {
			List<FieldError> errList = errors.getFieldErrors();
			for(FieldError err:errList) {
				error.addFieldError(err.getField(), err.getDefaultMessage());
			}
			return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
		}
		boolean anyBrowserExist = true;
		CloudAdvisor cloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));
		DeviceWithUuid device = slotService.getDevice(payload.getDeviceBrand(), payload.getDeviceModel());
		List<String> nameVersion = getOSNameAndVersion(payload.getDeviceOs());
		taOS = testAdvisorOperatingSystemService.getSingleOS(nameVersion.get(0), nameVersion.get(1));
		List<List<String>> payLoadBrowsers = payload.getBrowser();
		isSlotValid(payload.getSlotId(), cloudAdvisor.getMaxSlots());
		checkForErrorInData(device, "No device exists by the Provided Brand.");
		checkForErrorInData(taOS, "No OperatingSystem exists by the provided operating system name.");
		List<String> listOfBrowsers = browserRichCardService.getBrowserName();
		for (List<String> brow : payLoadBrowsers) {
			if (!listOfBrowsers.contains(brow.get(0))) {
				error.addFieldError("Browser : "+brow.get(0)+" "+brow.get(1), "This browser doesnt exist.");
				anyBrowserExist = false;
			}
		}
		if (!anyBrowserExist) {
			return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
		}
		Slot slot = new Slot();
		slot.setSlotId(payload.getSlotId());
		slot.setDeviceUuid(device);
		slot.setTaOperatingSystem(taOS);
		slot.setCloudAdvisor(cloudAdvisor);
		for (List<String> brow : payLoadBrowsers) {
			if (listOfBrowsers.contains(brow.get(0))) {
				browser = browserRichCardService.getBrowserByNameAndVersion(brow.get(0), brow.get(1));
				if (browser != null) {
					slot.getBrowserRichCard().add(browser);
				}
			}
		}
		Slot saved = slotService.save(slot);
		if (saved == null) {
			throw new SaveEntityException("Couldnt Save the slot.");
		}
		return new ResponseEntity<>(saved, HttpStatus.CREATED);
	}

	/**
	 * Edits the slot.
	 *
	 * @param slotUuid the slot uuid
	 * @param payload  the payload
	 * @return the response entity
	 * @throws DataNotFoundException     the data not found exception
	 * @throws InvalidParameterException the invalid parameter exception
	 * @throws UnauthorizedException
	 * @throws SaveEntityException
	 */
	@PostMapping(value = "/edit/{uuid}")
	public ResponseEntity<?> editSlot(@PathVariable("uuid") UUID slotUuid, @RequestBody JsonSlot payload,
			HttpServletRequest request)
			throws DataNotFoundException, InvalidParameterException, UnauthorizedException, SaveEntityException {		
		TestAdvisorOperatingSystem taOS = null;
		Slot slotFormer = slotService.findSlotsByUuid(slotUuid);
		checkForErrorInData(slotFormer, "No Slot exists by the provided UUID.");
		CloudAdvisor cloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));
		slotFormer.setCloudAdvisor(cloudAdvisor);
		if ((payload.getSlotId() != 0) && (payload.getSlotId() != slotFormer.getSlotId())) {
			isSlotValid(payload.getSlotId(), cloudAdvisor.getMaxSlots());
			slotFormer.setSlotId(payload.getSlotId());
		}
		if (payload.getDeviceBrand() != null && payload.getDeviceModel() != null) {
			DeviceWithUuid device = slotService.getDevice(payload.getDeviceBrand(), payload.getDeviceModel());
			checkForErrorInData(device, "No Device  system exist by the device and model provided.");
			slotFormer.setDeviceUuid(device);
		}
		if (payload.getDeviceOs() != null) {
			List<String> nameVersion = getOSNameAndVersion(payload.getDeviceOs());
			taOS = testAdvisorOperatingSystemService.getSingleOS(nameVersion.get(0), nameVersion.get(1));
			checkForErrorInData(taOS, "No Operating system exist by the Operating system provided.");
			slotFormer.setTaOperatingSystem(taOS);
		}
		if (payload.getBrowser() != null) {
			List<BrowserRichCard> list = addBrowsers(payload, slotFormer);
			slotFormer.setBrowserRichCard(list);
		}
		Slot saved = slotService.save(slotFormer);
		if (saved == null) {
			throw new SaveEntityException("Couldnt Save the edited slot.");
		}
		return new ResponseEntity<>(saved, HttpStatus.CREATED);
	}

	public List<BrowserRichCard> addBrowsers(JsonSlot payload, Slot slotFormer) throws DataNotFoundException {
		ValidationErrorDTO error=new ValidationErrorDTO();
		BrowserRichCard browser = null;
		boolean anyBrowserExist = true;
		List<List<String>> payloadBrowsers = payload.getBrowser();
		List<String> listOfBrowsers = browserRichCardService.getBrowserName();
		List<BrowserRichCard> formerBrowsers = slotFormer.getBrowserRichCard();
		List<BrowserRichCard> list = new ArrayList<>();
		if (payloadBrowsers.size() == 0) {
			throw new DataNotFoundException("Couldnt find browser by the browser list given.");
		}
		for (List<String> brow : payloadBrowsers) {
			if (!listOfBrowsers.contains(brow.get(0))) {
				error.addFieldError("Browser : "+brow.get(0)+" "+brow.get(1), "This browser doesnt exist.");
				anyBrowserExist = false;
				continue;
			}
			browser = browserRichCardService.getBrowserByNameAndVersion(brow.get(0), brow.get(1));
			checkForErrorInData(browser,
					"We couldnt find browser by the Name:" + brow.get(0) + " Version:" + brow.get(1) + ".");
			if (formerBrowsers.contains(browser)) {
				throw new DataNotFoundException("Name: " + browser.getName() + " Version: " + browser.getVersion()
						+ " this browser already exist.");
			}
			list.add(browser);
		}
		if (!anyBrowserExist) {
			throw new DataNotFoundException(
					"From the list Browser given their are certain browser that arent present.");
		}
		return list;
	}

	/**
	 * Gets the OS name and version.
	 *
	 * @param deviceOs the device os
	 * @return the OS name and version
	 * @throws DataNotFoundException the data not found exception
	 */
	public List<String> getOSNameAndVersion(String deviceOs) throws DataNotFoundException {
		List<String> nameVersion = new ArrayList<>();
		List<String> operatingSystem = testAdvisorOperatingSystemService.getOperatingSystemsName();
		for (String osName : operatingSystem) {
			if (deviceOs.toLowerCase().contains(osName.toLowerCase())) {
				nameVersion.add(deviceOs.substring(0, osName.length()));
				nameVersion.add(deviceOs.substring(osName.length()));
				break;
			}
		}
		if (nameVersion.size() == 0) {
			throw new DataNotFoundException("There is no operating system by this operating system and version");
		}
		return nameVersion;
	}

	/**
	 * Checks if is slot valid.
	 *
	 * @param slotID  the slot ID
	 * @param maxSlot the max slot
	 * @throws InvalidParameterException the invalid parameter exception
	 */
	public void isSlotValid(int slotID, int maxSlot) throws InvalidParameterException {
		if (slotID < 0 || slotID > maxSlot) {
			throw new InvalidParameterException("The slot id provided is invalid.");
		}
	}

	public void checkForErrorInData(Object objectToBeChecked, String errorMessage) throws DataNotFoundException {
		if (objectToBeChecked == null) {
			throw new DataNotFoundException(errorMessage);
		}
	}

	/**
	 * Adds the slot browser.
	 *
	 * @param slotUuid the slot uuid
	 * @param payload  the payload
	 * @return the response entity
	 * @throws DataNotFoundException     the data not found exception
	 * @throws InvalidParameterException the invalid parameter exception
	 */
	@PostMapping(value = "/addBrowser/{uuid}")
	public ResponseEntity<?> addSlotBrowser(@PathVariable("uuid") UUID slotUuid, @RequestBody JsonSlot payload,
			HttpServletRequest request) throws DataNotFoundException, InvalidParameterException {
		Slot slotFormer = slotService.findSlotsByUuid(slotUuid);
		List<BrowserRichCard> list = addBrowsers(payload, slotFormer);
		slotFormer.setBrowserRichCard(list);
		Slot saved = slotService.save(slotFormer);
		checkForErrorInData(saved, "Couldnt Save the edited slot.");
		return new ResponseEntity<>(saved, HttpStatus.CREATED);
	}

	/**
	 * Delete slot browser.
	 *
	 * @param slotUuid the slot uuid
	 * @param payload  the payload
	 * @return the response entity
	 * @throws DataNotFoundException     the data not found exception
	 * @throws InvalidParameterException the invalid parameter exception
	 */
	@DeleteMapping(path = "/deleteBrowser/{uuid}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public ResponseEntity<?> deleteSlotBrowser(@PathVariable("uuid") UUID slotUuid, @RequestBody JsonSlot payload,
			HttpServletRequest request) throws DataNotFoundException, InvalidParameterException {
		Slot slotFormer = slotService.findSlotsByUuid(slotUuid);
		BrowserRichCard browser;
		boolean anyBrowserExist = true;
		List<List<String>> payloadBrowsers = payload.getBrowser();
		List<String> listOfBrowesrs = browserRichCardService.getBrowserName();
		List<BrowserRichCard> formerBrowsers = slotFormer.getBrowserRichCard();
		if (payloadBrowsers.size() == 0 || payloadBrowsers == null) {
			return new ResponseEntity<>(null, HttpStatus.NO_CONTENT);
		}
		for (List<String> brow : payloadBrowsers) {
			if (!listOfBrowesrs.contains(brow.get(0))) {
				anyBrowserExist = false;
				continue;
			}
			browser = browserRichCardService.getBrowserByNameAndVersion(brow.get(0), brow.get(1));
			if (!formerBrowsers.contains(browser)) {
				throw new DataNotFoundException("The browser that you want to delete isnt in the database.");
			}
			if (browser != null) {
				formerBrowsers.remove(browser);
			}
		}
		if (!anyBrowserExist) {
			throw new DataNotFoundException(
					"From the list Browser given their are certain browser that arent present.");
		}
		slotFormer.setBrowserRichCard(formerBrowsers);
		Slot saved = slotService.save(slotFormer);
		checkForErrorInData(saved, "Couldnt save the slot after deleting the browser.");
		return new ResponseEntity<>(saved, HttpStatus.CREATED);
	}

	/**
	 * Fetch slots. Fetches slots of a specific company
	 * 
	 * @param companyName the company name
	 * @return the response entity == Slot
	 * @throws DataNotFoundException the data not found exception
	 * @throws UnauthorizedException
	 */
	@GetMapping(value = "/fetchSlots")
	public ResponseEntity<List<Slot>> fetchSlots(HttpServletRequest request)
			throws DataNotFoundException, UnauthorizedException {
		String companyName = utilities.getUserCompanyName(request);
		List<Slot> slots = new ArrayList<>();
		CloudAdvisor cloudAdvisors = cloudAdvisorService.findByCompanyName(companyName);
		checkForErrorInData(cloudAdvisors, "Company doesnt exist by the current account.");
		slots = slotService.findCloudAdvisor(cloudAdvisors);
		if (slots.isEmpty()) {
			throw new DataNotFoundException("Slots not found for this company");
		}
		return new ResponseEntity<List<Slot>>(slots, HttpStatus.OK);
	}
	@GetMapping(value = "/getDetailedSlots")
	public ResponseEntity<List<Slot>> getDetailedSlots(HttpServletRequest request) throws UnauthorizedException, DataNotFoundException
			 {
		List<Slot> slots=null;
		String companyName = utilities.getUserCompanyName(request);
		CloudAdvisor cloudAdvisors = cloudAdvisorService.findByCompanyName(companyName);
		List<DetailedSlot> listSlot=new ArrayList<DetailedSlot>();
		checkForErrorInData(cloudAdvisors, "Company doesnt exist by the current account.");
		slots = slotService.findCloudAdvisor(cloudAdvisors);
		checkForErrorInData(slots, "Slots not found for this company");
		DetailedSlot dSlot=new DetailedSlot();
		for (Slot slo:slots) {	
			dSlot.setImageLink(slo.getDeviceUuid().getImageLink());
			dSlot.setListTask(taskService.findBySlot(slo));
			dSlot.setSlot(slo);
			listSlot.add(dSlot);
		}
		return new ResponseEntity(listSlot, HttpStatus.OK);

	}
	@GetMapping(value = "/getdetailedslot/{uuid}")
	public ResponseEntity<List<Slot>> getDetailedSlot(@PathVariable("uuid") UUID uuid,HttpServletRequest request) throws UnauthorizedException, DataNotFoundException
			 {
		String companyName = utilities.getUserCompanyName(request);
		CloudAdvisor cloudAdvisors = cloudAdvisorService.findByCompanyName(companyName);
		checkForErrorInData(cloudAdvisors, "Company doesnt exist by the current account.");
		Slot slot = slotService.findByUuidAndCloudAdvisor(uuid, cloudAdvisors.getUuid());
		checkForErrorInData(slot, "Slots not found for this company");
		DetailedSlot dSlot=new DetailedSlot();
		dSlot.setImageLink(slot.getDeviceUuid().getImageLink());
		dSlot.setListTask(taskService.findBySlot(slot));
		dSlot.setSlot(slot);
		return new ResponseEntity(dSlot, HttpStatus.OK);
	}
}
