package com.qualitytaskforce.insightportal.model.put;

import java.sql.Date;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonReleaseAdvisorPut {
	   
	@JsonProperty("uuid")
    private UUID uuid;
	
	@NotNull(message = "This field is required.")
	@Size(min = 5, max = 50, message = "The release advisor title must be between {min} and {max} characters long")
 	@JsonProperty("title")
 	private String title;
    
	@NotNull(message = "This field is required.")
	@NotEmpty()
    @JsonProperty("subtitle")
 	private String subtitle;
     
	@NotNull(message = "This field is required.")
	@NotEmpty()
    @JsonProperty("category")
    private String category;
     
	@NotNull(message = "This field is required.")
    @JsonProperty("start_date")
 	private Date startDate;
     
	@NotNull(message = "This field is required.")
    @JsonProperty("end_date")
 	private Date endDate;
     
	@NotNull(message = "This field is required.")
    @JsonProperty("published")
    private boolean published;

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}
}