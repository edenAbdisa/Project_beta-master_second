package com.qualitytaskforce.insightportal.model;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import org.hibernate.annotations.GenericGenerator;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "sef_urls", uniqueConstraints = @UniqueConstraint(columnNames = "sef_url"))
public class SefURL implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "sef_url", unique = true, nullable = false, length = 50)
	private String sefUrl;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sefURL")
	private Set<Article> articles = new HashSet<>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "sefURL")
	private Set<Category> categories = new HashSet<>(0);

	public SefURL() {
	}

	public SefURL(UUID uuid, String sefUrl) {
		this.uuid = uuid;
		this.sefUrl = sefUrl;
	}

	public SefURL(UUID uuid, String sefUrl, Set<Article> articles, Set<Category> categories) {
		this.uuid = uuid;
		this.sefUrl = sefUrl;
		this.articles = articles;
		this.categories = categories;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getSefUrl() {
		return this.sefUrl;
	}

	public void setSefUrl(String sefUrl) {
		this.sefUrl = sefUrl;
	}

	public Set<Article> getArticles() {
		return this.articles;
	}

	public void setArticles(Set<Article> articles) {
		this.articles = articles;
	}

	public Set<Category> getCategories() {
		return this.categories;
	}

	public void setCategories(Set<Category> categories) {
		this.categories = categories;
	}
}
