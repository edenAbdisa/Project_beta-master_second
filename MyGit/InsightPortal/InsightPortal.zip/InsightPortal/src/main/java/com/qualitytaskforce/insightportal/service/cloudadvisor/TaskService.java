package com.qualitytaskforce.insightportal.service.cloudadvisor;


import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Slot;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Task;
import com.qualitytaskforce.insightportal.model.cloudadvisor.TaskWithOutSlotList;
import com.qualitytaskforce.insightportal.repository.cloudadvisor.TaskRepository;
import com.qualitytaskforce.insightportal.repository.cloudadvisor.TaskWithOutSlotListRepository;

@Service
public class TaskService {
	
	@Autowired
	private TaskRepository taskRepository;
	
	@Autowired
	private TaskWithOutSlotListRepository taskWithOutSlotListRepository;
	
	/**
	 * Method to find list of tasks in a given cloud advisor
	 * @param cloudAdvisor
	 * @return list of task objects
	 * @throws DataNotFoundException if there is no task in the given cloud advisor
	 */
	public List<Task> findByCompany(CloudAdvisor cloudAdvisor) throws DataNotFoundException{
		List<Task> tasksByCompany=taskRepository.findByCloudAdvisor(cloudAdvisor);
		if(tasksByCompany.isEmpty()) {
			throw new DataNotFoundException("No task exists with the provided company name."); 
		}
		return tasksByCompany;
	}
	
	/**
	 * Method to find a task by UUID
	 * @param uuid
	 * @return
	 * @throws DataNotFoundException if there is no task with the given UUID
	 */
	public Task findOne(String uuid) throws DataNotFoundException{
		Task existingTask = taskRepository.findOne(UUID.fromString(uuid));
		if(existingTask == null) {
    		throw new DataNotFoundException("No such task exists."); 
    	}
		return existingTask;
	}
	public  List<TaskWithOutSlotList> findBySlot(Slot slot) {
		return this.taskWithOutSlotListRepository.findBySlot(slot.getUuid());
	}
}
