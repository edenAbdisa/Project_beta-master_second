package com.qualitytaskforce.insightportal.model.response;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.springframework.http.HttpStatus;

/**
 * SimpleResponse Class
 */
@JsonPropertyOrder({"timestamp", "status", "message"})
public class SimpleResponse {
    
    private Long timestamp;
    private int status;
    private String message;
    
    @JsonIgnore
    private HttpStatus httpStatus;
    
    /**
     * Constructor for SimpleResponse
     */
    public SimpleResponse(HttpStatus status, String message) {
        this.timestamp = System.currentTimeMillis();
        this.status = status.value();
        this.message = message;
        this.httpStatus = status;
    }
    
    /**
     * @return the timestamp
     */
    public Long getTimestamp() {
      return timestamp;
    }
    
    /**
     * @return the status
     */
    public int getStatus() {
      return status;
    }
    
    /**
     * @return the message
     */
    public String getMessage() {
      return message;
    }
    
    /**
     * @return the httpStatus
     */
    public HttpStatus getHttpStatus() {
      return httpStatus;
    }
}
