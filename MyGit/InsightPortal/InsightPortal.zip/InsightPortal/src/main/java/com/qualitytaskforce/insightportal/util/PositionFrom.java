package com.qualitytaskforce.insightportal.util;

public class PositionFrom {
	public static int getPositionFrom(int part, int quantity){
		
		/*
		 * Example : 
		 * 	part =     		2 
		 * 	quantity = 		5
		 *  to =      2*5 = 10
		 *  from =    10-5= 5
		 *   
		 */	
		
		return (Integer.valueOf(part) * quantity) - quantity;
	}
}
