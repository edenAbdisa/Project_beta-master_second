package com.qualitytaskforce.insightportal.controller.users;

import java.security.Key;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.crypto.MacProvider;

public class LoginController {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@GetMapping("/signin")
	public ResponseEntity<String> login(@RequestBody String credential) {

		/**
		 * Link of use: https://github.com/jwtk/jjwt
		 */

		/*
		 * table: user sessions [userId, token] save tokens, remove tokens
		 *
		 */

		JSONObject obje;
		String a1 = null;
		String a2 = null;
		try {
			obje = new JSONObject(credential);
			a1 = obje.get("email").toString();
			a2 = obje.get("password").toString();

		} catch (JSONException e) {
			LOGGER.info("Error parsing json credentials: {}", credential, e);
		}

		// --------------------------------------------------------------

		System.out.println(a1);
		System.out.println(a2);

		Key key = MacProvider.generateKey();
		String compactJws = Jwts.builder().setSubject("token").signWith(SignatureAlgorithm.HS512, key).compact();

		JSONObject obj;
		String json = "";
		try {
			obj = new JSONObject("{\"token\":\"" + compactJws + "\"}");
			json = obj.toString();
		} catch (JSONException e) {
			LOGGER.info("Error parsing token:", e);
		}

		return new ResponseEntity<String>(json, HttpStatus.OK);
	}
	
	@GetMapping(value = "/checkSession")
	public ResponseEntity<String> checkSession(@RequestBody String credential) {

		return new ResponseEntity<String>("", HttpStatus.OK);
	}
}
