package com.qualitytaskforce.insightportal.controller.users;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.users.ApiLimit;
import com.qualitytaskforce.insightportal.model.post.JsonApiLimit;
import com.qualitytaskforce.insightportal.model.util.ResponseBuilder;
import com.qualitytaskforce.insightportal.service.users.ApiLimitService;
import com.qualitytaskforce.insightportal.service.MessageUtil;

@RestController
@RequestMapping(value = "/apilimit")
public class ApiLimitController {

	@Autowired
	private ApiLimitService service;

	@Autowired
	private MessageUtil util;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public ResponseEntity<?> apilimit() {
		List<ApiLimit> apiLimits = service.getAll();
		return new ResponseEntity<>(apiLimits,HttpStatus.OK);
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<String> create(@RequestBody JsonApiLimit input) throws Exception {

		//Name of api limit, saved as Upper case String
		String name = input.getName().toUpperCase();

		List<ApiLimit> existing = service.findByName(name);

		//TODO Check name vs RouteTier

		if (!existing.isEmpty()) {
			throw new InvalidParameterFormatException(util.getMessage("error.auth.limit.duplicate"));
		}

		ApiLimit apiLimit = new ApiLimit(UUID.randomUUID(), name, input.getLowHourly(),
										input.getLowMonthly(), input.getMedHourly(), input.getMedMonthly(),
										input.getHighHourly(), input.getHighMonthly());
		service.save(apiLimit);

		return new ResponseBuilder(util.getMessage("success.auth.limit.created"), HttpStatus.CREATED).getResponse();
	}
}