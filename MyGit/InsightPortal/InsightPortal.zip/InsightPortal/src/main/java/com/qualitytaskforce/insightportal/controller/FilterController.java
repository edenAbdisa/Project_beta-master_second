/*package com.qualitytaskforce.insightportal.controller;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.util.PositionFrom;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;
import com.qualitytaskforce.insightportal.util.SefURLToString;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

	
@RestController
@RequestMapping(value = "/filter")
public class FilterController {
	
	@Autowired
	private ArticleService articleService;
	
	@Autowired
	private CategoryService categoryService;
	
	@Autowired
	ArticleRepository articleRepository;
		
		@GetMapping("/get-articles")
		public ResponseEntity<List<ArticleWhenList>> getArticles (@RequestParam(value = "part") String partStr,
																  @RequestParam(value = "category") String category) 
															                      throws DataNotFoundException, UnsupportedEncodingException{
			
			List<Category> categories = new ArrayList<Category>();
			String categorydec = URLDecoder.decode(category, "UTF-8");
			Category categoryObj = new Category();
			
			if (categorydec.equals("All News"))
				categories = categoryService.getAllCategories();
			else {
				categoryObj = categoryService.findByName(categorydec);
				categories.add(categoryObj);
			}

			
			
			int part = Integer.valueOf(partStr);			
			int quantity = 7;					
			int from = PositionFrom.getPositionFrom(part, quantity);
			
			List<Article> articles = articleService.findByLimit(categories, "desc",from,quantity+1);
			if (articles == null)
				return new ResponseEntity<List<ArticleWhenList>>(Collections.<ArticleWhenList>emptyList(), HttpStatus.NO_CONTENT);
			
			List<ArticleWhenList> articlesCutted = PrepareToShowInList.prepare(articles);			
			return new ResponseEntity<List<ArticleWhenList>>(articlesCutted, HttpStatus.OK);
		}
		
		
		@PostMapping("/get-filtered-articles")
		public ResponseEntity<List<ArticleWhenList>> getFilteredArticles(@RequestBody String args){			
			
			String keywords = null, dateStart = null, dateStop = null;			
			JSONArray filterSubcategoriesJson = new JSONArray(); // [desktop-browsers,java]
			List<String> filterSubcategories = new ArrayList<String>(); // // [Desktop Browsers, Java]
			
			try {
				JSONObject json = new JSONObject(args);
				keywords = json.get("keywords").toString();
				dateStart = json.get("dateStart").toString();
				dateStop = json.get("dateStop").toString();
				filterSubcategoriesJson = json.getJSONArray("checkedSubcategories");				
			} catch (JSONException e) {
				e.printStackTrace();
			}			
			
			for(int i=0;i<filterSubcategoriesJson.length();i++) {
				String converted = null;
				try {
					converted = SefURLToString.sefUrlToString(filterSubcategoriesJson.get(i).toString());
				} catch (JSONException e) {
					e.printStackTrace();
				}
				filterSubcategories.add(converted);
			}
		    
		    List<ArticleWhenList> articlesCutted = new ArrayList<ArticleWhenList>();
			List<Article> articles = new ArrayList<Article>();
		    
		    Date dateFrom, dateTo;
		    List<Date> dates = strToDates(dateStart, dateStop);
		    dateFrom = dates.get(0);
		    dateTo = dates.get(1);
			
			if (keywords.equals("none")) articles = articleService.filterByDateSubcategories(dateFrom, dateTo, filterSubcategories);			
			else if (keywords.trim().length() > 0 && keywords.trim().length() < 30){
				int typeSearchField = 4;
				articles = articleRepository.search(keywords, typeSearchField, true, true, false, dateFrom, dateTo, 0, 0);
				List<Article> filteredBySubcategories = new ArrayList<Article>();
				
				for(Article article : articles) {
					for(String subcategory : filterSubcategories) {
						if(article.getSubcategory().equals(subcategory)) {
							filteredBySubcategories.add(article);
							break;
						}
					}
				}
				articles = filteredBySubcategories;
			}
			
			articlesCutted = PrepareToShowInList.prepare(articles);
			System.out.println(articlesCutted.size());
			
			return new ResponseEntity<List<ArticleWhenList>>(articlesCutted, HttpStatus.OK);
		}
		
		private List<Date> strToDates(String dateStart, String dateStop) {
			
			Date dateFrom = null;
			Date dateTo = null;
			
			try {
				int day = Integer.valueOf(dateStop.substring(0,2));
		    	String dateStopMod = String.valueOf(day+1);
		    	if(dateStopMod.length()==1) dateStopMod = "0" + dateStopMod;		    	
				dateStop = dateStopMod + dateStop.substring(2);
		    	dateFrom = new SimpleDateFormat("dd/MM/yyyy").parse(dateStart);
				dateTo = new SimpleDateFormat("dd/MM/yyyy").parse(dateStop);
			 } catch (ParseException e) {			
				e.printStackTrace();
			 }
			 
			 List<Date> dates = new ArrayList<Date>();
			 dates.add(dateFrom);
			 dates.add(dateTo);
			 return dates;			 
		}
}
*/
