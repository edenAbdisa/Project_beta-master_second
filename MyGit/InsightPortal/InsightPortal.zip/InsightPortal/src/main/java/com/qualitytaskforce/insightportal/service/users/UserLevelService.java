package com.qualitytaskforce.insightportal.service.users;

import java.util.List;

import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.repository.users.UserLevelRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserLevelService {

	@Autowired
	UserLevelRepository repo;

	public UserLevel save(UserLevel userLevel) {
		return repo.save(userLevel);
	}

	public List<UserLevel> findByName(String name) {
		return repo.findByName(name);
	}

	public void delete(UserLevel userLevel) {
		repo.delete(userLevel);
	}
	
	public List<UserLevel> findAll(){
		return repo.findAll();
	}
}
