package com.qualitytaskforce.insightportal.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.jsoupcrawler.DetailModel;


public interface DetailModelRepository extends JpaRepository<DetailModel, UUID> {
	
}
