package com.qualitytaskforce.insightportal.repository.users;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.users.UserLevel;

public interface UserLevelRepository extends JpaRepository<UserLevel, Long> {

	List<UserLevel> findByName(String name);
	
	List<UserLevel> findAll();

}