package com.qualitytaskforce.insightportal.model.post;

import java.util.List;
import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.qualitytaskforce.insightportal.annotation.UniqueTitleConstraint;
import com.qualitytaskforce.insightportal.model.put.JsonReleaseAdvisorPut;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.URL;

public class ArticleCombinedRequest {

	@Size(min = 5, max = 90, message = "The title must be between {min} and {max} characters long")
	@UniqueTitleConstraint()
    @NotNull(message = "This field is required.")
    @JsonProperty("title")
    String title;
	
	@NotNull(message = "This field is required.")
    @NotEmpty()
    @JsonProperty("summaryText")
    String summaryText;
	
	@NotNull(message = "This field is required.")
    @JsonProperty("richcardType")
    String richcardType;
    
    @JsonProperty("richcardBrand")
    String richcardBrand;
    
    @JsonProperty("richcardModel")
    String richcardModel;
    
    
    @NotNull(message = "This field is required.")
    @NotEmpty()
    @JsonProperty("fullText")
    String fullText;
    
    @JsonProperty("metaKeywords")
    String metaKeywords; 
    
    @NotNull(message = "This field is required.")
    @JsonProperty("testRecommendation")
    String testRecommendation;
    
    @NotNull(message = "This field is required.")
    @JsonProperty("impactRatingName")
    int impactRatingName;
	
    @NotNull(message = "This field is required.")
    @NotEmpty()
    @JsonProperty("categoryName")
    String categoryName;
    
    @JsonProperty("subcategoryName")
    String subcategoryName;

    @URL()
    @NotNull(message = "This field is required.")
    @NotEmpty(message = "you must select main picture")
    @JsonProperty("artworkUrl")
    String artworkUrl;    
    
    @JsonProperty("relatedArticles")
    List<String> relatedArticles;


	@JsonProperty("releaseAdvisors")
    Set<JsonReleaseAdvisorPut> releaseAdvisors;

	@NotNull(message = "This field is required.")
	@JsonProperty("published")
	boolean published;    
	
	
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummaryText() {
		return summaryText;
	}

	public void setSummaryText(String summaryText) {
		this.summaryText = summaryText;
	}

	public String getRichcardType() {
        return richcardType;
    }

    public void setRichcardType(String richcardType) {
        this.richcardType = richcardType;
    }
    
    public String getRichcardBrand() {
		return richcardBrand;
	}

	public void setRichcardBrand(String richcardBrand) {
		this.richcardBrand = richcardBrand;
	}

	public String getRichcardModel() {
		return richcardModel;
	}

	public void setRichcardModel(String richcardModel) {
		this.richcardModel = richcardModel;
	}

    
    public String getFullText() {
		return fullText;
	}

	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	
	 public String getMetaKeywords() {
		return metaKeywords;
	}

	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}
		
	public String getTestRecommendation() {
        return testRecommendation;
    }
	
	public void setTestRecommendation(String testRecommendation) {
		this.testRecommendation = testRecommendation;
	}
		
	public int getImpactRatingName() {
        return impactRatingName;
    }

    public void setImpactRatingName(int impactRatingName) {
        this.impactRatingName = impactRatingName;
    }
    
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getSubcategoryName() {
		return subcategoryName;
	}

	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}    
   
	public String getArtworkUrl() {
        return artworkUrl;
    }

    public void setArtworkUrl(String artworkUrl) {
        this.artworkUrl = artworkUrl;
    }
    
    public List<String> getRelatedArticles() {
		return relatedArticles;
	}

	public void setRelatedArticles(List<String> relatedArticles) {
		this.relatedArticles = relatedArticles;
	}
    
    public Set<JsonReleaseAdvisorPut> getReleaseAdvisors() {
		return releaseAdvisors;
	}

	public void setReleaseAdvisors(Set<JsonReleaseAdvisorPut> releaseAdvisors) {
		this.releaseAdvisors = releaseAdvisors;
	}	

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}
}
