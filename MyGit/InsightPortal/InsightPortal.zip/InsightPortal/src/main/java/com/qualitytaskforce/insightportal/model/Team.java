package com.qualitytaskforce.insightportal.model;

import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "teams", uniqueConstraints = @UniqueConstraint(columnNames = "team_manager"))
public class Team implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "team_manager", unique = true, nullable = false)
	private UUID teamManager;

	public Team() {
	}

	public Team(UUID uuid, UUID teamManager) {
		this.uuid = uuid;
		this.teamManager = teamManager;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public UUID getTeamManager() {
		return this.teamManager;
	}

	public void setTeamManager(UUID teamManager) {
		this.teamManager = teamManager;
	}
}
