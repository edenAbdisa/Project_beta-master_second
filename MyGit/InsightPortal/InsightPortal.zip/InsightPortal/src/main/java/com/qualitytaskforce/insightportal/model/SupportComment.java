package com.qualitytaskforce.insightportal.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.qualitytaskforce.insightportal.model.users.User;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "support_comments")
public class SupportComment implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "ticket_id", nullable = false)
	private SupportTicket supportTicket;
	
	@Column(name = "from_email", nullable = false)
	private String fromEmail;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id")
	private User user;
	
	@Column(name = "comment", nullable = false, length = 65535)
	private String comment;

	public SupportComment() {
	}

	public SupportComment(UUID uuid, SupportTicket supportTicket, String fromEmail, String comment) {
		this.uuid = uuid;
		this.supportTicket = supportTicket;
		this.fromEmail = fromEmail;
		this.comment = comment;
	}

	public SupportComment(UUID uuid, SupportTicket supportTicket, User user, String fromEmail, String comment) {
		this.uuid = uuid;
		this.supportTicket = supportTicket;
		this.user = user;
		this.fromEmail = fromEmail;
		this.comment = comment;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public SupportTicket getSupportTicket() {
		return this.supportTicket;
	}

	public void setSupportTicket(SupportTicket supportTicket) {
		this.supportTicket = supportTicket;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getFromEmail() {
		return this.fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getComment() {
		return this.comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
}
