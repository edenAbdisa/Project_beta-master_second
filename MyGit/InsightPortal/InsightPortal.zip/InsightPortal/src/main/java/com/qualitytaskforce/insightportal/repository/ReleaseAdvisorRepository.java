package com.qualitytaskforce.insightportal.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.util.ReleaseAdvisorFilterCriteria;
import org.springframework.stereotype.Repository;

@Repository
public interface ReleaseAdvisorRepository extends JpaRepository<ReleaseAdvisor, UUID>
{
	void delete(UUID uuid);
	void delete(ReleaseAdvisor releaseAdvisor);

	List<ReleaseAdvisor> findAllByPublishedIsTrue();

	@Query(value = "SELECT * "
			+ "FROM release_advisor " 
			+ "WHERE (:#{[0].getUuid()} IS null OR release_advisor.uuid = :#{[0].getUuid()}) "
			+ "AND (:#{[0].getArticleId()} IS null OR release_advisor.article_id = :#{[0].getArticleId()}) "
			+ "AND (:#{[0].getCategory()} IS null OR release_advisor.category = :#{[0].getCategory()}) "
			+ "AND (:#{[0].getTitle()} IS null OR release_advisor.title = :#{[0].getTitle()}) "
			+ "AND (:#{[0].getSubtitle()} IS null OR release_advisor.subtitle = :#{[0].getSubtitle()}) "
			+ "AND (:#{[0].getPublished()} IS null OR release_advisor.published = :#{[0].getPublished()}) "
			+ "AND (:#{[0].getStartDate()} IS null OR release_advisor.start_date > :#{[0].getStartDate()}) "
			+ "AND (:#{[0].getEndDate()} IS null OR release_advisor.end_date < :#{[0].getEndDate()}) "
			+ "ORDER BY release_advisor.start_date DESC"
			, nativeQuery = true)
	
	List<ReleaseAdvisor> findMatchingCriteria(@Param("criteria") ReleaseAdvisorFilterCriteria criteria);
	
	@Query(value = "SELECT * "
			+ "FROM release_advisor "
			+ "WHERE release_advisor.start_date > DATE(NOW()) AND release_advisor.published = 1 "
			+ "ORDER BY release_advisor.start_date ASC LIMIT :#{[0]}"
			, nativeQuery = true)
	
	List<ReleaseAdvisor> getNextEvents(@Param("number") int n);

    @Query(value = "SELECT category from release_advisor GROUP BY category", nativeQuery = true)
    List<Object> getAllCategories();

	ReleaseAdvisor findByUuid(UUID uuid);
}

