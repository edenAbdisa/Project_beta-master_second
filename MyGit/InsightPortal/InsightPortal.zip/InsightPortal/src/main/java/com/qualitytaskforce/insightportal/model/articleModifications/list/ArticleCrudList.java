package com.qualitytaskforce.insightportal.model.articleModifications.list;

import com.qualitytaskforce.insightportal.model.SefURL;

import java.util.UUID;

public class ArticleCrudList {
    private String createdAt;
    private int readTime;
    private String title;
    private UUID uuid;
    private String author;
    private boolean published;
    private int impactRating;
    private SefURL sefURL;

    private String subcategory;
    private String category;
    private String updatedAt;

    private boolean feature;
    
    

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public int getReadTime() {
        return readTime;
    }

    public void setReadTime(int readTime) {
        this.readTime = readTime;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }


    public String getAuthor() {
        return author;
    }

    public void setAuthor(String name, String surname) {
        this.author = name + " " + surname;
    }

    public void setImpactRating(int impactRating) {
        this.impactRating =  impactRating;
    }

    public int getImpactRating() {
        return impactRating;
    }
    
    public boolean getPublished() {
        return published;
    }

    public void setPublished(boolean published) {
        this.published = published;
    }
    
    public SefURL getSefURL() {
        return this.sefURL;
    }

    public void setSefURL(SefURL sefURL) {
        this.sefURL = sefURL;
    }

    public boolean isFeature() {
        return feature;
    }

    public void setFeature(boolean feature) {
        this.feature = feature;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getSubcategory() {
        return subcategory;
    }

    public void setSubcategory(String subcategory) {
        this.subcategory = subcategory;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}
