package com.qualitytaskforce.insightportal.service;

import java.util.UUID;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.model.TestRecommendation;
import com.qualitytaskforce.insightportal.repository.TestRecommendationRepository;

@Service
public class TestRecommendationService {

	@Autowired
	TestRecommendationRepository repo;
	
	@Transactional
	public TestRecommendation save(TestRecommendation testRecommendation) {
		return repo.save(testRecommendation);
	}	

	public void delete(TestRecommendation testRecommendation) {
		repo.delete(testRecommendation);
	}
	
	public TestRecommendation findByUuid(UUID uuid) {
		return repo.findByUuid(uuid);
	}
}
