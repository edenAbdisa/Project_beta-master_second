package com.qualitytaskforce.insightportal.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.Subcategory;

public interface SubcategoryRepository extends JpaRepository<Subcategory, Long> {
	
	List<Subcategory> findByName (String subcategoryName);
	List<Subcategory> findAllByCategories (Category category);
}