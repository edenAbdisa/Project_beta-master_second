package com.qualitytaskforce.insightportal.controller.testadvisor;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.testadvisor.ChartData;
import com.qualitytaskforce.insightportal.model.testadvisor.Country;
import com.qualitytaskforce.insightportal.model.testadvisor.Device;
import com.qualitytaskforce.insightportal.model.testadvisor.RankingDevice;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import com.qualitytaskforce.insightportal.service.TestAdvisorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/testadvisor")
public class TaDashboardStats {

	@Autowired
	private TestAdvisorService service;

	private HttpHeaders headers = new HttpHeaders();

	@Autowired
	private MessageUtil util;

	@RequestMapping(value = "/deviceranking/{brand}/{model}", method = RequestMethod.GET)
	public ResponseEntity<?> deviceRanking(@PathVariable String brand, @PathVariable String model, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<Country> countries = new ArrayList<>();
        List<UUID> countryuuids = new ArrayList<>();
        countries = service.getAllCountries();
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		List<Device> list = service.topDevicesGlobalNoLimit(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}
		
		int finalIndex = list.size() - 1;
		int targetIndex = 0;
		List<RankingDevice> finalList = new ArrayList<>();
		boolean found = false;

		for (Device device : list) {
			if (device.getBrand().equals(brand)) {
				if (device.getModel().equals(model)) {
					Device target = device;
					targetIndex = list.indexOf(target);
					found = true;
					break;
				}
			}
		}

		if (!found) {
			throw new DataNotFoundException(util.getMessage("error.ta.device.no-data"));
		} else {
			if (targetIndex < 2) {
				targetIndex = 2;
			} else if (targetIndex > list.size() - 3) {
				targetIndex = list.size() - 3;
			}
			for (int i = targetIndex - 2; i <= targetIndex + 2; i++) {
				Device tmpDevice = list.get(i);
				RankingDevice device = new RankingDevice(i, tmpDevice.getBrand(), tmpDevice.getModel(), tmpDevice.getMarketPen());
				finalList.add(device);
			}
		}

		Map<String, Object> map = new HashMap<>();
		map.put("last-item", finalIndex);
		map.put("devices", finalList);

		return new ResponseEntity<Map<String, Object>>(map, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/devices/{limit}", method = RequestMethod.GET)
	public ResponseEntity<?> topDevicesGlobal(@PathVariable int limit, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        List<Country> countries = new ArrayList<>();
        List<UUID> countryuuids = new ArrayList<>();
        countries = service.getAllCountries();
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		if (limit > 100 || limit < 0) {
			throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.bad-limit"));
		}

		List<Device> list = service.topDevicesGlobal(countryuuids, getDate(), limit, total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<Device>>(list, headers, HttpStatus.OK);
    }

	@RequestMapping(value = "/top/devices/region/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> topDevicesRegion(@PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<Country> countries = new ArrayList<>();
		List<UUID> countryuuids = new ArrayList<>();
		countries = service.getCountriesByRegion(Arrays.asList(code.split(" ")));
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		List<Device> list = service.topDevicesGlobalNoLimit(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<Device>>(list, headers, HttpStatus.OK);
	}

    @RequestMapping(value = "/top/devices/{code}/{limit}", method = RequestMethod.GET)
    public ResponseEntity<?> topDevicesCountry(@PathVariable String code, @PathVariable int limit, HttpServletRequest request) throws Exception {
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        List<Device> list = service.topDevicesCountry(code, getDate(), limit);
        if (list.isEmpty()) {
            throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
        }

        return new ResponseEntity<List<Device>>(list, headers, HttpStatus.OK);
    }

	@RequestMapping(value = "/top/mobileos/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> osBarChartCountry(@PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<ChartData> list = service.osBarChartCountry(code, getDate());
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		} else {
			list = rescaleChartData(list);
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/mobileos/region/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> osBarChartRegion(@PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<Country> countries = new ArrayList<>();
		List<UUID> countryuuids = new ArrayList<>();
		countries = service.getCountriesByRegion(Arrays.asList(code.split(" ")));
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		List<ChartData> list = service.osBarChartGlobal(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		} else {
			list = rescaleChartData(list);
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/top/mobileos/", method = RequestMethod.GET)
	public ResponseEntity<?> osBarChartGlobal(HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<Country> countries = new ArrayList<>();
        List<UUID> countryuuids = new ArrayList<>();
		countries = service.getAllCountries();
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		List<ChartData> list = service.osBarChartGlobal(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		} else {
			list = rescaleChartData(list);
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/desktopbrowsers/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> desktopBrowserChartCountry(@PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<ChartData> list = service.desktopBrowserChartCountry(code, getDate());
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/desktopbrowsers/{code}/{limit}", method = RequestMethod.GET)
	public ResponseEntity<?> desktopBrowserChartCountryLimit(@PathVariable String code, @PathVariable int limit, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		if (limit > 7 || limit < 0) {
			throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.bad-dashboard-limit"));
		}

		List<ChartData> list = service.desktopBrowserChartCountry(code, getDate());
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		if (limit > 0) {
			ChartData otherCategorySummed = new ChartData("Other", 0f);
			for (int i = limit - 1; i < list.size(); i++) {
				otherCategorySummed.setMarketPen(otherCategorySummed.getMarketPen() + list.get(i).getMarketPen());
			}
	
			List<ChartData> newList = list.subList(0, limit - 1);
			newList.add(otherCategorySummed);

			return new ResponseEntity<List<ChartData>>(newList, headers, HttpStatus.OK);
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/desktopbrowsers/region/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> desktopBrowsersChartRegion(@PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<Country> countries = new ArrayList<>();
		List<UUID> countryuuids = new ArrayList<>();
		countries = service.getCountriesByRegion(Arrays.asList(code.split(" ")));
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		List<ChartData> list = service.desktopBrowserChartGlobal(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/desktopbrowsers/global", method = RequestMethod.GET)
	public ResponseEntity<?> desktopBrowserChartGlobal(HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		List<Country> countries = new ArrayList<>();
        List<UUID> countryuuids = new ArrayList<>();
		countries = service.getAllCountries();
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		List<ChartData> list = service.desktopBrowserChartGlobal(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/top/desktopbrowsers/global/{limit}", method = RequestMethod.GET)
	public ResponseEntity<?> desktopBrowserChartGlobalLimit(@PathVariable int limit, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		List<Country> countries = new ArrayList<>();
        List<UUID> countryuuids = new ArrayList<>();
		countries = service.getAllCountries();
		countryuuids = getCountryUuids(countries);
		long total = service.getUserTotal(countryuuids);

		if (limit > 7 || limit < 0) {
			throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.bad-dashboard-limit"));
		}

		List<ChartData> list = service.desktopBrowserChartGlobal(countryuuids, getDate(), total);
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		int indexOfOthers = 0;
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).getName().equals("Others")) {
				indexOfOthers = i;
				break;
			}
		}

		if (limit > 0) {
			ChartData otherCategorySummed = new ChartData("Other", 0f);
			if (indexOfOthers < limit) {
				otherCategorySummed = list.get(indexOfOthers);
				otherCategorySummed.setName("Other");
				list.remove(indexOfOthers);
			}
			for (int i = limit - 1; i < list.size(); i++) {
				otherCategorySummed.setMarketPen(otherCategorySummed.getMarketPen() + list.get(i).getMarketPen());
			}
	
			List<ChartData> newList = list.subList(0, limit - 1);
			newList.add(otherCategorySummed);

			return new ResponseEntity<List<ChartData>>(newList, headers, HttpStatus.OK);
		}

		return new ResponseEntity<List<ChartData>>(list, headers, HttpStatus.OK);
	}

    private String getDate() {
		String date = new SimpleDateFormat("yyyy-MM").format(new Date());
		date = date + "-01";
		return date;
    }
    
    private List<UUID> getCountryUuids(List<Country> countries) {
		List<UUID> countryuuids = new ArrayList<>();
		for (int i = 0; i < countries.size(); i++) {
			countryuuids.add(countries.get(i).getUuid());
		}
		return countryuuids;
	}

	private List<ChartData> rescaleChartData(List<ChartData> chartData) {
		float totalMarketShare = (float) chartData.stream().mapToDouble(ChartData::getMarketPen).sum();
		if (totalMarketShare > 0.0f) {
			chartData.forEach(p -> p.setMarketPen(p.getMarketPen() / totalMarketShare * 100));
		}
		return chartData;
	}
}