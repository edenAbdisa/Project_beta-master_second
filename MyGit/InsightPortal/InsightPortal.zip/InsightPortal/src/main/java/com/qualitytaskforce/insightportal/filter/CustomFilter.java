package com.qualitytaskforce.insightportal.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.qualitytaskforce.insightportal.config.RoutesConfig;
import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.ApiLimit;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.util.Route;
import com.qualitytaskforce.insightportal.model.util.RouteTier;
import com.qualitytaskforce.insightportal.service.users.ApiKeyService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.HiddenHttpMethodFilter;

public class CustomFilter extends HiddenHttpMethodFilter {

	private UserService userService;
	private ApiKeyService apiKeyService;
	private RoutesConfig routeConfig;

	private double newHourly;

	@Override
	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		boolean limitCheck = true;
		boolean monthlyCheck = true;
		String limitMessage = "";

		// Get the users email, if no email then no auth has been provided
		Object emailOrUser = null;
		String email = "";

		// At some point getPrincipal can return either an email or a List containing the User
		// object
		try {
			emailOrUser = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (emailOrUser instanceof ArrayList<?>) {
				email = ((ArrayList<User>) emailOrUser).get(0).getEmail();
			} else {
				email = emailOrUser.toString();
			}
		} catch (NullPointerException e) {
			String responseText = "{\"timestamp\": " + System.currentTimeMillis()
					+ ", \"status\": 401 " + ", \"error\": \"Unauthorized\""
					+ ", \"message\": \"This path requires authentication.\"" + "}";

			response.reset();
			response.setContentType("application/json;charset=UTF-8");
			response.setHeader("Access-Control-Allow-Origin", "*");
			response.setStatus(401);
			response.getWriter().write(responseText);
			response.getWriter().flush();
			response.getWriter().close();
			return;
		}

		manualAutowire(request);

		List<User> user = userService.findByEmail(email);
		List<ApiKey> keyList = apiKeyService.findByUser(user.get(0));
		ApiKey key = keyList.get(0);
		ApiLimit limit = key.getApiLimit();

		String requestURI = request.getRequestURI();
		// String routeTier = routeConfig.routes().getOrDefault(requestURI, new Route(RouteTier.LOW,
		// "FREE")).getRateTier().toString();
		List<Route> routesList = routeConfig.routes().get(requestURI).stream().filter(
				route -> route.getMethod().toString().equals(request.getMethod().toString()))
				.collect(Collectors.toList());

		String routeTier = "";
		if (routesList.isEmpty() || routesList.size() > 1) {
			routeTier = "LOW";
		} else {
			routeTier = routesList.get(0).getRateTier().toString();
		}

		// Rate limit algorithm uses micro-second accurate time.
		Long currentTimeMicro = System.currentTimeMillis() / 1000;
		switch (routeTier) {
			case "LOW":
				// Check monthly limit first
				monthlyCheck = checkMonthly(key.getLowMonthly());
				if (!monthlyCheck) {
					break;
				}
				// Check hourly limit
				limitCheck = checkLimit(key.getLowHourly(), limit.getLowHourly(), key.getLowReset(),
						currentTimeMicro);
				key.setLowReset(currentTimeMicro);
				key.setLowHourly(newHourly);
				key.setLowMonthly(key.getLowMonthly() - 1);
				break;
			case "MEDIUM":
				// Check monthly limit first
				monthlyCheck = checkMonthly(key.getMedMonthly());
				if (!monthlyCheck) {
					break;
				}
				// Check hourly limit
				limitCheck = checkLimit(key.getMedHourly(), limit.getMedHourly(), key.getMedReset(),
						currentTimeMicro);
				key.setMedReset(currentTimeMicro);
				key.setMedHourly(newHourly);
				key.setMedMonthly(key.getMedMonthly() - 1);
				break;
			case "HIGH":
				// Check monthly limit first
				monthlyCheck = checkMonthly(key.getHighMonthly());
				if (!monthlyCheck) {
					break;
				}
				// Check hourly limit
				limitCheck = checkLimit(key.getHighHourly(), limit.getHighHourly(),
						key.getHighReset(), currentTimeMicro);
				key.setHighReset(currentTimeMicro);
				key.setHighHourly(newHourly);
				key.setHighMonthly(key.getHighMonthly() - 1);
				break;
		}

		if (!monthlyCheck) {
			limitMessage = "You have reached your monthly limit for this type of call.";
		}

		if (!limitCheck) {
			limitMessage = "You have attempted too many requests in the last hour.";
		}

		// If either the limitCheck (for hourly) or monthlyCheck fail then too many requests have
		// been made
		if (!limitCheck || !monthlyCheck) {
			String responseText = "{\"timestamp\": " + System.currentTimeMillis()
					+ ", \"status\": 429 " + ", \"error\": \"Too Many Requests\""
					+ ", \"message\": \"" + limitMessage + "\"" + "}";
			response.reset();
			response.setContentType("application/json;charset=UTF-8");
			response.setStatus(429);
			response.getWriter().write(responseText);
			response.getWriter().flush();
			response.getWriter().close();
			return;
		}

		// Otherwise, the request can continue and we save the new key usage
		apiKeyService.save(key);
		chain.doFilter(request, response);
	}

	/**
	 * Method to check if monthly call usage is equal to zero
	 * 
	 * @param monthly monthly call usage
	 */
	private boolean checkMonthly(int monthly) {
		if (monthly == 0) {
			return false;
		}
		return true;
	}

	/**
	 * Method to check the calls per hour the allowance will grow at a rate of hourlyLimit/3600
	 * units per second Algorithm used is called Token-Bucket algorithm
	 * 
	 * @param usage      current usage of the userkey
	 * @param usageLimit the usage limit of the userkey
	 * @param reset      the time in microseconds of the last check
	 * 
	 */
	private boolean checkLimit(double hourly, int hourlyLimit, Long reset, Long currentTimeMicro) {
		int rate = hourlyLimit;
		int per = 3600; // Num of seconds in an hour
		double ratePer = (double) rate / per;
		double allowance = hourly;
		Long lastCheck = reset;

		Long current = currentTimeMicro;
		Long timePassed = current - lastCheck;
		lastCheck = current;
		allowance += (double) timePassed * (ratePer);

		// If no calls are made in more than an hours time then the allowance would continue to grow
		// So we cap it at the rate (hourlyLimit)
		if (allowance > rate) {
			allowance = rate;
		}
		if (allowance < 1) {
			// Too many requests have been made in the hour
			return false;
		} else {
			// Decrement the allowance and continue with the request
			allowance -= 1;
			newHourly = allowance;
			return true;
		}
	}

	// Services inside Filters cannot be autowired, so the following voodoo has to be done instead
	private void manualAutowire(HttpServletRequest request) {
		if (userService == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext =
					WebApplicationContextUtils.getWebApplicationContext(servletContext);
			userService = webApplicationContext.getBean(UserService.class);
		}
		if (apiKeyService == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext =
					WebApplicationContextUtils.getWebApplicationContext(servletContext);
			apiKeyService = webApplicationContext.getBean(ApiKeyService.class);
		}
		if (routeConfig == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext =
					WebApplicationContextUtils.getWebApplicationContext(servletContext);
			routeConfig = webApplicationContext.getBean(RoutesConfig.class);
		}
	}
}
