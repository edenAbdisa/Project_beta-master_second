package com.qualitytaskforce.insightportal.model.put;

import java.util.UUID;

public class JsonArticleUpdate {
	UUID uuid;
	String updateContent;
	String updateCheckBy;
	String updateDate;
	
	
	public UUID getUuid() {
		return uuid;
	}
	
	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
	public String getUpdateContent() {
		return updateContent;
	}
	
	public void setUpdateContent(String updateContent) {
		this.updateContent = updateContent;
	}
	
	public String getUpdateCheckBy() {
		return updateCheckBy;
	}
	
	public void setUpdateCheckBy(String updateCheckBy) {
		this.updateCheckBy = updateCheckBy;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	
}