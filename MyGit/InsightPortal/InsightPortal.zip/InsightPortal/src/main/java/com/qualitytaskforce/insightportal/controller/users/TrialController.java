package com.qualitytaskforce.insightportal.controller.users;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.service.EmailServiceImpl;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TrialController {
	
	private HttpHeaders headers = new HttpHeaders();

	@Autowired
	UserTrialService userTrialService;	
	
	@Autowired
	UserService userService;
	
	@Autowired
 	private EmailServiceImpl emailService;

		
	 @PostMapping("/user/checktrial")
	    public ResponseEntity<?> checkTrial (@RequestBody Map<String, String> payload) throws DataNotFoundException {
	    	
			Map<String,String> map = payload;
	    	String email = map.get("email");
	    	int daysBeforeExpire = userTrialService.checkTrial(email);
	    	
			Map<String, Integer> outputMap = new HashMap<String, Integer>();
			outputMap.put("daysBeforeExpire", daysBeforeExpire);
			
			return new ResponseEntity<Map<String, Integer>> (outputMap, headers, HttpStatus.OK);
	    }
	 
	 
	 @PostMapping("/user/manualsubscribe/requestoffer")
	    public ResponseEntity<?> requestOffer (@RequestBody Map<String, String> payload) throws DataNotFoundException {
	    	
		 	Map<String,String> map = payload;
	    	
	    	String firstName = map.get("firstName");
	    	String lastName = map.get("lastName");
	    	String email = map.get("email");
	    	String phoneNumber = map.get("phoneNumber");
	    	
	    	String emailFrom = "contactus@insightportal.io";
			String emailTo = emailFrom;
			String emailTitle = "OFFER REQUEST";
			String devBody = "First name: " + firstName + "<br>" 
								+ "Last name: " + lastName + "<br>" 
								+ "Email : " + email + "<br>"
								+ "Phone number: " + phoneNumber;
			emailService.sendEmail(emailFrom, emailTo, emailTitle, devBody);
			
			ApiResponse response = new ApiResponse("success", "Your request has been sent successfully.");
			return new ResponseEntity<ApiResponse> (response, headers, HttpStatus.OK);
	    }
	 
	 
	 @PostMapping("/user/manualsubscribe/requestofferdata")
	    public ResponseEntity<?> getRequestOfferData (@RequestBody Map<String, String> payload) throws Exception {
		 
		 String payloadEmail = payload.get("email");
		 Object principal = SecurityContextHolder.getContext().getAuthentication();
		 if (principal == null) {
			 throw new Exception("User not authenticated.");
		 }
		 
		 String contextEmail = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
		 if (!contextEmail.equals(payloadEmail)) {
			 throw new Exception("User context email and payload email not equals.");
		 }
		 		 
		 String email = payloadEmail;
		 List<User> userList = userService.findByEmail(email);
		 if (userList.isEmpty()) {
			 throw new DataNotFoundException("User with selected email not found.");
		 }
		 User user = userList.get(0);
		 
		 Map<String,String> response = new HashMap<String, String>();
		 response.put("firstName", user.getName());
		 response.put("lastName", user.getSurname());
		 response.put("phoneNumber", user.getPhoneNumber());
		 
		 return new ResponseEntity<Map<String,String>> (response, headers, HttpStatus.OK);
	 }
}