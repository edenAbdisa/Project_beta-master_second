package com.qualitytaskforce.insightportal.model.util;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;

public class JSONEnitityUuidKeySerializer extends JsonSerializer<Uuidgetable>
{
	@Override
	public void serialize(Uuidgetable entityObject, JsonGenerator jGen, SerializerProvider arg2)
			throws IOException, JsonProcessingException{
		jGen.writeString(entityObject.getUuid().toString()); 
	}
}