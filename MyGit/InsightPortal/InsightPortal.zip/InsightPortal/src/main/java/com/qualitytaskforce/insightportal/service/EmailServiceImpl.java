package com.qualitytaskforce.insightportal.service;

import com.qualitytaskforce.insightportal.util.EmailSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class EmailServiceImpl implements EmailSender {

    public static final Logger LOGGER = LoggerFactory.getLogger(EmailServiceImpl.class);
    
    @Autowired
    private JavaMailSender javaMailSender;

    @Override
    public void sendEmail(String from, String to, String title, String content) {
        MimeMessage mail = javaMailSender.createMimeMessage();
        try {
            MimeMessageHelper helper = new MimeMessageHelper(mail, true);
            helper.setFrom(new InternetAddress(from));
            helper.setTo(new InternetAddress(to));
            helper.setSubject(title);
            helper.setText(content, true);
        } catch (MessagingException e) {
            LOGGER.info("Error sending email.", e);
        }
        javaMailSender.send(mail);
    }
}
