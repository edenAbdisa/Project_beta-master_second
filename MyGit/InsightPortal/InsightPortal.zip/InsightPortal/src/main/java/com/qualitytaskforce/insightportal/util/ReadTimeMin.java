package com.qualitytaskforce.insightportal.util;

import java.util.List;
import java.util.StringTokenizer;	

public class ReadTimeMin {
		
	StringBuilder stringBuilder;	
	List<Integer> lastIndexes;	
	
	int firstIndex;	
	int lastIndex;	
	int readTime;	
	int countedWords;
	
	static final int words_per_minute = 120;	
	static final int minTextLenght = 300; 
	
	
	public int readTime(String text){
		
		if (text.length() < minTextLenght) {			
			return 1;		
		} else {
			countedWords = countWords(text);				
			readTime = (countedWords) / (words_per_minute);
			
			if (readTime < 1) {			
				return 1;			
			} else {
				return readTime; 
			}
		}			
	}	
	
	
	int countWords(String text){
		
		String preparedText = HtmlToString.convert(text);
		StringTokenizer st = new StringTokenizer(preparedText);
		int count = st.countTokens();		
		
		return count;	
	}
}
