package com.qualitytaskforce.insightportal.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class StringToSefURL {

	public static String stringToSefURL(String title) {

		String result = title;
		int limitLength = 60;
		result = replacePatterns(result);
		result = cutLength(result, limitLength);

		return result;
	}

	static String replacePatterns(String result) {

		result = result.replaceAll("&", "and");
		result = result.replaceAll(" - ", "-");
		result = result.replaceAll("\\(", "");
		result = result.replaceAll("\\)", "");
		result = result.replaceAll("\\.", "-");
		result = result.replaceAll("\\s\\/\\s", "-");
		result = result.replaceAll("\\/", "-");
		result = result.replaceAll("\\s", "-");

		Pattern p = Pattern.compile("[^a-zA-Z\\d-]");
		Matcher m = p.matcher(result);
		result = m.replaceAll("");
		result = result.toLowerCase();

		return result;
	}


	static String cutLength(String result, int limit) {
		if (result.length() > limit) {
			result = result.substring(0, limit);
			int endIndex = result.lastIndexOf("-");
			if (endIndex != -1) {
				result = result.substring(0, endIndex);
			}
		}
		return result;
	}
}
