package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.Browser;

public interface BrowserRepository extends JpaRepository<Browser, Long> {

	@Query(value = "SELECT ta_ms_browsers.uuid, ta_browsers.version AS browser_name, ta_ms_browsers.marketpenetration AS marketpen "
				+ "FROM ta_ms_browsers "
				+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_browsers.browseruuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_browsers.countryuuid "
				+ "WHERE ta_countries.code = :code "
				+ "AND ta_ms_browsers.date = :date " 
				+ "ORDER BY marketpen DESC"
				, nativeQuery = true)
	List<Browser> browsers(@Param("code") String code, @Param("date") String date);

	@Query(value = "SELECT * FROM ( "
				+ "SELECT uuid_v4() AS uuid, (SUM(IFNULL(ta_ms_browsers.marketpenetration * ta_countries.desktop_users, 0)) / SUM(ta_countries.desktop_users)) AS marketpen, "
				+ "ta_browsers.version AS browser_name "
				+ "FROM ta_ms_browsers "
				+ "INNER JOIN ta_browsers ON ta_browsers.uuid = ta_ms_browsers.browseruuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_browsers.countryuuid "
				+ "WHERE ta_ms_browsers.countryuuid IN :countries "
				+ "AND ta_ms_browsers.date = :date "
				+ "GROUP BY ta_ms_browsers.date, browser_name "
				+ "ORDER BY marketpen DESC "
				+ ") t WHERE marketpen > :threshold"
				, nativeQuery = true)
	List<Browser> browsersMultiple(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("threshold") float threshold);

}