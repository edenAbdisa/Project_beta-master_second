package com.qualitytaskforce.insightportal.model.cloudadvisor;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonSlot {
	
	@JsonProperty("slot_id")
	@NotNull(message = "You must pass a Slot ID to add a slot.")
	@Min(value=0,message = "Slot Id cant be bellow zero.")
	private int slotId;
	
	@JsonProperty("device_brand")
	@NotBlank(message = "Device brand cant be blank")
	@NotNull(message = "You must pass a Device brand to add a slot.")
	private String deviceBrand;

	@JsonProperty("device_model")
	 @NotBlank(message = "Device model cant be blank")
	@NotNull(message = "You must pass a Device Model to add a slot.")
	private String deviceModel;

	@JsonProperty("device_os")
	 @NotBlank(message = "Device OS cant be blank")
	@NotNull(message = "You must pass a Device operating system to add a slot")
	private String deviceOs;
	
	@JsonProperty("browser")
	private List<List<String>> browser;

	 
	public int getSlotId() {
		return slotId;
	}
	public void setSlotId(int slotId) {
		this.slotId = slotId;
	}
	public String getDeviceBrand() {
		return deviceBrand;
	}
	public void setDeviceBrand(String deviceBrand) {
		this.deviceBrand = deviceBrand;
	}
	public String getDeviceModel() {
		return deviceModel;
	}
	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}
	public String getDeviceOs() {
		return deviceOs;
	}
	public void setDeviceOs(String deviceOs) {
		this.deviceOs = deviceOs;
	}
	public List<List<String>> getBrowser() {
		return browser;
	}
	public void setBrowser(List<List<String>> browser) {
		this.browser = browser;
	}
	
	@JsonCreator
	public JsonSlot() {
		
	}
	
	@JsonCreator
	public JsonSlot(@JsonProperty("slot_id") int slotId,@JsonProperty("device_brand") String deviceBrand, @JsonProperty("device_model") String deviceModel,@JsonProperty("device_os") String deviceOs,@JsonProperty("browser")
	List<List<String>> browser ) {
		this.slotId = slotId;
		this.deviceBrand = deviceBrand;
		this.deviceModel = deviceModel;
		this.deviceOs = deviceOs;
		this.browser = browser;
	}
	
}
