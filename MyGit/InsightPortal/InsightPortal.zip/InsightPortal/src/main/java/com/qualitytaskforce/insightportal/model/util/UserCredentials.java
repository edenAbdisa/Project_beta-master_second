package com.qualitytaskforce.insightportal.model.util;

import com.qualitytaskforce.insightportal.model.users.User;

/**
 * This class is used to map user email and password along with additional login parameters
 *
 */

public class UserCredentials extends User {

    private boolean keptLoggedIn;

    public boolean isKeptLoggedIn() {
        return keptLoggedIn;
    }
}
