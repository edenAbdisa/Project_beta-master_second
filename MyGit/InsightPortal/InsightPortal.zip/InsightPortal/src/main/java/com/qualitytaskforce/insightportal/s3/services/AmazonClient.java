package com.qualitytaskforce.insightportal.s3.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.qualitytaskforce.insightportal.model.users.UserLogging;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class AmazonClient {

    public static final Logger LOGGER = LoggerFactory.getLogger(AmazonClient.class);
    
    private AmazonS3 s3client;

    @Value("https://s3-eu-west-1.amazonaws.com")
    private String endpointUrl;
    @Value("${amazonProperties.bucketName}")
    private String bucketName;
    @Value("${amazonProperties.accessKey}")
    private String accessKey;
    @Value("${amazonProperties.secretKey}")
    private String secretKey;
    @Value("${amazonProperties.enableUserActionLogs}")
    private boolean enableUserActionLogs;

    // I know the variable name is clumsy, but trust me
    List<String> userLoggingLogs = new ArrayList<>();

    @PostConstruct
    private void initializeAmazon() {

        AWSCredentials credentials = new BasicAWSCredentials(this.accessKey, this.secretKey);
        this.s3client = new AmazonS3Client(credentials);
    }

    private File convertMultiPartToFile(MultipartFile file) throws IOException {
        File convFile = new File(file.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(convFile)) {
            fos.write(file.getBytes());
        }
        return convFile;

    }

    private String generateFileName(MultipartFile multiPart) {
        return multiPart.getOriginalFilename().replace(" ", "_");
    }

    private void uploadFileTos3bucket(String fileName, File file) {
    	String devices = "/images/cards/devices";
        s3client.putObject(new PutObjectRequest(bucketName + devices, fileName, file)
                .withCannedAcl(CannedAccessControlList.PublicRead));
    }

    public String uploadFile(MultipartFile multipartFile) {
        LOGGER.trace("Starting file upload");
        String fileUrl = "";
        try {
            File file = convertMultiPartToFile(multipartFile);
            String fileName = generateFileName(multipartFile);
//            fileUrl = endpointUrl + "/" + bucketName + "/" + fileName;
            fileUrl = fileName;
            uploadFileTos3bucket(fileName, file);
            if (!file.delete()) {
                throw new IOException("File not deleted");
            }
            LOGGER.trace("File upload complete");
        } catch (IOException e) {
            LOGGER.info("Error when uploading file", e);
        }
        return fileUrl;
    }


    private void uploadFileTos3(String fileName, File file, String dir) {
        s3client.putObject(new PutObjectRequest(bucketName + dir, fileName, file)
                .withCannedAcl(CannedAccessControlList.PublicRead));
    }

    public String uploadFileWithPath(MultipartFile multipartFile, String dir) {
        LOGGER.trace("Starting file upload");
        String fileUrl = "";
        try {
            File file = convertMultiPartToFile(multipartFile);
            String fileName = generateFileName(multipartFile);
            fileUrl = endpointUrl + "/" + bucketName+ dir + "/" + fileName;
            uploadFileTos3(fileName, file, dir);
            if (!file.delete()) {
                throw new IOException("File not deleted");
            }
            LOGGER.trace("File upload complete");
        } catch (IOException e) {
            LOGGER.info("Error when uploading file", e);
        }
        return fileUrl;
    }

    public String deleteFileFromS3Bucket(String fileUrl) {
        String fileName = fileUrl.substring(fileUrl.lastIndexOf("/") + 1);
        s3client.deleteObject(new DeleteObjectRequest(bucketName, fileName));
        return "Successfully deleted";
    }
    /*
    * get files from specific folder in bucket
    * @param dir - its path to folder from which we want to download the list of files
    * @return List<S3ObjectSummary> - the information about files in folder
    * */
    public List<?> listFiles(String dir){
        ObjectListing bucketFiles = s3client.listObjects(new ListObjectsRequest()
                .withBucketName(bucketName)
                .withPrefix(dir + '/')
                .withDelimiter("/"));
        List<S3ObjectSummary> summaries = bucketFiles.getObjectSummaries();
        List<FileSummary> fileSummaries = new ArrayList<>();
        for (S3ObjectSummary file : summaries){
                String url = endpointUrl + "/" + bucketName + "/" + file.getKey();
                File f = new File(file.getKey());
                fileSummaries.add(new FileSummary(url, f.getName()));
        }

        return fileSummaries;
    }

    /* Get a single login/logout/change password log and save it as String */
    public void addToLogs(UserLogging log) {
        userLoggingLogs.add(log.toString() + '\n');
    }

    /* Upload a new file with logs every day at 11:59 PM */
    @Scheduled(cron = "0 59 23 * * *")
    public void uploadUserLog() {
        /* Upload only if logging to S3 is enabled */
        if (enableUserActionLogs) {
            String day = LocalDateTime.now().toLocalDate().toString();
            String fileName = day + ".log";

            String userActionDir = bucketName + "/useractions";

            StringBuilder fullDailyLog = new StringBuilder();

            userLoggingLogs.forEach(fullDailyLog::append);

            try {
                s3client.putObject(userActionDir, fileName, fullDailyLog.toString());
            } catch (AmazonServiceException ex) {
                System.out.println("Error saving" + fileName + "log file to S3");
            }

            if (s3client.doesObjectExist(bucketName, fileName)) {
                userLoggingLogs.clear();
            }
        }
    }

    final static class FileSummary{
        String Url;
        String name;

        public FileSummary(String url, String name) {
            Url = url;
            this.name = name;
        }

        public String getUrl() {
            return Url;
        }

        public void setUrl(String url) {
            Url = url;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }

    /**
     * @return the s3client
     */
    public AmazonS3 getS3client() {
        return s3client;
    }

    /**
     * @param s3client the s3client to set
     */
    public void setS3client(AmazonS3 s3client) {
        this.s3client = s3client;
    }

    /**
     * @return the endpointUrl
     */
    public String getEndpointUrl() {
        return endpointUrl;
    }

    /**
     * @param endpointUrl the endpointUrl to set
     */
    public void setEndpointUrl(String endpointUrl) {
        this.endpointUrl = endpointUrl;
    }

    /**
     * @return the bucketName
     */
    public String getBucketName() {
        return bucketName;
    }

    /**
     * @param bucketName the bucketName to set
     */
    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }

    /**
     * @return the accessKey
     */
    public String getAccessKey() {
        return accessKey;
    }

    /**
     * @param accessKey the accessKey to set
     */
    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    /**
     * @return the secretKey
     */
    public String getSecretKey() {
        return secretKey;
    }

    /**
     * @param secretKey the secretKey to set
     */
    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    /**
     * @return the enableUserActionLogs
     */
    public boolean isEnableUserActionLogs() {
        return enableUserActionLogs;
    }

    /**
     * @param enableUserActionLogs the enableUserActionLogs to set
     */
    public void setEnableUserActionLogs(boolean enableUserActionLogs) {
        this.enableUserActionLogs = enableUserActionLogs;
    }

    /**
     * @return the userLoggingLogs
     */
    public List<String> getUserLoggingLogs() {
        return userLoggingLogs;
    }

    /**
     * @param userLoggingLogs the userLoggingLogs to set
     */
    public void setUserLoggingLogs(List<String> userLoggingLogs) {
        this.userLoggingLogs = userLoggingLogs;
    }
}