package com.qualitytaskforce.insightportal.repository.cloudadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.BrowserRichCard;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Slot;
import com.qualitytaskforce.insightportal.model.testadvisor.Country;
import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid;


public interface SlotRepository extends JpaRepository<Slot, UUID>{
	


	List<Slot> findSlotByCloudAdvisor(CloudAdvisor cloudAdvisorUuid);
	
	

	Slot findSlotsByUuid(UUID slotUuid);

	@Query(value = "SELECT * FROM slots "
			+ "WHERE cloud_advisor_uuid =:companyUuid "
			, nativeQuery = true)
	List<Slot> findAllSlots(@Param("companyUuid") UUID companyUuid);
	@Query(value = "SELECT * FROM slots "
			+ "WHERE uuid =:uuid "
			, nativeQuery = true)
	Slot findByUuid(@Param("uuid") UUID uuid);
	
	@Query(value = "SELECT * FROM slots "
			+ "WHERE uuid =:slotUuid "
			+ "AND cloud_advisor_uuid =:companyUuid  "
			, nativeQuery = true)
	Slot findByUuidAndCloudAdvisor(@Param("slotUuid") UUID slotUuid,@Param("companyUuid") UUID companyUuid);

}
