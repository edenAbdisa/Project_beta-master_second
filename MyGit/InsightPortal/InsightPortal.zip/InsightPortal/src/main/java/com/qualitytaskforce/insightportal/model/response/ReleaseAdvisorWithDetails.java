package com.qualitytaskforce.insightportal.model.response;

import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;

public class ReleaseAdvisorWithDetails {

    ReleaseAdvisor releaseAdvisor;
    ArticleDetails articleDetails;

    public ReleaseAdvisorWithDetails() {
    }

    public ReleaseAdvisorWithDetails(ReleaseAdvisor releaseAdvisor, ArticleDetails articleDetails) {
        this.releaseAdvisor = releaseAdvisor;
        this.articleDetails = articleDetails;
    }

    public void setReleaseAdvisor(ReleaseAdvisor releaseAdvisor) {
        this.releaseAdvisor = releaseAdvisor;
    }

    public void setArticleDetails(ArticleDetails articleDetails) {
        this.articleDetails = articleDetails;
    }

    public ReleaseAdvisor getReleaseAdvisor() {
        return releaseAdvisor;
    }

    public ArticleDetails getArticleDetails() {
        return articleDetails;
    }
}
