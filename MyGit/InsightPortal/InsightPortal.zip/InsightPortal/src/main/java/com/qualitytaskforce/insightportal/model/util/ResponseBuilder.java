package com.qualitytaskforce.insightportal.model.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

public class ResponseBuilder {
	
	private ResponseEntity<String> response;

	private HttpHeaders headers = new HttpHeaders();

	public ResponseBuilder() {

	}

	public ResponseBuilder(String message, HttpStatus httpStatus) {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		int errorCode = getErrorCode(httpStatus.name());
		String error = parseErrorName(httpStatus.name());
		String responseText = "{\"timestamp\": " + System.currentTimeMillis() 
							+ ", \"status\": " + errorCode
							+ ", \"response\": \"" + error + "\"" 
							+ ", \"message\": \"" + message + "\""
							+ "}";
		this.response = new ResponseEntity<String>(responseText, headers, httpStatus);
	}

	public ResponseEntity<String> getResponse() {
		return this.response;
	}

	private String parseErrorName(String error){

		String text = error.toLowerCase();
		String t[] = text.split("_");
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < t.length; i++) {
			sb.append(Character.toUpperCase(t[i].charAt(0)));
			sb.append(t[i].substring(1));
			sb.append(" ");
		}
		return sb.toString().trim();
	}

	private int getErrorCode(String httpStatus) {
		switch (httpStatus) {
			case "CONTINUE" :
				return 100;
			case "SWITCHING_PROTOCOLS" :
				return 101;
			case "CHECKPOINT" :
				return 103;
			case "OK" :
				return 200;
			case "CREATED" :
				return 201;
			case "ACCEPTED" :
				return 202;
			case "NON_AUTHORITATIVE_INFORMATION" :
				return 203;
			case "NO_CONTENT" :
				return 204;
			case "RESET_CONTENT" :
				return 205;
			case "PARTIAL_CONTENT" :
				return 206;
			case "MULTI_STATUS" :
				return 207;
			case "ALREADY_REPORTED" :
				return 208;
			case "IM_USED" :
				return 226;
			case "MULTIPLE_CHOICES" :
				return 300;
			case "MOVED_PERMANENTLY" :
				return 301;
			case "FOUND" :
				return 302;
			case "SEE_OTHER" :
				return 303;
			case "NOT_MODIFIED" :
				return 304;
			case "TEMPORARY_REDIRECT" :
				return 307;
			case "PERMANENT_REDIRECT" :
				return 308;
			case "BAD_REQUEST" :
				return 400;
			case "UNAUTHORIZED" :
				return 401;
			case "PAYMENT_REQUIRED" :
				return 402;
			case "FORBIDDEN" :
				return 403;
			case "NOT_FOUND" :
				return 404;
			case "METHOD_NOT_ALLOWED" :
				return 405;
			case "NOT_ACCEPTED" :
				return 406;
			case "REQUEST_TIMEOUT" :
				return 408;
			case "CONFLICT" :
				return 409;
			case "GONE" :
				return 410;
			case "LENGTH_REQUIRED" :
				return 411;
			case "PRECONDITION_FAILED" :
				return 412;
			case "PAYLOAD_TOO_LARGE" :
				return 413;
			case "URI_TOO_LONG" :
				return 414;
			case "UNSUPPORTED_MEDIA_TYPE" :
				return 415;
			case "REQUESTED_RANGE_NOT_SATISFIABLE" :
				return 416;
			case "EXPECTATION_FAILED" :
				return 417;
			case "I_AM_A_TEAPOT" :
				return 418;
			case "UNPROCESSABLE_ENTITY" :
				return 422;
			case "LOCKED" :
				return 423;
			case "FAILED_DEPENDENCY" :
				return 424;
			case "UPGRADE_REQUIRED" :
				return 426;
			case "PRECONDITION_REQUIRED" :
				return 428;
			case "TOO_MANY_REQUESTS" :
				return 429;
			case "REQUEST_HEADER_FIELDS_TOO_LARGE" :
				return 431;
			case "UNAVAILABLE_FOR_LEGAL_REASONS" :
				return 451;
			case "INTERNAL_SERVER_ERROR" :
				return 500;
			case "NOT_IMPLEMENTED" :
				return 501;
			case "BAD_GATEWAY" :
				return 502;
			case "SERVICE_UNAVAILABLE" :
				return 503;
			case "GATEWAY_TIMEOUT" :
				return 504;
			case "HTTP_VERSION_NOT_SUPPORTED" :
				return 505;
			case "VARIANT_ALSO_NEGOTIATES" :
				return 506;
			case "INSUFFICIENT_STORAGE" :
				return 507;
			case "LOOP_DETECTED" :
				return 508;
			case "BANDWIDTH_LIMIT_EXCEEDED" :
				return 509;
			case "NOT_EXTENDED" :
				return 510;
			case "NETWORK_AUTHENTICATION_REQUIRED" :
				return 511;
			default :
				return 500;
		}
	}
}