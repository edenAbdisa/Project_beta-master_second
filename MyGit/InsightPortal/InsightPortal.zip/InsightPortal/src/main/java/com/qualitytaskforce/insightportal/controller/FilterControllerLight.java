package com.qualitytaskforce.insightportal.controller;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.ArticlesFilterService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.util.PositionFrom;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping(value = "/filter")
public class FilterControllerLight {

	public static final Logger LOGGER = LoggerFactory.getLogger(FilterControllerLight.class);

	@Autowired
	private ArticleService articleService;

	@Autowired
	private CategoryService categoryService;

	@Autowired
	ArticleRepository articleRepository;

	@Autowired
	ArticlesFilterService articlesFilterService;

	@GetMapping("/get-articles")
	public ResponseEntity<List<ArticleWhenList>> getArticles(
			@RequestParam(value = "part") String partStr,
			@RequestParam(value = "category") String category) throws Exception {

		List<Category> categories = new ArrayList<Category>();
		String categorydec = URLDecoder.decode(category, "UTF-8");
		if (categorydec.trim().length() < 1) {
			throw new Exception("Category param is empty");
		}

		categories = fetchCategories(categorydec, categories);
		if (!isExistCategories(categories)) {
			throw new DataNotFoundException("No categories found");
		}

		if (partStr.trim().length() < 1) {
			throw new Exception("Part param is empty");
		}

		int part = Integer.valueOf(partStr);
		if (part < 1) {
			throw new Exception("Part value is less then 1");
		}

		int quantity = 7;
		int from = PositionFrom.getPositionFrom(part, quantity);

		List<Article> articles = articleService.findByLimit(categories, "desc", from, quantity + 1);
		if (articles.size() < 1) {
			return new ResponseEntity<List<ArticleWhenList>>(
					Collections.<ArticleWhenList>emptyList(), HttpStatus.NO_CONTENT);
		}

		List<ArticleWhenList> articlesCutted = PrepareToShowInList.prepare(articles);
		return new ResponseEntity<List<ArticleWhenList>>(articlesCutted, HttpStatus.OK);
	}

	List<Category> fetchCategories(String categorydec, List<Category> categories) {
		if (categorydec.equals("All News")) {
			categories = categoryService.getAllCategories();
		} else {
			Category categoryObj = categoryService.findByName(categorydec);
			if (categoryObj != null) {
				categories.add(categoryObj);
			}
		}
		return categories;
	}

	boolean isExistCategories(List<Category> categories) {
		return (categories.size() > 0);
	}



	@PostMapping("/get-filtered-articles")
	public ResponseEntity<List<ArticleWhenList>> getFilteredArticles(@RequestBody String args)
			throws Exception {

		String keywords = "";
		String dateStart = "";
		String dateStop = "";
		JSONArray subcategoriesJson = new JSONArray(); // [desktop-browsers,java]

		try {
			JSONObject json = new JSONObject(args);
			keywords = json.get("keywords").toString();
			dateStart = json.get("dateStart").toString();
			dateStop = json.get("dateStop").toString();
			subcategoriesJson = json.getJSONArray("checkedSubcategories");
		} catch (JSONException e) {
			LOGGER.info("Error with getting filtered articles, args: {}", args, e);
		}

		if (keywords.trim().length() < 1) {
			throw new Exception("No keywords exist");
		}

		if (subcategoriesJson.length() < 1) {
			throw new Exception("No subcategories checked");
		}

		List<ArticleWhenList> articlesCutted = articlesFilterService.getFilteredArticles(dateStart,
				dateStop, keywords, subcategoriesJson);

		return new ResponseEntity<List<ArticleWhenList>>(articlesCutted, HttpStatus.OK);
	}



}

