package com.qualitytaskforce.insightportal.model.put;

import java.util.List;
import java.util.Set;
import java.util.UUID;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.URL;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ArticleCombinedRequestUpdate {
	
	
    @NotNull(message = "This field is required.")
    @JsonProperty("uuid")
    UUID uuid;

	@Size(min = 5, max = 90, message = "The title must be between {min} and {max} characters long")
    @NotNull(message = "This field is required.")
    @JsonProperty("title")
    String title;
	
	@NotNull(message = "This field is required.")
    @NotEmpty()
    @JsonProperty("summaryText")
    String summaryText;
	
	@NotNull(message = "This field is required.")
    @JsonProperty("richcardType")
    String richcardType;
    
    @JsonProperty("richcardBrand")
    String richcardBrand;
    
    @JsonProperty("richcardModel")
    String richcardModel;
    
    
    @NotNull(message = "This field is required.")
    @NotEmpty()
    @JsonProperty("fullText")
    String fullText;
    
    @JsonProperty("metaKeywords")
    String metaKeywords;
    
    @JsonProperty("testRecommendationId")
    UUID testRecommendationId;
    
    @JsonProperty("testRecommendation")
    String testRecommendation;
    
    @NotNull(message = "This field is required.")
    @JsonProperty("impactRatingName")
    int impactRatingName;
	
    @NotNull(message = "This field is required.")
    @NotEmpty()
    @JsonProperty("categoryName")
    String categoryName;
    
    @JsonProperty("subcategoryName")
    String subcategoryName;

    @URL()
    @NotNull(message = "This field is required.")
    @NotEmpty(message = "you must select main picture")
    @JsonProperty("artworkUrl")
    String artworkUrl;
    
    @JsonProperty("relatedArticles")
    List<String> relatedArticles;
    
    @JsonProperty("articleUpdates")
    List<JsonArticleUpdate> articleUpdates;

	@JsonProperty("releaseAdvisors")
    Set<JsonReleaseAdvisorPut> releaseAdvisors;

	@NotNull(message = "This field is required.")
	@JsonProperty("published")
	boolean published;
	
	@JsonProperty("isChangeUpdatedAt")
    boolean isChangeUpdatedAt;
	

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
    public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSummaryText() {
		return summaryText;
	}

	public void setSummaryText(String summaryText) {
		this.summaryText = summaryText;
	}
    
    public String getRichcardType() {
        return richcardType;
    }

    public void setRichcardType(String richcardType) {
        this.richcardType = richcardType;
    }
    
    public String getRichcardBrand() {
		return richcardBrand;
	}

	public void setRichcardBrand(String richcardBrand) {
		this.richcardBrand = richcardBrand;
	}

	public String getRichcardModel() {
		return richcardModel;
	}

	public void setRichcardModel(String richcardModel) {
		this.richcardModel = richcardModel;
	}

    
    public String getFullText() {
		return fullText;
	}

	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	
	
	public String getMetaKeywords() {
		return metaKeywords;
	}

	public void setMetaKeywords(String metaKeywords) {
		this.metaKeywords = metaKeywords;
	}

	public UUID getTestRecommendationId() {
		return testRecommendationId;
	}

	public void setTestRecommendationId(UUID testRecommendationId) {
		this.testRecommendationId = testRecommendationId;
	}
		
	public String getTestRecommendation() {
        return testRecommendation;
    }
	
	public void setTestRecommendation(String testRecommendation) {
		this.testRecommendation = testRecommendation;
	}
		
	public int getImpactRatingName() {
        return impactRatingName;
    }

    public void setImpactRatingName(int impactRatingName) {
        this.impactRatingName = impactRatingName;
    }
    
    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getSubcategoryName() {
		return subcategoryName;
	}

	public void setSubcategoryName(String subcategoryName) {
		this.subcategoryName = subcategoryName;
	}    
   
	public String getArtworkUrl() {
        return artworkUrl;
    }

    public void setArtworkUrl(String artworkUrl) {
        this.artworkUrl = artworkUrl;
    }    	
    
    public List<String> getRelatedArticles() {
		return relatedArticles;
	}

	public void setRelatedArticles(List<String> relatedArticles) {
		this.relatedArticles = relatedArticles;
	}
    
	 public List<JsonArticleUpdate> getArticleUpdates() {
		return articleUpdates;
	 }

	public void setArticleUpdates(List<JsonArticleUpdate> articleUpdates) {
		this.articleUpdates = articleUpdates;
	}
	
    public Set<JsonReleaseAdvisorPut> getReleaseAdvisors() {
		return releaseAdvisors;
	}

	public void setReleaseAdvisors(Set<JsonReleaseAdvisorPut> releaseAdvisors) {
		this.releaseAdvisors = releaseAdvisors;
	}	

	public boolean isPublished() {
		return published;
	}

	public void setPublished(boolean published) {
		this.published = published;
	}

	public boolean isChangeUpdatedAt() {
		return isChangeUpdatedAt;
	}

	public void setChangeUpdatedAt(boolean isChangeUpdatedAt) {
		this.isChangeUpdatedAt = isChangeUpdatedAt;
	}
 }
