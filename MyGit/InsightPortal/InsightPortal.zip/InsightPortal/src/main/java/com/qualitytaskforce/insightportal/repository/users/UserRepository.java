package com.qualitytaskforce.insightportal.repository.users;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;

public interface UserRepository extends JpaRepository<User, Long> {

	List<User> findByEmail(String email);
	
	User findByName(String userName);

	User getByEmail(String email);
	
	List<User> findByUserLevel (UserLevel userLevel);

    boolean existsByEmail(String s);

    User findByUuid (UUID uuid);
    
    List<User> findByCompany(String company);
}