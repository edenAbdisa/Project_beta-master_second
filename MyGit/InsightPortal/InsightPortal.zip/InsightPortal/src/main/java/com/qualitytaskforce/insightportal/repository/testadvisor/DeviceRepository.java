package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import com.qualitytaskforce.insightportal.model.testadvisor.DeviceWithUuid;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DeviceRepository extends JpaRepository<DeviceWithUuid, UUID> {

	@Query(value = "SELECT uuid, brand, model "
				+ "FROM ta_devices "
				+ "WHERE brand IN :brands "
				+ "AND model IN :models "
				+ "AND chipset IS NOT NULL"
				, nativeQuery = true)
    List<DeviceWithUuid> getBulkDevices(@Param("brands") List<String> brands, @Param("models") List<String> models);
	
	@Query(value = "SELECT uuid, brand, model "
			+ "FROM ta_devices "
			+ "WHERE brand = :brand "
			+ "AND model  = :model" 

			, nativeQuery = true)
	DeviceWithUuid getDevice(@Param("brand") String brand, @Param("model") String model);

	@Query(value = "SELECT uuid,brand,model "
			+ "FROM ta_devices "
			+ "WHERE uuid = :uuid"
			, nativeQuery = true)
	List<DeviceWithUuid> findByUuid(@Param("uuid") java.util.UUID  uuid);

	@Query(value = "SELECT uuid, brand, model,img_link"
			+ "FROM ta_devices "
			+ "WHERE uuid = :uuid " 

			, nativeQuery = true)
	DeviceWithUuid getDeviceByUuid(@Param("uuid") UUID uuid);
}