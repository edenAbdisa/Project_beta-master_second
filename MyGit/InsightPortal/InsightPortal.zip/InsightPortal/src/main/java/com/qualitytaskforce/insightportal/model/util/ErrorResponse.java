package com.qualitytaskforce.insightportal.model.util;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ErrorResponse {
	
	private Long timestamp;
	private int status;
	private String error;
	private String message;
	@JsonIgnore
	private HttpStatus httpStatus;
	
	public ErrorResponse(){
		this.timestamp = System.currentTimeMillis();
	}
	
	public ErrorResponse(HttpStatus httpStatus, String message){
		this();
		this.httpStatus = httpStatus;
		setStatus(httpStatus.value());
		error = parseErrorName(httpStatus.name());
		setMessage(message);
	}
	
	public Long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Long timestamp) {
		this.timestamp = timestamp;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = parseErrorName(error);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

	private String parseErrorName(String error){

		String text = error.toLowerCase();
		String t[] = text.split("_");
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < t.length; i++) {
			sb.append(Character.toUpperCase(t[i].charAt(0)));
			sb.append(t[i].substring(1));
			sb.append(" ");
		}
		return sb.toString().trim();
	}	
}