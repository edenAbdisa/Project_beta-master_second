package com.qualitytaskforce.insightportal.model;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.qualitytaskforce.insightportal.model.users.User;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "email_templates")
public class EmailTemplate implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "subject", nullable = false, length = 50)
	private String subject;
	
	@Column(name = "from_email", nullable = false)
	private String fromEmail;
	
	@Column(name = "content", nullable = false, length = 65535)
	private String content;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "check_in_by")
	private User user;
	
	
	public EmailTemplate() {
	}

	public EmailTemplate(UUID uuid, String subject, String fromEmail, String content) {
		this.uuid = uuid;
		this.subject = subject;
		this.fromEmail = fromEmail;
		this.content = content;		
	}

	public EmailTemplate(UUID uuid, User user, String subject, String fromEmail, String content) {
		this.uuid = uuid;
		this.user = user;
		this.subject = subject;
		this.fromEmail = fromEmail;
		this.content = content;		
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getSubject() {
		return this.subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getFromEmail() {
		return this.fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}
	
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}	
	
	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
