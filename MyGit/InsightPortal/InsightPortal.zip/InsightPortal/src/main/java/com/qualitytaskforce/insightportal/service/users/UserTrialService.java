package com.qualitytaskforce.insightportal.service.users;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;


import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.repository.users.UserTrialRepository;

@Service
public class UserTrialService {
	
	@Autowired
	UserService userService;
	
	@Autowired
	UserTrialService userTrialService;
	
	@Autowired
	UserTrialRepository userTrialRepository;
	
	public void save (UserTrial trial) {
		userTrialRepository.save(trial);
	}
	
	public UserTrial findByUser (User user) {
		return userTrialRepository.findByUser(user);
	}
	
	public UserTrial findByConfirmationToken(String token) {
		return userTrialRepository.findByConfirmationToken(token);
	}
	
	User getUserLocal(String email) throws DataNotFoundException {
		List<User> userList = userService.findByEmail(email);
    	if (userList.isEmpty()) {
    		throw new DataNotFoundException("User with such email not found.");
    	}
    	return userList.get(0);
	}
	
	Integer getTrialValue (Date expireDate) throws DataNotFoundException {
		Date now = new Date();
    	if (expireDate == null) {
    		throw new DataNotFoundException("Expire date not found.");
    	}
    	
		int daysBeforeExpire = (int) ChronoUnit.DAYS.between(now.toInstant(), expireDate.toInstant());
		if (expireDate.after(now)) {
			return daysBeforeExpire; // always 0,1,2,more
		} else {
			return -1; // expired
		}
	}
	
	public Integer checkTrial (String email) throws DataNotFoundException {
		
    	User user = getUserLocal(email);
    	UserLevel userLevel = user.getUserLevel();
    	boolean isManualTrial = userLevel.getName().equals("ManualTrial");
    	if (isManualTrial) {
    		return 0;
    	}
    	
    	UserTrial userTrial = userTrialService.findByUser(user);
    	Date expireDate = userTrial.getExpireAt();
    	Integer trialValue = getTrialValue(expireDate);
    	return trialValue;
	}
	
	public boolean verifyToken(String token) {
        UserTrial userTrial = findByConfirmationToken(token);
        if (userTrial == null) {
            return false;        
		} else {
			return true;
		}
    }
	
	public void invalidateToken(UserTrial userTrial) {
       userTrial.setConfirmationToken(null);
       save(userTrial);
	}
	
	public String generateVerificationToken() {
        SecureRandom random = new SecureRandom();
        String salt = new BigInteger(130, random).toString(16);
        String token = BCrypt.hashpw(salt, BCrypt.gensalt(10)).substring(6,32);
        return token;
    }
}