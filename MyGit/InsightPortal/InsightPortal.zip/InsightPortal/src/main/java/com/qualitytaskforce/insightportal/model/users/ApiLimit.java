package com.qualitytaskforce.insightportal.model.users;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Api_limits", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
public class ApiLimit implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "name", unique = true, nullable = false, length = 50)
	private String name;

	@Column(name = "low_hourly", nullable = false)
	private int lowHourly;

	@Column(name = "low_monthly", nullable = false)
	private int lowMonthly;

	@Column(name = "med_hourly", nullable = false)
	private int medHourly;

	@Column(name = "med_monthly", nullable = false)
	private int medMonthly;

	@Column(name = "high_hourly", nullable = false)
	private int highHourly;

	@Column(name = "high_monthly", nullable = false)
	private int highMonthly;

	public ApiLimit() {
	}
	
	public ApiLimit(UUID uuid, String name, int lowHourly, int lowMonthly, int medHourly, int medMonthly,
					int highHourly, int highMonthly) {
		this.uuid = uuid;
		this.name = name;
		this.lowHourly = lowHourly;
		this.lowMonthly = lowMonthly;
		this.medHourly = medHourly;
		this.medMonthly = medMonthly;
		this.highHourly = highHourly;
		this.highMonthly = highMonthly;
	}

	/**
	 * @return the uuid
	 */
	public UUID getUuid() {
		return uuid;
	}

	/**
	 * @param uuid the uuid to set
	 */
	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the lowHourly
	 */
	public int getLowHourly() {
		return lowHourly;
	}

	/**
	 * @param lowHourly the lowHourly to set
	 */
	public void setLowHourly(int lowHourly) {
		this.lowHourly = lowHourly;
	}

	/**
	 * @return the lowMonthly
	 */
	public int getLowMonthly() {
		return lowMonthly;
	}

	/**
	 * @param lowMonthly the lowMonthly to set
	 */
	public void setLowMonthly(int lowMonthly) {
		this.lowMonthly = lowMonthly;
	}

	/**
	 * @return the medHourly
	 */
	public int getMedHourly() {
		return medHourly;
	}

	/**
	 * @param medHourly the medHourly to set
	 */
	public void setMedHourly(int medHourly) {
		this.medHourly = medHourly;
	}

	/**
	 * @return the medMonthly
	 */
	public int getMedMonthly() {
		return medMonthly;
	}

	/**
	 * @param medMonthly the medMonthly to set
	 */
	public void setMedMonthly(int medMonthly) {
		this.medMonthly = medMonthly;
	}

	/**
	 * @return the highHourly
	 */
	public int getHighHourly() {
		return highHourly;
	}

	/**
	 * @param highHourly the highHourly to set
	 */
	public void setHighHourly(int highHourly) {
		this.highHourly = highHourly;
	}

	/**
	 * @return the highMonthly
	 */
	public int getHighMonthly() {
		return highMonthly;
	}

	/**
	 * @param highMonthly the highMonthly to set
	 */
	public void setHighMonthly(int highMonthly) {
		this.highMonthly = highMonthly;
	}
}