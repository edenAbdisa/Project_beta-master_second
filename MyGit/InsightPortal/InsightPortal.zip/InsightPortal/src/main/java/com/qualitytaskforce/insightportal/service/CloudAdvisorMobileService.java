package com.qualitytaskforce.insightportal.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

import com.qualitytaskforce.insightportal.repository.CloudAdvisorMobileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;

/**
 * The Class CloudAdvisorMobileService.
 */
@Service
public class CloudAdvisorMobileService {
    
    /** The cloud advisor mobile repository. */
    @Autowired
    private CloudAdvisorMobileRepository cloudAdvisorMobileRepository;
	
	/**
	 * Find mobile Operating System.
	 *
	 * @return the list
	 * @throws DataNotFoundException the data not found exception
	 */
	public List<String> findMobileOSs() throws DataNotFoundException {
		List<String> mobileOSs = new ArrayList<>();
		mobileOSs = cloudAdvisorMobileRepository.findMobileOSs();
		if (mobileOSs.size() < 1) {
			throw new DataNotFoundException("No mobile OS's were found.");
		}
		HashSet<String> mobileOSsHashSet = new HashSet<String>(mobileOSs);
		List<String> mobileOperatingSystems = new ArrayList<String>(mobileOSsHashSet); 
        Collections.sort(mobileOperatingSystems);
		return mobileOperatingSystems;
	}
		
	/**
	 * Find mobile browsers.
	 *
	 * @return the list
	 * @throws DataNotFoundException the data not found exception
	 */
	public List<String> findMobileBrowsers() throws DataNotFoundException {
		List<String> mobileBrowsers = new ArrayList<>();
		mobileBrowsers = cloudAdvisorMobileRepository.findMobileBrowsers();
		if (mobileBrowsers.size() < 1) {
			throw new DataNotFoundException("No mobile browsers were found.");
		}
		HashSet<String> mobileBrowsersHashSet = new HashSet<String>(mobileBrowsers);
		List<String> mobileBrowsersq = new ArrayList<String>(mobileBrowsersHashSet); 
        Collections.sort(mobileBrowsersq); 
		return mobileBrowsersq;
	}
	
	
}