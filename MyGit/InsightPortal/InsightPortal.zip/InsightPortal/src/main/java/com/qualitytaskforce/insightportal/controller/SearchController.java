/*package com.qualitytaskforce.insightportal.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.util.HtmlToString;
import com.qualitytaskforce.insightportal.util.PositionFrom;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/search")
public class SearchController {

	// private static Logger LOG = LoggerFactory.getLogger(SearchController.class);

	@Autowired
	ArticleService articlesService;
	
	@Autowired
	ArticleRepository articleRepository;
	
	@GetMapping("/suggestion-tags")
	public ResponseEntity<List<SearchSuggestion>> getSuggestions(@RequestParam(value = "title") String inputText) throws Exception{
		
	// ==== CONST PARAMETER ========
		int typeSearchField = 4;
	// ============================
	
	String text = inputText;
	if (!text.matches("^[a-zA-Z0-9]*$"))		
		return new ResponseEntity<List<SearchSuggestion>>(Collections.<SearchSuggestion>emptyList(), HttpStatus.NO_CONTENT);
		//throw new Exception("Warning: Input text contains non-alphanumeric symbols");
	
	HashSet<String> suggestions = new HashSet<String>();
	int minLength = 2;
	
	
	if(text.trim().length() > minLength  && !(text.equals("a")) && !(text.equals("the"))){
		List<Article> findArticles = articleRepository.search(text, typeSearchField, false, false, false, null, null, 0, 0);
		System.out.println(findArticles.size());

		int quantityWords = text.split("\\s+").length;
		System.out.println("Quantity: "+quantityWords);
		for(int k=0;k<findArticles.size();k++){
			
			String title = findArticles.get(k).getTitle();
			String summaryText = findArticles.get(k).getSummaryText();
			String outFullText = HtmlToString.convert(findArticles.get(k).getFullText());
			// String outFullText = previousFullText.replaceAll("<[^>]*>", " ");
			HashSet<String> fromTitle = new HashSet<String>();
			HashSet<String> fromSummaryText = new HashSet<String>();
			HashSet<String> fromFullText = new HashSet<String>();
			
			switch(typeSearchField) {
				case 1:
					fromTitle = findInText(text, quantityWords, typeSearchField, title);				
				break;				
				case 2:
					fromSummaryText = findInText(text, quantityWords, typeSearchField, summaryText);
				break;				
				case 3:
					fromFullText = findInText(text, quantityWords, typeSearchField, outFullText);
				break;
				case 4:
					fromTitle = findInText(text, quantityWords, typeSearchField, title);	
					fromSummaryText = findInText(text, quantityWords, typeSearchField, summaryText);
					fromFullText = findInText(text, quantityWords, typeSearchField, outFullText);
				break;				
				case 5:
					fromTitle = findInText(text, quantityWords, typeSearchField, title);
					fromSummaryText = findInText(text, quantityWords, typeSearchField, summaryText);
				break;
				case 6:
					fromSummaryText = findInText(text, quantityWords, typeSearchField, summaryText);
					fromFullText = findInText(text, quantityWords, typeSearchField, outFullText);
				break;
				case 7:
					fromTitle = findInText(text, quantityWords, typeSearchField, title);
					fromFullText = findInText(text, quantityWords, typeSearchField,  outFullText);
				break;
				default:
				break;			
			}			
			
			suggestions.addAll(fromTitle);
			suggestions.addAll(fromSummaryText);
			suggestions.addAll(fromFullText);
		}
		System.out.println(Arrays.deepToString(suggestions.toArray(new String[0])));
	}
	
	List<SearchSuggestion> suggestionsObj = new ArrayList<SearchSuggestion>();
	if (suggestions.size() > 0) {
		List<String> results = new ArrayList<String>(suggestions);
		results.sort((p1,p2) -> p2.compareTo(p1));
		results.sort((p1,p2) -> p1.length() - p2.length());
		
		
		System.out.println(Arrays.deepToString(results.toArray(new String[0])));
		
		SearchSuggestion suggestion = new SearchSuggestion();
		
		int maxSize = 7;
		if (results.size() <= 7) maxSize = results.size();
		
		for(int m=0;m<maxSize;m++){
			suggestion = new SearchSuggestion();
			suggestion.setSuggestion(results.get(m));
			suggestionsObj.add(suggestion);
		}
	}
	
	return new ResponseEntity<List<SearchSuggestion>>(suggestionsObj, HttpStatus.OK);
}
	
	
	
	@GetMapping("/get-articles-in-list")
	public ResponseEntity<List<ArticleWhenList>> getArticlesInList(@RequestParam(value = "keywords") String keywords ,
																	@RequestParam(value = "part") String partStr) {
		
		String text = keywords.replace("-", " ");
		int part = Integer.valueOf(partStr);
		int quantity = 7;
		int from = PositionFrom.getPositionFrom(part, quantity);
		
		int typeSearchField = 4;
		List<Article> foundArticles = articleRepository.search(text, typeSearchField, false, true, true, null, null, from, quantity+1);
		if (foundArticles == null)
			return new ResponseEntity<List<ArticleWhenList>>(Collections.<ArticleWhenList>emptyList(), HttpStatus.NO_CONTENT);
		
		List<ArticleWhenList> articlesCutted = PrepareToShowInList.prepare(foundArticles);
		return new ResponseEntity<List<ArticleWhenList>>(articlesCutted, HttpStatus.OK);
	}
	

	//@ExceptionHandler(org.hibernate.search.exception.EmptyQueryException.class)
	//public ResponseEntity<ErrorResponse> handleError(Exception exception) {
		//ErrorResponse er = new ErrorResponse(HttpStatus.BAD_REQUEST, "One of the query parameters is empty.");
		//LOG.info("Empty query parameter: {}", exception.getMessage());
		//return new ResponseEntity<ErrorResponse>(er, er.getHttpStatus());
	//}
	
	
	HashSet<String> findInText(String keywords, int quantityWords, int typeSearchField, String text) {
	
		HashSet<String> suggestions = new HashSet<String>();
		int indexStart = 0;
		int indexStop = 0;
		boolean flag = true;
		
		String textLocal = text;
		
		if (typeSearchField == 3) {
			if (!(textLocal.contains(keywords))) flag = false;
		}
			
		int matchFrom = 0;
		int showSecondAfter = 0;
		int showNextAfter = 0;
		int counter = 0;
		int counterBound = 0;
		
		if(flag) {
			 switch (quantityWords) {
					 
				 case 1:
				 	 //textLocal = "Vivaldi 1.11 has been officially released. The full release notes are available here.".toLowerCase(); //<========== CHANGE AFTER TEST
					 textLocal = textLocal.toLowerCase();
					 indexStart = textLocal.indexOf(keywords);
					 counter = 0;
					 showSecondAfter = 4;
					 counterBound = 2;
					 
					 while (indexStart >= 0) {
						 	counter = 0;
						 	while((indexStart-1)>= 0 && Character.isLetter(textLocal.charAt(indexStart-1))){
						 		indexStart--;							 	
						 	}
						 	
							indexStop = indexStart;				
							if(keywords.length() >= showSecondAfter){
								while(indexStop < textLocal.length() && counter < counterBound){
									if(Character.isLetter(textLocal.charAt(indexStop)) || (textLocal.charAt(indexStop)>= '0' && textLocal.charAt(indexStop) <='9')){
										indexStop++;
									} else{
										//System.out.println(textLocal.charAt(indexStop));
										//System.out.println(textLocal.charAt(indexStop+1));
										if(counter < (counterBound - 1) && ((textLocal.charAt(indexStop) != '.')&&(textLocal.charAt(indexStop) != ',')))// counter < 1								
											indexStop++;
										counter++;										
									}
								}								
							} else {
								while(indexStop < textLocal.length() && Character.isLetter(textLocal.charAt(indexStop))){
									indexStop++;
								}								
							}							
								
							suggestions.add(textLocal.substring(indexStart, indexStop).toLowerCase().trim());
							indexStart = textLocal.indexOf(keywords, indexStop+1);			
					 }
				 
				 break;					 
					 
				 case 2: case 3: case 4:
					 //textLocal = "Vivaldi 1.11 has been officially released. The full release notes are available here.".toLowerCase();
					 matchFrom = 0;
					 indexStart = startEndPhrase(keywords,textLocal,matchFrom,true);						
					 showNextAfter = 2;
					 counter = 0;
					 
					 if(quantityWords == 2) counterBound = 3;
					 else if(quantityWords == 3) counterBound = 2;
					 else if(quantityWords == 4) counterBound = 1;
					 
					 while (indexStart >= 0) {
						 	counter = 0;
						 	while((indexStart-1)>= 0 && Character.isLetter(textLocal.charAt(indexStart-1))){
						 		indexStart--;							 	
						 	}
						 	
							indexStop = startEndPhrase(keywords,textLocal,matchFrom,false);
							String[] keywordsArr = keywords.split("\\s+");
							
							if(keywordsArr[1].length() >= showNextAfter){
								
								while(indexStop < textLocal.length() && counter < counterBound) {
									if (Character.isLetter(textLocal.charAt(indexStop)) || (textLocal.charAt(indexStop)>= '0' && textLocal.charAt(indexStop) <='9')){
										indexStop++;						
									}else {
										if(counter < (counterBound - 1) && ((textLocal.charAt(indexStop) != '.')&&(textLocal.charAt(indexStop) != ',')))// counter < 1
											indexStop++;
										counter++;
									}
								}								
									
								suggestions.add(textLocal.substring(indexStart, indexStop).toLowerCase().trim());
								matchFrom = indexStop+1;
								if(matchFrom < textLocal.length())
									indexStart = startEndPhrase(keywords,textLocal,matchFrom,true);
								else
									indexStart = -1;
							}
					 }	
					 
				 break;
			 	default:
				break;
			 }
		 }
		
		return suggestions;
	}

	int startEndPhrase (String keyword, String text, int matchFrom, boolean type){		
	    Pattern word = Pattern.compile(keyword.toLowerCase());
	    text = text.substring(matchFrom);
	    Matcher match = word.matcher(text.toLowerCase());

	    while (match.find()) {
	        if (type)
	        	return match.start() + matchFrom;
	        else
	        	return (match.end()-1) + matchFrom;	    	
	    }
		return -1;
	}
	
	
}
// end of main
	

 class SearchSuggestion {
	
	String suggestion;

	public String getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}	 
	 
} */