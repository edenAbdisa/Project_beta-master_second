package com.qualitytaskforce.insightportal.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.qualitytaskforce.insightportal.model.BrowserRichCard;

public interface BrowserRichCardRepository extends JpaRepository<BrowserRichCard, UUID> {
	
	@Query(value = "SELECT DISTINCT brand FROM ta_browsers " // brand or name
	        + "WHERE (release_date IS NOT NULL) "
			+ "ORDER BY brand ASC"
	        , nativeQuery = true)
	List<String> getBrowserBrands();
	
	@Query(value = "SELECT name FROM ta_browsers " // brand or name
    + "WHERE (release_date IS NOT NULL) "
	+ "ORDER BY brand ASC"
    , nativeQuery = true)
	List<String> getBrowserName();
	@Query(value = "SELECT concat(name, ' ' ,version) FROM ta_browsers "
		 + "WHERE brand = :choosenBrand ORDER BY version DESC"
	     , nativeQuery = true)
	List<String> getBrowserModels(@Param("choosenBrand") String choosenBrand);

	@Query(value = "SELECT *, "
			+ "LOWER(CONCAT(" 
			+ "SUBSTR(HEX(uuid), 1, 8), '-'," 
			+ "SUBSTR(HEX(uuid), 9, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 13, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 17, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 21)" 
			+ ")) FROM ta_browsers "
			 + "WHERE brand = :choosenBrand ORDER BY version DESC"
		     , nativeQuery = true)
	BrowserRichCard getBrowserModelx(@Param("choosenBrand") String choosenBrand);
	
	@Query(value = "SELECT LOWER(CONCAT(" 
			+ "SUBSTR(HEX(uuid), 1, 8), '-'," 
			+ "SUBSTR(HEX(uuid), 9, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 13, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 17, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 21)" 
			+ ")) FROM ta_browsers "
			+ "WHERE brand = :choosenBrand AND concat(name, ' ' ,version) = :version ORDER BY version DESC LIMIT 1"
			, nativeQuery = true)
	String getBrowserUuid(@Param("choosenBrand") String brand, @Param("version") String version);
	
	@Query(value = "SELECT * FROM ta_browsers " // brand or name
		    + "WHERE name =:name "
			+ "AND version =:version"
		    , nativeQuery = true)
	BrowserRichCard getBrowserByNameAndVersion(@Param("name") String name,@Param("version") String version);
	
	BrowserRichCard findByUuid(UUID uuid);	
		
}
