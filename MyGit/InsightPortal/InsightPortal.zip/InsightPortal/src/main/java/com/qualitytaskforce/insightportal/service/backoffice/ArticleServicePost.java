package com.qualitytaskforce.insightportal.service.backoffice;

import java.util.Date;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.ImpactRating;
import com.qualitytaskforce.insightportal.model.RelatedArticles;
import com.qualitytaskforce.insightportal.model.SefURL;
import com.qualitytaskforce.insightportal.model.TestRecommendation;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.post.ArticleCombinedRequest;
import com.qualitytaskforce.insightportal.model.put.JsonReleaseAdvisorPut;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.repository.SefURLRepository;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.BrowserRichCardService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.service.ImpactRatingService;
import com.qualitytaskforce.insightportal.service.MobileDeviceRichCardService;
import com.qualitytaskforce.insightportal.service.RelatedArticlesService;
import com.qualitytaskforce.insightportal.service.ReleaseAdvisorService;
import com.qualitytaskforce.insightportal.service.SefURLService;
import com.qualitytaskforce.insightportal.service.SubcategoryService;
import com.qualitytaskforce.insightportal.service.TestRecommendationService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.util.ReadTimeMin;
import com.qualitytaskforce.insightportal.util.StringToSefURL;

@Service
public class ArticleServicePost {
	
	private static Logger LOGGER = LoggerFactory.getLogger(ArticleServicePost.class);

	@Autowired
	ArticleRepository articleRepository;

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	SubcategoryService subcategoryService;
	
	@Autowired
	SefURLService sefURLService;
	
	@Autowired
	ReleaseAdvisorService releaseAdvisorService;
	
	@Autowired
	BrowserRichCardService browserService;
	
	@Autowired
	MobileDeviceRichCardService mobileDeviceService;
	
	@Autowired
	TestRecommendationService testRecommendationService;
	
	@Autowired
	ImpactRatingService impactRatingService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	RelatedArticlesService relatedArticleService;
	
	@Autowired
	ArticleService articleService;

	@Autowired
	SefURLRepository sefURLRepository;
	
	@Autowired
	GetRichcardIdUtil rcUtil;

	@PersistenceContext
	private EntityManager entityManager;
	
	@Transactional
	public void backofficePost(ArticleCombinedRequest articleCombinedRequest) {
		
		ArticleCombinedRequest acRequest = articleCombinedRequest;

    	// USER
    	User user = getContextUser();

        SefURL sefURL = new SefURL();
        String sefUrlString = StringToSefURL.stringToSefURL(acRequest.getTitle());
        sefURL.setSefUrl(sefUrlString);
        sefURLService.save(sefURL);

        Category category = new Category();
        category = categoryService.findByName(acRequest.getCategoryName());

        ImpactRating impactRating = new ImpactRating();
        impactRating = impactRatingService.findByName(acRequest.getImpactRatingName());

        TestRecommendation testRecommendation = null;
        if (acRequest.getTestRecommendation().length() > 0) {
        	testRecommendation = new TestRecommendation();
            testRecommendation.setContent(acRequest.getTestRecommendation());
            testRecommendation.setUser(user);
            testRecommendationService.save(testRecommendation);
        }

        Article article = new Article();
        article.setCategory(category);
        if (acRequest.getSubcategoryName().length() > 0) {
        	article.setSubcategory(acRequest.getSubcategoryName());
		} else {
			article.setSubcategory(null);
		}
        
        article.setImpactRating(impactRating);
        article.setSefURL(sefURL);
        article.setTestRecommendation(testRecommendation);
        article.setUserByCreatedBy(user);
        article.setUserByUpdatedBy(user);
        article.setUserByCheckInBy(null);
        article.setTitle(acRequest.getTitle());
        article.setSummaryText(acRequest.getSummaryText());
        article.setFullText(acRequest.getFullText());
        /*if (acRequest.getMetaKeywords().length() > 0) {
        	article.setMetaKeywords(acRequest.getMetaKeywords());
        } else {
        	article.setMetaKeywords(null);
        }*/
        article.setMetaKeywords(null);
        
        article.setImgLink(acRequest.getArtworkUrl());
        ReadTimeMin timeMin = new ReadTimeMin();
        int min = timeMin.readTime(acRequest.getFullText());
        article.setReadTime(min);

        article.setRichcardType(acRequest.getRichcardType());

    	if (acRequest.getRichcardBrand() != null && acRequest.getRichcardModel() != null) {
    		UUID richcardId = rcUtil.getRichcardId(acRequest.getRichcardType(), acRequest.getRichcardBrand(), acRequest.getRichcardModel());
    		article.setRichcardId(richcardId);
    	} else {
    		article.setRichcardId(null);
    	}        
    	
    	boolean isPublished = acRequest.isPublished();
    	article.setPublished(isPublished);
    	if (isPublished) {
			article.setPublishDate(new Date());
		}

        
        article.setCreatedAt(new Date());
        article.setUpdatedAt(new Date());
        try {       	
        
	        try {
	        	articleService.save(article);
	        } catch (Exception e) {
	        	LOGGER.info(e.getMessage());
	        } finally {
	        	try {
		        	for (String title : acRequest.getRelatedArticles()) {
		            	
		                RelatedArticles relatedArticles = new RelatedArticles();
		                relatedArticles.setArticleByOriginalArticleId(article);
		                System.out.println(title);
		                Article related = articleService.findByTitle(title);
		                relatedArticles.setArticleByRelatedArticle(related);
		                relatedArticleService.save(relatedArticles);
		            }
	        	}catch(Exception e) {
	        		LOGGER.info(e.getMessage());
	        	} finally {
	        		try {        		
		        		if (acRequest.getReleaseAdvisors().size() > 0) {
		        	    	JsonReleaseAdvisorPut jsonRA = acRequest.getReleaseAdvisors().iterator().next();
		        	    	releaseAdvisorService.createWhenUpdateArticle(jsonRA, article);
		        	    }
		        		} catch(Exception e) {
		        			LOGGER.info(e.getMessage());
		        		}
	        	}
	        }
        } catch(Exception e) {
        	LOGGER.info(e.getMessage());
        }		
	}
	
	User getContextUser () {
		 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	     String email = auth.getName(); // in unknown way return email
	     User contextuser = userService.findByEmail(email).get(0);
	     return contextuser;
	 }
}
