package com.qualitytaskforce.insightportal.service.cloudadvisor;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.model.cloudadvisor.TestAdvisorOperatingSystem;
import com.qualitytaskforce.insightportal.repository.cloudadvisor.TestAdvisorOperatingSystemRepository;


/**
 * The Class TestAdvisorOperatingSystemService.
 */
@Service
public class TestAdvisorOperatingSystemService {
	
	/** The test advisor operating system repository. */
	@Autowired
	private TestAdvisorOperatingSystemRepository testAdvisorOperatingSystemRepository;
	
	/**
	 * Gets the os.
	 *
	 * @param name the name
	 * @return the os
	 */
	public List<TestAdvisorOperatingSystem> getOS(String name) {
		return testAdvisorOperatingSystemRepository.getOS(name);
	} 
	
	/**
	 * Gets the operating systems name.
	 *
	 * @return the operating systems name
	 */
	public List<String> getOperatingSystemsName() {
		return testAdvisorOperatingSystemRepository.getOperatingSystemsName();
	}
	
	/**
	 * Gets the single OS.
	 *
	 * @param name the name
	 * @param version the version
	 * @return the single OS
	 */
	public TestAdvisorOperatingSystem getSingleOS(String name,String version) {
		return testAdvisorOperatingSystemRepository.getSingleOS(name,version);
	}
	
	/**
	 * Gets the os name.
	 *
	 * @param uuid the uuid
	 * @return the os name
	 */
	public List<TestAdvisorOperatingSystem> getOsName(TestAdvisorOperatingSystem uuid) {
		return testAdvisorOperatingSystemRepository.getOsName(uuid.getUuid());
	}
}
