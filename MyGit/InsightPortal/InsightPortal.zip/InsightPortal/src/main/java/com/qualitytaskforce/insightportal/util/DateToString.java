package com.qualitytaskforce.insightportal.util;

import java.util.Date;

public class DateToString {
	
	public String dateToString(Date date){
		
		/**
		 * TEMPLATE 
		 * "2017-10-09 14:21:58" 
		 *
		 */		
		
		String [] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		
		String dateStr = date.toString();		
		
		String year = dateStr.substring(0, 4);
		
		int month = Integer.parseInt(dateStr.substring(5, 7));		
		
		String monthStr = months[month - 1];		
		
		String day = dateStr.substring(8, 10);			
		
		String result = (day+" "+monthStr+" "+year); 
	
	return result ; 	
	
	}

}
