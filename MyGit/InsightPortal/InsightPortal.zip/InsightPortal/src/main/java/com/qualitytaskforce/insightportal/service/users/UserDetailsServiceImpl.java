package com.qualitytaskforce.insightportal.service.users;

import static java.util.Collections.emptyList;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.repository.users.UserRepository;
import com.qualitytaskforce.insightportal.service.LoginAttemptService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private HttpServletRequest request;

    @Autowired
    private LoginAttemptService loginAttemptService;

    @Override
    public UserDetails loadUserByUsername(String credentials) throws UsernameNotFoundException {
        String ip = getClientIP();

        if (loginAttemptService.isBlocked(ip)) {
            throw new RuntimeException("blocked");
        } else {
            String loginPart = credentials.split(";")[0];

            List<User> userList = userRepository.findByEmail(loginPart);

            if (userList.isEmpty()) {
                throw new UsernameNotFoundException("Could not find the user: " + loginPart);
            }
            if (userList.get(0).isBlocked()) {
                throw new RuntimeException("Account has blocked.");
            }
            /* Create a UserDetails User: email -> username, password -> password (for reference check out userdetails.User constructor)*/
            User user = userList.get(0);
            return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), emptyList());
        }


    }


    public String getClientIP() {
        String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0];
    }
}
