package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class MobileDevice {
	
	@Id
	private UUID uuid;

	@Column(name = "device_brand")
	private String brand;

	@Column(name = "device_model")
	private String model;

	@Column(name = "device_type")
	private String type;

	@Column(name = "os_name")
	private String osName;

	@Column(name = "os_version")
	private String osVersion;

	@Column(name = "marketpen")
	private float marketPen;

	public MobileDevice () {
	}

	public MobileDevice(UUID uuid, String brand, String model, String type, String osName, 
						String osVersion, float marketPen) {
		this.uuid = uuid;
		this.brand = brand;
		this.model = model;
		this.type = type;
		this.osName = osName;
		this.osVersion = osVersion;
		this.marketPen = marketPen;
	}

	public String getBrand() {
		return this.brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return this.model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getOsName() {
		return this.osName;
	}

	public void setOsName(String osName) {
		this.osName = osName;
	}

	public String getOsVersion() {
		return this.osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}
	
	public float getMarketPen() {
		return this.marketPen;
	}

	public void setMarketPen(float marketPen) {
		this.marketPen = marketPen;
	}
}