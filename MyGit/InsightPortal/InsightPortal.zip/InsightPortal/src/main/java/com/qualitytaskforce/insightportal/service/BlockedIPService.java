package com.qualitytaskforce.insightportal.service;

import com.qualitytaskforce.insightportal.model.BlockedIP;
import com.qualitytaskforce.insightportal.repository.BlockedIPRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BlockedIPService {

    @Autowired
    BlockedIPRepository blockedIPRepository;
    public void save(BlockedIP ip){
        blockedIPRepository.save(ip);
    }

    public boolean findBlockedIP(String IP) {
        return  blockedIPRepository.findBlockedIPByIpAddress(IP);
    }

}
