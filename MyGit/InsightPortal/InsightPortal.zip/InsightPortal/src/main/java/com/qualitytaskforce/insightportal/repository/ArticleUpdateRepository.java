package com.qualitytaskforce.insightportal.repository;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ArticleUpdate;

public interface ArticleUpdateRepository extends JpaRepository<ArticleUpdate, UUID> {
		
	List<ArticleUpdate> findByArticles (Article article);
	
	ArticleUpdate findByUuid (UUID uuid);
	
	void delete(UUID uuid);
}