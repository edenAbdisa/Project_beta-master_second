package com.qualitytaskforce.insightportal.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/*****************
*  Very simple class for standard api response
* ****************/
public class ApiResponse extends Throwable {

    @JsonProperty("status")
    private String status;
    @JsonProperty("message")
    private String message;

    public ApiResponse(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public String getMessage() {
        return message;
    }
}