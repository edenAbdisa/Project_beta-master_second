package com.qualitytaskforce.insightportal.model.util;

import java.util.Map;

public class ReleaseAdvisorFilterCriteria {
	private String uuid;
	private String category;
	private String title;
	private String subtitle;
	private String published;
	private String startDate;
	private String endDate;
	private String articleId;

	public ReleaseAdvisorFilterCriteria(Map<String, String> requestParams) {
		this.uuid = requestParams.get("uuid");
		this.category = requestParams.get("category");
		this.title = requestParams.get("title");
		this.subtitle = requestParams.get("subtitle");
		this.published = requestParams.get("published");
		this.startDate = requestParams.get("start_date");
		this.endDate = requestParams.get("end_date");
		this.articleId = requestParams.get("articleId");
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getPublished() {
		return published;
	}

	public void setPublished(String published) {
		this.published = published;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getArticleId() {
		return articleId;
	}

	public void setArticleId(String articleId) {
		this.articleId = articleId;
	}

}
