package com.qualitytaskforce.insightportal.util;

public class SefURLToString {
	
	public static String sefUrlToString(String sefUrl){
		
		String[]words = sefUrl.split("-");
		
		String categoryUpCase = "";
		
		for (int i = 0; i < words.length; i++) {
			
			if (words[i].equals("os")) {
				words[i] = words[i].toUpperCase();
			} else {
				words[i] = words[i].substring(0, 1).toUpperCase() + words[i].substring(1);
			}
			
			if (i == words.length - 1) {
				categoryUpCase = categoryUpCase + words[i];
			} else {
				categoryUpCase = categoryUpCase + words[i] + " ";
			}
		}
		
		return categoryUpCase;	
		
	}

}
