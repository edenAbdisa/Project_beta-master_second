package com.qualitytaskforce.insightportal.service.backoffice;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.SaveEntityException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ArticleUpdate;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.ImpactRating;
import com.qualitytaskforce.insightportal.model.RelatedArticles;
import com.qualitytaskforce.insightportal.model.TestRecommendation;
import com.qualitytaskforce.insightportal.model.put.ArticleCombinedRequestUpdate;
import com.qualitytaskforce.insightportal.model.put.JsonArticleUpdate;
import com.qualitytaskforce.insightportal.model.put.JsonReleaseAdvisorPut;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.repository.SefURLRepository;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.ArticleUpdateService;
import com.qualitytaskforce.insightportal.service.BrowserRichCardService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.service.ImpactRatingService;
import com.qualitytaskforce.insightportal.service.MobileDeviceRichCardService;
import com.qualitytaskforce.insightportal.service.RelatedArticlesService;
import com.qualitytaskforce.insightportal.service.ReleaseAdvisorService;
import com.qualitytaskforce.insightportal.service.SefURLService;
import com.qualitytaskforce.insightportal.service.SubcategoryService;
import com.qualitytaskforce.insightportal.service.TestRecommendationService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.util.ReadTimeMin;

@Service
public class ArticleServicePut {

	@Autowired
	ArticleRepository articleRepository;

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	SubcategoryService subcategoryService;
	
	@Autowired
	SefURLService sefURLService;
	
	@Autowired
	ReleaseAdvisorService releaseAdvisorService;
	
	@Autowired
	BrowserRichCardService browserService;
	
	@Autowired
	MobileDeviceRichCardService mobileDeviceService;
	
	@Autowired
	TestRecommendationService testRecommendationService;
	
	@Autowired
	ImpactRatingService impactRatingService;
	
	@Autowired
	UserService userService;
	
	@Autowired
	RelatedArticlesService relatedArticleService;
	
	@Autowired
	ArticleService articleService;
	
	@Autowired
	ArticleUpdateService articleUpdateService;

	@Autowired
	SefURLRepository sefURLRepository;
	
	@Autowired
	GetRichcardIdUtil rcUtil;

	@PersistenceContext
	private EntityManager entityManager;
	
	
	@Transactional
	public void backofficePut (ArticleCombinedRequestUpdate acRequest) throws DataNotFoundException, SaveEntityException {
		// ArticleCombinedRequestUpdate acRequest = articleCombinedRequest;
		
    	Article updatedArticle = articleService.findByUUID(acRequest.getUuid());
    	if (updatedArticle == null) {
    		throw new DataNotFoundException("Article with selected uuid not found.");
    	}
    	
    	updatedArticle.setTitle(acRequest.getTitle());
    	
    	updatedArticle.setSummaryText(acRequest.getSummaryText());
    	
    	// Void
    	setRichCard(updatedArticle, acRequest);
    	
    	updatedArticle.setRichcardType(acRequest.getRichcardType());
    	updatedArticle.setFullText(acRequest.getFullText());
    	updatedArticle.setMetaKeywords(acRequest.getMetaKeywords());

    	// Void
    	setTestRecommendation(updatedArticle, acRequest);
    	
    	
    	ImpactRating impactRating = impactRatingService.findByName(acRequest.getImpactRatingName());
    	updatedArticle.setImpactRating(impactRating);
    	
    	Category category = categoryService.findByName(acRequest.getCategoryName());
    	updatedArticle.setCategory(category);
    	
    	// Void
    	setSubcategory(updatedArticle, acRequest);
    	
    	updatedArticle.setImgLink(acRequest.getArtworkUrl());
    	boolean isPublished = acRequest.isPublished();
    	updatedArticle.setPublished(isPublished);
    	if (updatedArticle.getPublishDate() == null && isPublished) {
    		updatedArticle.setPublishDate(new Date());
    		updatedArticle.setUpdatedAt(new Date());
    	}
    	
    	
    	
    	ReadTimeMin timeMin = new ReadTimeMin();
    	int min = timeMin.readTime(acRequest.getFullText());
    	updatedArticle.setReadTime(min);
    	
    	// Void
    	setArticleUpdateIfExist(updatedArticle, acRequest);
    	
    	
    	
		List<RelatedArticles> relatedArticles = relatedArticleService.findByArticle(updatedArticle);
		relatedArticleService.deleteRelatedArticlesList(relatedArticles);
	
	
		
    	for (String title : acRequest.getRelatedArticles()) {
        	
            RelatedArticles relatedArticle = new RelatedArticles();
            relatedArticle.setArticleByOriginalArticleId(updatedArticle);
            Article related = articleService.findByTitle(title);
            relatedArticle.setArticleByRelatedArticle(related);
            relatedArticleService.save(relatedArticle);
        }
	
		if (acRequest.getReleaseAdvisors().size() > 0) {
    		JsonReleaseAdvisorPut jsonRA = acRequest.getReleaseAdvisors().iterator().next();
    		
    		if (jsonRA.getUuid() != null)
    			releaseAdvisorService.updateWhenUpdateArticle(jsonRA);
    		else
    			releaseAdvisorService.createWhenUpdateArticle(jsonRA, updatedArticle);    		
    	}
		
		
		if (acRequest.isChangeUpdatedAt()) {
			updatedArticle.setUpdatedAt(new Date());
			updatedArticle.setPublishDate(new Date());
		}
			
		articleService.save(updatedArticle);
    				
    	
	}
	
	
	private void setSubcategory(Article updatedArticle, ArticleCombinedRequestUpdate acRequest) {
		if (acRequest.getSubcategoryName() != null) {
    		updatedArticle.setSubcategory(acRequest.getSubcategoryName());
    	} else {
			updatedArticle.setSubcategory(null);
		}
	}
	
	private void setRichCard(Article updatedArticle, ArticleCombinedRequestUpdate acRequest) {
		if (acRequest.getRichcardBrand() != null && acRequest.getRichcardModel() != null) {
    		UUID richcardId = rcUtil.getRichcardId(acRequest.getRichcardType(), acRequest.getRichcardBrand(), acRequest.getRichcardModel());
    		updatedArticle.setRichcardId(richcardId);
    	} else {
    		updatedArticle.setRichcardId(null);
    	}
	}
	
	/*
	 * Test recommendation
	 **/
	private void setTestRecommendation(Article updatedArticle, ArticleCombinedRequestUpdate acRequest) {
		TestRecommendation testRecommendation = 
    					testRecommendationService.findByUuid(acRequest.getTestRecommendationId());
		
    	if (testRecommendation == null) {
    		if (acRequest.getTestRecommendation() != null ) {
    		  	if (acRequest.getTestRecommendation().length() > 0 ) {
					testRecommendation = saveIfNotExist(testRecommendation, acRequest);
			  	}
    	 	}  		
    	} else {    		
    		testRecommendation = updateIfExist(testRecommendation, acRequest);    		
    	}
    	
    	updatedArticle.setTestRecommendation(testRecommendation);
	}
	
	private TestRecommendation saveIfNotExist (TestRecommendation testRecommendation, ArticleCombinedRequestUpdate acRequest ) {
		 testRecommendation = new TestRecommendation();
	     testRecommendation.setContent(acRequest.getTestRecommendation());
	     // Mock user
	     // testRecommendation.setUser(user);
	     testRecommendationService.save(testRecommendation);
	     return testRecommendation;
	}
	
	private TestRecommendation updateIfExist (TestRecommendation testRecommendation, ArticleCombinedRequestUpdate acRequest ) {
		
		if (acRequest.getTestRecommendation() != null) {
			 if ( acRequest.getTestRecommendation().length() > 0 ) {  		
				testRecommendation.setContent(acRequest.getTestRecommendation());
				testRecommendationService.save(testRecommendation);
			 } else {
				 testRecommendationService.delete(testRecommendation);
				 return null;
			 }
		}
		
		return testRecommendation;
	}
	 
	 /*
	  * Article update
	  **/
	private boolean isLastHasUuid (int size, ArticleCombinedRequestUpdate acRequest) {
			return (acRequest.getArticleUpdates().get(size - 1).getUuid() != null);
	}
	 
	private User getContextUser () {
		 Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	     String email = auth.getName(); // in unknown way return email
	     User contextuser = userService.findByEmail(email).get(0);
	     return contextuser;
	 }
		 
	private boolean isContextUserEqulsFrontendUser (String contextUser, String frontendUser) {
		return contextUser.equals(frontendUser);
	 }
	 
	private boolean isEqualsContent(ArticleUpdate update, JsonArticleUpdate jsonupdate) {
		return update.getContent().equals(jsonupdate.getUpdateContent());
	}
	 
	private boolean isCheckinUserStrEmpty (JsonArticleUpdate jsonupdate) {
		return jsonupdate.getUpdateContent().trim().length() < 1;
	}
	  
	private boolean isCheckinUserNull (ArticleUpdate update) {
		return update.getUserByCheckInBy() == null;
	}
	 
	private boolean isEqualsCheckinUser(ArticleUpdate update, JsonArticleUpdate jsonupdate) {
		if (isCheckinUserNull(update)) {
			return false;
		} else {
			return update.getUserByCheckInBy().getName().equals(jsonupdate.getUpdateCheckBy());
		}
	}
	 
	private void updateArticleUpdate (JsonArticleUpdate jsonupdate, User contextuser, Article updatedArticle) {
		ArticleUpdate au = articleUpdateService.findByUuid(jsonupdate.getUuid());
		boolean isEqualsContent = isEqualsContent(au, jsonupdate);
		boolean isEqualsCheckinUser = isEqualsCheckinUser(au, jsonupdate);
		if (!isEqualsContent || !isEqualsCheckinUser) {
			if (!isEqualsContent) {
				au.setContent(jsonupdate.getUpdateContent());
				au.setUpdatedAt(new Date());
			}
			if (!isEqualsCheckinUser) {
				String userNameSurname = jsonupdate.getUpdateCheckBy();
				if (isContextUserEqulsFrontendUser(contextuser.getNameAndSurname(), userNameSurname)){
					User checkinUser = contextuser;
					au.setUserByCheckInBy(checkinUser);
				} else {
					au.setUserByCheckInBy(null);
				}
				
			}
			
			if (isCheckinUserStrEmpty(jsonupdate)) {
				articleUpdateService.delete(au);
			} else {
				au.setUserByUpdatedBy(contextuser);
				articleUpdateService.save(au);
			}
			
		}
	 }
	 
	private void updateAll (boolean exceptLast, int lastIndex, Article updatedArticle, List<JsonArticleUpdate> jsonupdates, User contextuser) {
			
		if (exceptLast) {
			for (JsonArticleUpdate jsonupdate : jsonupdates) {
				if (!jsonupdates.get(lastIndex).equals(jsonupdate) == exceptLast) {
					updateArticleUpdate(jsonupdate, contextuser, updatedArticle);
				}
			}
		} else {
			for (JsonArticleUpdate jsonupdate : jsonupdates) {
				updateArticleUpdate(jsonupdate, contextuser, updatedArticle);	
			}
		}
		
		// check if deleted all updates - return back updateAt date to publishedAt
		List<ArticleUpdate> articleUpdateList = articleUpdateService.findAllByArticle(updatedArticle);
		if (articleUpdateList.isEmpty()) {
			updatedArticle.setUpdatedAt(updatedArticle.getPublishDate());
		}
	 }
	 	 
	 
	private void createArticleUpdate (int lastindex, Article updatedArticle, ArticleCombinedRequestUpdate acRequest, User contextuser) {
		ArticleUpdate articleUpdate = new ArticleUpdate();	
 		articleUpdate.setArticle(updatedArticle);
 		String content = acRequest.getArticleUpdates().get(lastindex).getUpdateContent();
 		articleUpdate.setContent(content);
 		
 		int mockReadTime = 3;
 		articleUpdate.setReadTime(mockReadTime);
 		 		
 		User createByUser = contextuser;
 		User updateByUser = contextuser;
 		User checkinByUser = null;
 		
 		articleUpdate.setCreatedAt(new Date());
 		articleUpdate.setUpdatedAt(new Date()); 		
 		
 		articleUpdate.setUserByCheckInBy(checkinByUser); // will set null if not selected checkinUser
 		articleUpdate.setUserByCreatedBy(createByUser);
 		articleUpdate.setUserByUpdatedBy(updateByUser);
 		articleUpdateService.save(articleUpdate);
 		
 		// Update Article updatedAt time
 		updatedArticle.setUpdatedAt(new Date());
	 }
	
	private void setArticleUpdateIfExist(Article updatedArticle, ArticleCombinedRequestUpdate acRequest) {
		 	List<JsonArticleUpdate> jsonupdates = acRequest.getArticleUpdates();	    	
		 	if (jsonupdates.size() > 0) {
		 		User contextuser = getContextUser();
			 	int size = jsonupdates.size();	    	
		    	int lastIndex = size - 1;
		    	
				boolean exceptLast = !isLastHasUuid(size, acRequest);
				
				if (exceptLast) {
					createArticleUpdate(lastIndex, updatedArticle, acRequest, contextuser);
				}
				updateAll(exceptLast, lastIndex, updatedArticle, jsonupdates, contextuser);    	
		 	}
	}
}
