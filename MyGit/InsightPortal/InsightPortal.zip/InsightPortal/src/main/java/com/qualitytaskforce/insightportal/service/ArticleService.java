package com.qualitytaskforce.insightportal.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.SefURL;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.repository.SefURLRepository;
import com.qualitytaskforce.insightportal.service.users.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ArticleService {

	private static Logger LOGGER = LoggerFactory.getLogger(ArticleService.class);

	@Autowired
	ArticleRepository articleRepository;

	@Autowired
	CategoryService categoryService;

	@Autowired
	SubcategoryService subcategoryService;

	@Autowired
	SefURLService sefURLService;

	@Autowired
	ReleaseAdvisorService releaseAdvisorService;

	@Autowired
	BrowserRichCardService browserService;

	@Autowired
	MobileDeviceRichCardService mobileDeviceService;

	@Autowired
	TestRecommendationService testRecommendationService;

	@Autowired
	ImpactRatingService impactRatingService;

	@Autowired
	UserService userService;

	@Autowired
	RelatedArticlesService relatedArticleService;

	@Autowired
	ArticleUpdateService articleUpdateService;

	@Autowired
	SefURLRepository sefURLRepository;

	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * Find possible related articles. If none can be found, gets the newest articles from the same
	 * category
	 * 
	 * @param category name of the category to search
	 * @param uuid     uuid of the original article to ignore
	 * @throws DataNotFoundException
	 */
	public List<Article> findPublishedArticlesByCategoryAndDate(String category, UUID uuid)
			throws DataNotFoundException {
		LOGGER.info("Searching for articles by category {}", category);
		Category c = categoryService.findByName(category);
		List<Article> articles = new ArrayList<>();
		final int MINIMUM_RELATED_ARTICLES = 3;
		final int MAX_MONTHS = 3;
		String date = LocalDate.now().minusMonths(MAX_MONTHS).toString();
		if (uuid == null) {
			articles = articleRepository.findPublishedArticlesByCategoryAndDateWithoutUUID(date,
					c.getUuid());
		} else {
			articles = articleRepository.findPublishedArticlesByCategoryAndDate(date, c.getUuid(),
					uuid);
		}

		if (articles.size() < MINIMUM_RELATED_ARTICLES) {
			articles = articleRepository.findNewestPublishedArticlesByCategory(c.getUuid());
			if (articles.size() < MINIMUM_RELATED_ARTICLES) {
				throw new DataNotFoundException("Not enough related articles found.");
			}
		}
		return articles;
	}

	public void save(Article article) {
		articleRepository.save(article);
	}

	/*
	 * public List<Article> searchByTitle(String searchText) { return
	 * articleRepository.searchByTitle(searchText); }
	 */

	public Article findByTitle(String title) {
		return articleRepository.findBytitle(title);
	}

	public List<Article> getAllArticles() {
		return articleRepository.findAll();
	}

	/*
	 * public List<Article> searchsearch(String text, int typeSearchField, boolean typeSymbol,
	 * boolean isSortedByDate, boolean isPaginated, Date dateFrom, Date dateTo, int rangeFrom, int
	 * results ){ return articleRepository.search(text, typeSearchField, typeSymbol, isSortedByDate,
	 * isPaginated, dateFrom, dateTo, rangeFrom, results ); }
	 */

	public List<Article> autocomplWithSQL(String query) {
		return articleRepository.autocomplWithSQL(query);
	}

	public List<Article> searchPaginWithSQL(String query, int from, int to) {
		query = query.replaceAll(" ", "(.*)");
		return articleRepository.searchPaginWithSQL(query, from, to);
	}

	public List<Article> filterSearchWithSQL(String query, Date dateFrom, Date dateTo) {
		return articleRepository.filterSearchWithSQL(query, dateFrom, dateTo);
	}


	public List<Article> getSortedDateAscDesc(String typeOfSorting) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);

		if (typeOfSorting.equals("asc")) {
			criteria.select(root).orderBy(builder.asc(root.get("publishDate")));
		} else if (typeOfSorting.equals("desc")) {
			criteria.select(root).orderBy(builder.desc(root.get("publishDate")));
		}

		List<Article> result = entityManager.createQuery(criteria).getResultList();
		return result;
	}

	public List<Article> getSortedTitleAz() {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);
		criteria.select(root).orderBy(builder.asc(root.get("title")));
		List<Article> result = entityManager.createQuery(criteria).getResultList();
		return result;
	}

	public List<Article> findByDateViewCountAscDesc(Date dateStart, Date dateStop,
			boolean isSortedByDesc) {

		/*
		 * How to use:
		 * 
		 * Date stop = new Date(); LocalDate now = new LocalDate(stop); LocalDate thirty =
		 * now.minusDays( 30 ); Date start = thirty.toDateTimeAtStartOfDay().toDate();
		 * 
		 * List<Article> articles = articleService.findByDateViewCountAscDesc(start, stop, true);
		 */


		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);

		criteria.select(root);

		if (isSortedByDesc) {
			criteria.orderBy(builder.desc(root.get("viewCount")));
		} else {
			criteria.orderBy(builder.asc(root.get("viewCount")));
		}

		Path<Date> dateEntryPath = root.get("updatedAt");
		Predicate predicate = builder.between(dateEntryPath, dateStart, dateStop);

		criteria.where(predicate);

		List<Article> result = entityManager.createQuery(criteria).setFirstResult(0) // offset
				.setMaxResults(5) // limit
				.getResultList();
		return result;

	}

	@Transactional
	public Article findBySefURL(String sefUrlStr) {

		SefURL sefURL = sefURLRepository.findBySefUrl(sefUrlStr);
		Article result = articleRepository.findBySefURL(sefURL);

		return result;
	}

	public List<Article> findBySummaryText(String summaryText) {
		return articleRepository.findBySummaryText(summaryText);
	}

	public Article findByUUID(UUID uuid) {

		return articleRepository.findByUuid(uuid);
	}

	public boolean updateCounter(UUID uuid) {
		Article article = articleRepository.findByUuid(uuid);
		if (article != null) {
			article.setViewCount(article.getViewCount() + 1);
			articleRepository.save(article);
			return true;
		} else {
			return false;
		}
	}

	public boolean publishToggle(UUID uuid, boolean isPublish) {
		Article article = articleRepository.findByUuid(uuid); // here is something wrong
		if (article != null) {
			article.setPublished(isPublish);
			articleRepository.save(article);
			return true;
		} else {
			return false;
		}
	}

	public List<Article> findByCategory(Category category) {
		return articleRepository.findByCategory(category);
	}

	public List<Article> findBetweenDates(Date dateStart, Date dateStop) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();

		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);

		Root<Article> root = criteria.from(Article.class);

		Path<Date> dateEntryPath = root.get("publishDate");

		Predicate predicate = builder.between(dateEntryPath, dateStart, dateStop);

		criteria.select(root).where(predicate);

		List<Article> result = entityManager.createQuery(criteria).getResultList();

		return result;

	}

	public List<Article> findByMultipleCategories(List<String> categoriesStr) {

		Category categoryObj = new Category();

		List<Category> categories = new ArrayList<Category>();

		for (int k = 0; k < categoriesStr.size(); k++) {
			categoryObj = categoryService.findByName(categoriesStr.get(k));
			if (categoryObj != null) {
				categories.add(categoryObj);
			}
		}

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();

		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);

		Root<Article> root = criteria.from(Article.class);

		criteria.select(root);

		Predicate predicate = builder.disjunction();

		Path<Category> category = root.get("category");

		for (int i = 0; i < categories.size(); i++) {
			predicate = builder.or(predicate, builder.equal(category, categories.get(i)));
		}

		criteria.where(predicate);

		List<Article> result = entityManager.createQuery(criteria).getResultList();

		return result;

	}

	public List<Article> filterByDateCategories(Date dateStart, Date dateStop,
			List<String> categoriesStr) {

		Category categoryObj = new Category();
		List<Category> categories = new ArrayList<Category>();

		for (int k = 0; k < categoriesStr.size(); k++) {
			categoryObj = categoryService.findByName(categoriesStr.get(k));
			if (categoryObj != null) {
				categories.add(categoryObj);
			}
		}

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);
		criteria.select(root);

		Predicate filterByCategories = builder.disjunction();
		Path<Category> category = root.get("category");
		Path<Date> dateEntryPath = root.get("updatedAt");
		Predicate filterBetwenDates = builder.between(dateEntryPath, dateStart, dateStop);

		for (int i = 0; i < categories.size(); i++) {
			filterByCategories =
					builder.or(filterByCategories, builder.equal(category, categories.get(i))); // builder.equal(uuid,
																								// subcategory.getUUID())
		}

		criteria.orderBy(builder.desc(root.get("updatedAt")));
		criteria.where(builder.and(filterByCategories, filterBetwenDates));

		List<Article> result = entityManager.createQuery(criteria).getResultList();
		return result;
	}



	// JPA criteria JOIN
	public List<Article> filterByDateSubcategories(Date dateStart, Date dateStop,
			List<String> subcategoriesStr) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);

		criteria.select(root);

		Predicate filterBySubcategories = builder.disjunction();
		Path<String> subcategory = root.get("subcategory");
		Path<Date> dateEntryPath = root.get("updatedAt");
		Path<Boolean> isPublished = root.get("published");


		for (String subcategoryItem : subcategoriesStr) {
			filterBySubcategories =
					builder.or(filterBySubcategories, builder.equal(subcategory, subcategoryItem));
		}

		criteria.orderBy(builder.desc(root.get("updatedAt")));

		Predicate publishedOnly = builder.equal(isPublished, true);
		if (dateStart != null & dateStop != null) {
			Predicate filterBetwenDates = builder.between(dateEntryPath, dateStart, dateStop);
			criteria.where(builder.and(filterBySubcategories, filterBetwenDates, publishedOnly));
		} else {
			criteria.where(builder.and(filterBySubcategories, publishedOnly));
		}

		List<Article> result = entityManager.createQuery(criteria).getResultList();

		return result;
	}



	// EXAMPLE FORMAT:
	// String uuidString = "01c58221-c5bb-3dc4-9b4e-2acb87c59fe2";
	public Article findByUUIDString(String uuidString) {
		UUID uuid = UUID.fromString(uuidString);
		return articleRepository.findByUuid(uuid);
	}


	public List<Article> findByLimit(List<Category> categories, String typeOfSorting, int from,
			int quantity) {

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);
		criteria.select(root);

		if (typeOfSorting.equals("asc")) {
			criteria.orderBy(builder.asc(root.get("updatedAt")));
		} else if (typeOfSorting.equals("desc")) {
			criteria.orderBy(builder.desc(root.get("updatedAt")));
		}

		Path<Boolean> publishedPath = root.get("published");
		Predicate publishedPred = builder.isTrue(publishedPath);

		Path<Category> categoryPath = root.get("category");
		Predicate categoryPred = builder.disjunction();

		for (int i = 0; i < categories.size(); i++) {
			categoryPred = builder.or(categoryPred, builder.equal(categoryPath, categories.get(i)));
		}

		criteria.where(builder.and(publishedPred, categoryPred));

		List<Article> result = entityManager.createQuery(criteria).setFirstResult(from) // offset
				.setMaxResults(quantity) // limit
				.getResultList();
		return result;
	}

	public int findArticlesQuantity() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
		criteria.select(builder.count(criteria.from(Article.class)));
		return (int) (long) entityManager.createQuery(criteria).getSingleResult();
	}

	public boolean deleteArticle(UUID uuid) throws Exception {
		Article article = articleRepository.findByUuid(uuid); // here is something wrong
		if (article != null) {
			SefURL sefURL = article.getSefURL();
			if (sefURL == null) {
				throw new Exception("Sef url of article not found");
			}
			if (article.getReleaseAdvisors().size() > 0) {
				releaseAdvisorService
						.deleteBatch(article.getReleaseAdvisors().iterator().next().getUuid());
			}
			if (article.getArticleUpdates().size() > 0) {
				articleUpdateService
						.deleteBatch(article.getArticleUpdates().iterator().next().getUuid());
			}
			articleRepository.delete(uuid);
			sefURLService.delete(sefURL);
			return true;
		} else {
			return false;
		}
	}

	public boolean resetCount(UUID uuid) {
		Article article = articleRepository.findByUuid(uuid); // here is something wrong
		if (article != null) {
			article.setViewCount(0);
			articleRepository.save(article);
			return true;
		} else {
			return false;
		}
	}

	public boolean featureToggle(UUID uuid, boolean featured) {
		Article article = articleRepository.findByUuid(uuid); // here is something wrong
		if (article != null) {
			article.setFeatured(featured);
			articleRepository.save(article);
			return true;
		} else {
			return false;
		}
	}

	public int featureCount() {
		return articleRepository.countAllByFeaturedIsTrue();
	}

	public boolean isPublish(UUID uuid) {
		Article article = articleRepository.findByUuid(uuid);
		return article.getPublished() == true;
	}


	public List<Article> findFeaturedArticles() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Article> criteria = builder.createQuery(Article.class);
		Root<Article> root = criteria.from(Article.class);
		criteria.select(root);

		Path<Boolean> featured = root.get("featured");
		Predicate featuredpred = builder.isTrue(featured);
		criteria.where(featuredpred);

		List<Article> result = entityManager.createQuery(criteria).getResultList();
		return result;
	}

}
