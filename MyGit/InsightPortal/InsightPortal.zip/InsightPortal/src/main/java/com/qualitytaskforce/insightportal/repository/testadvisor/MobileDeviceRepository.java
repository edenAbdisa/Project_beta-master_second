package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.MobileDevice;

public interface MobileDeviceRepository extends JpaRepository<MobileDevice, Long> {

	@Query(value = "SELECT ta_ms_mobile_devices.uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, "
				+ "ta_oss.name AS os_name, ta_devices.type AS device_type, ta_oss.version AS os_version, marketpenetration AS marketpen "
				+ "FROM ta_ms_mobile_devices "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_mobile_devices.osuuid "
				+ "INNER JOIN ta_devices ON ta_devices.uuid = ta_ms_mobile_devices.deviceuuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_mobile_devices.countryuuid "
				+ "WHERE ta_countries.code = :code "
				+ "AND ta_ms_mobile_devices.date = :date "
				+ "ORDER BY marketpen DESC"
				, nativeQuery = true)
	List<MobileDevice> mobileDevices(@Param("code") String code, @Param("date") String date);

	@Query(value = "SELECT * FROM ( "
				+ "SELECT uuid_v4() AS uuid, ta_devices.brand AS device_brand, ta_devices.model AS device_model, "
				+ "ta_oss.name AS os_name, ta_devices.type AS device_type, ta_oss.version AS os_version, "
				+ "(SUM(IFNULL(ta_ms_mobile_devices.marketpenetration * ta_countries.desktop_users, 0)) / SUM(ta_countries.desktop_users)) AS marketpen "
				+ "FROM ta_ms_mobile_devices "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_mobile_devices.osuuid "
				+ "INNER JOIN ta_devices ON ta_devices.uuid = ta_ms_mobile_devices.deviceuuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_mobile_devices.countryuuid "
				+ "WHERE ta_countries.uuid IN :countries "
				+ "AND ta_ms_mobile_devices.date = :date "
				+ "AND ta_devices.type IN :types "
				+ "GROUP BY device_brand, device_model, device_type, os_name, os_version "
				+ "ORDER BY marketpen DESC "
				+ ") t WHERE marketpen > :threshold"
				, nativeQuery = true)
	List<MobileDevice> mobileDevicesMultiple(@Param("countries") List<UUID> countries, @Param("date") String date, @Param("threshold") float threshold, @Param("types") List<String> types);
}