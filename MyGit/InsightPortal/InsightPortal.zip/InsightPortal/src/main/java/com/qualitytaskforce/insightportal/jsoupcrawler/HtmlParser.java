package com.qualitytaskforce.insightportal.jsoupcrawler;

import java.io.IOException;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.repository.DetailModelRepository;

@Service
public class HtmlParser {
	
	@Autowired
	DetailModelRepository detailModelRepository;
	
//	public static void main(String[] args) throws IOException, InterruptedException {
//		 getMakers();
//		 getDevices();
//		 getDetails();
//	}

	public void getMakers() throws IOException, InterruptedException {

		Document doc = Jsoup.connect("http://www.gsmarena.com/makers.php3").timeout(90000).get();
		Elements makers = doc.select("div[class=st-text]");
		Node makerNameNode;
		String makerName;
		String makerAddress;
//		System.out.println("There is " + makers.select("td").size() + " phone makers at the moment.\n");
		
//		for (Element a:makers.select("td")){
//			makerNameNode = a.select("a").first().childNodes().get(0);
//			makerName = makerNameNode.toString();
//			makerAddress = a.select("a").get(0).absUrl("href");
//			getDevices(makerAddress);
//			//System.out.println(makerName + " : " + makerAddress);
//		}
		
		for (int o = 108; o < 109; o++){ // 108. ZTE ( Max )
			Element a = makers.select("td").get(o);
			makerNameNode = a.select("a").first().childNodes().get(0);
			makerName = makerNameNode.toString();
			makerAddress = a.select("a").get(0).absUrl("href");
//			System.out.println(i + ". " + makerName + " : " + makerAddress);
			getDevices(makerAddress, makerName, o);
		}
	}

	public void getDevices(String makerAddress, String makerName, int o) throws IOException, InterruptedException {
		
		Document docum = Jsoup.connect(makerAddress).timeout(90000).get();
		Elements devices = docum.select("div[class=makers]").select("ul");
		String deviceName;
		String deviceAddress;
		
		for (int i = 0; i < devices.select("li").size(); i++) {
			deviceAddress = devices.select("a").get(i).absUrl("href");
			deviceName = devices.select("li").get(i).text();
//			System.out.println(deviceName + " : " + deviceAddress);
			getDetails(deviceAddress, makerName, deviceName, i, o);
		}
		
		Elements moreDevices = docum.select("div[class=nav-pages]").select("a");
		for (Element a:moreDevices) {
			makerAddress = a.select("a").get(0).absUrl("href");
			Document restDocum = Jsoup.connect(makerAddress).timeout(6000).get();
			Elements restDevices = restDocum.select("div[class=makers]").select("ul");

			for (int i = 0; i < restDevices.select("li").size(); i++) {
				deviceAddress = restDevices.select("a").get(i).absUrl("href");
				deviceName = restDevices.select("li").get(i).text();
//				System.out.println(deviceName + " : " + deviceAddress);
				getDetails(deviceAddress, makerName, deviceName, i, o);
			}
		}
	}
		
	public void getDetails(String deviceAddress, String makerName, String deviceName, int i, int o) throws IOException, InterruptedException {

		
		Thread.sleep(500);
		
		
	    Document document = Jsoup.connect(deviceAddress).timeout(90000).get();
        Elements elementary = document.select("ul[class=specs-spotlight-features]").select("li");

        DetailModel detailModel = new DetailModel();
        String brand = makerName;
        String model = deviceName;
	
		String imgLink = document.select("div[class=specs-photo-main]").select("img").attr("abs:src");
		String GENERALstatus = elementary.select("span[data-spec=released-hl]").text();
		String GENERALos = elementary.select("span[data-spec=os-hl]").text();
		String GENERALsize = elementary.select("span[data-spec=displaysize-hl]").text();
		String GENERALresolution = elementary.select("div[data-spec=displayres-hl]").text();
		String GENERALram = elementary.select("strong[class=accent accent-expansion]").text();
		String GENERALchipset = elementary.select("div[data-spec=chipset-hl]").text();
		String GENERALbattery = elementary.select("li[class=help accented help-battery]").text();
		String otherBodyFeatures = document.select("tr").select("td[data-spec=bodyother]").text();
		String otherDisplayFeatures = document.select("tr").select("td[data-spec=displayother]").text();
		String otherSoundFeatures = document.select("tr").select("td[data-spec=optionalother]").text();
		String otherFeatures = document.select("tr").select("td[data-spec=featuresother]").text();
		String batteryDetails = document.select("tr").select("td[data-spec=batdescription1]").text();
		
		detailModel.setBrand(brand);
		detailModel.setModel(model);
		detailModel.setImgLink(imgLink);
		detailModel.setGENERALstatus(GENERALstatus);
		detailModel.setGENERALos(GENERALos);
		detailModel.setGENERALsize(GENERALsize);
		detailModel.setGENERALresolution(GENERALresolution);
		detailModel.setGENERALram(GENERALram);
		detailModel.setGENERALchipset(GENERALchipset);
		detailModel.setGENERALbattery(GENERALbattery);
		detailModel.setBatteryDetails(batteryDetails);
		if (otherBodyFeatures.length() < 1) { 
			detailModel.setOtherBodyFeatures(null); 
		} else { 
			detailModel.setOtherBodyFeatures(otherBodyFeatures); 
		}
		if (otherDisplayFeatures.length() < 1) { 
			detailModel.setOtherDisplayFeatures(null); 
		} else { 
			detailModel.setOtherDisplayFeatures(otherDisplayFeatures); 
		}
		if (otherSoundFeatures.length() < 1) { 
			detailModel.setOtherSoundFeatures(null); 
		} else { 
			detailModel.setOtherSoundFeatures(otherSoundFeatures); 
		}
		if (otherFeatures.length() < 1) { 
			detailModel.setOtherFeatures(null); 
		} else { 
			detailModel.setOtherFeatures(otherFeatures); 
		}
		
		System.out.println("[" + o + "]  " + i + ". " + brand + " " + model + ": " + GENERALos + " " + GENERALram + " " + GENERALchipset);
		
		Elements details = document.select("div[id=specs-list]").select("table");
//		System.out.println("Number of 'table' elements in html id='specs-list': " + details.size() + "\n ");
//		for (Element table:details) {
//			for (Element tr:table.select("tr")) {
//				System.out.println(tr.select("td[class=ttl]").text() + " : " + tr.select("td[class=nfo]").text());
//			}
//		}
		
		for (Element table:details) {
			for (Element tr:table.select("tr")) {
				switch (tr.select("td[class=ttl]").text()){
					case "Technology":
						detailModel.setNETWORK_Technology(tr.select("td[class=nfo]").text());
						break;
					case "2G bands":
						detailModel.setNETWORK_2GBands(tr.select("td[class=nfo]").text());
						break;
					case "3G bands":
						detailModel.setNETWORK_3GBands(tr.select("td[class=nfo]").text());
						break;
					case "4G bands":
						detailModel.setNETWORK_4GBands(tr.select("td[class=nfo]").text());
						break;
					case "Speed":
						detailModel.setNETWORK_Speed(tr.select("td[class=nfo]").text());
						break;
					case "GPRS":
						detailModel.setNETWORK_GPRS(tr.select("td[class=nfo]").text());
						break;
					case "EDGE":
						detailModel.setNETWORK_EDGE(tr.select("td[class=nfo]").text());
						break;
					case "Announced":
						detailModel.setLAUNCH_Announced(tr.select("td[class=nfo]").text());
						break;
					case "Status":
						detailModel.setLAUNCH_Status(tr.select("td[class=nfo]").text());
						break;
					case "Dimensions":
						detailModel.setBODY_Dimensions(tr.select("td[class=nfo]").text());
						break;
					case "Weight":
						detailModel.setBODY_Weight(tr.select("td[class=nfo]").text());
						break;
					case "Build":
						detailModel.setBODY_Build(tr.select("td[class=nfo]").text());
						break;		 				
					case "SIM":
						detailModel.setBODY_SIM(tr.select("td[class=nfo]").text());
						break;
					case "Type":
						detailModel.setDISPLAY_Type(tr.select("td[class=nfo]").text());
						break;
					case "Size":
						detailModel.setDISPLAY_Size(tr.select("td[class=nfo]").text());
						break;
					case "Resolution":
						detailModel.setDISPLAY_Resolution(tr.select("td[class=nfo]").text());
						break;
					case "Multitouch":
						detailModel.setDISPLAY_Multitouch(tr.select("td[class=nfo]").text());
						break;
					case "Protection":
						detailModel.setDISPLAY_Protection(tr.select("td[class=nfo]").text());
						break;
					case "OS":
						detailModel.setPLATFORM_OS(tr.select("td[class=nfo]").text());
						break;
					case "Chipset":
						detailModel.setPLATFORM_Chipset(tr.select("td[class=nfo]").text());
						break;
					case "CPU":
						detailModel.setPLATFORM_CPU(tr.select("td[class=nfo]").text());
						break;
					case "GPU":
						detailModel.setPLATFORM_GPU(tr.select("td[class=nfo]").text());
						break;
					case "Card slot":
						detailModel.setMEMORY_CardSlot(tr.select("td[class=nfo]").text());
						break;
					case "Internal":
						detailModel.setMEMORY_Internal(tr.select("td[class=nfo]").text());
						break;
					case "Primary":
						detailModel.setCAMERA_Primary(tr.select("td[class=nfo]").text());
						break;
					case "Features":
						detailModel.setCAMERA_Features(tr.select("td[class=nfo]").text());
						break;
					case "Video":
						detailModel.setCAMERA_Video(tr.select("td[class=nfo]").text());
						break;
					case "Secondary":
						detailModel.setCAMERA_Secondary(tr.select("td[class=nfo]").text());
						break;
					case "Alert types":
						detailModel.setSOUND_AlertTypes(tr.select("td[class=nfo]").text());
						break;
					case "Loudspeaker":
						detailModel.setSOUND_Loudspeaker(tr.select("td[class=nfo]").text());
						break;
					case "3.5mm jack":
						detailModel.setSOUND_35mmjack(tr.select("td[class=nfo]").text());
						break;
					case "WLAN":
						detailModel.setCOMMS_WLAN(tr.select("td[class=nfo]").text());
						break;
					case "Bluetooth":
						detailModel.setCOMMS_Bluetooth(tr.select("td[class=nfo]").text());
						break;
					case "GPS":
						detailModel.setCOMMS_GPS(tr.select("td[class=nfo]").text());
						break;
					case "NFC":
						detailModel.setCOMMS_NFC(tr.select("td[class=nfo]").text());
						break;
					case "Infrared port":
						detailModel.setCOMMS_InfraredPort(tr.select("td[class=nfo]").text());
						break;
					case "Radio":
						detailModel.setCOMMS_Radio(tr.select("td[class=nfo]").text());
						break;
					case "USB":
						detailModel.setCOMMS_USB(tr.select("td[class=nfo]").text());
						break;
					case "Sensors":
						detailModel.setFEATURES_Sensors(tr.select("td[class=nfo]").text());
						break;
					case "Messaging":
						detailModel.setFEATURES_Messaging(tr.select("td[class=nfo]").text());
						break;
					case "Browser":
						detailModel.setFEATURES_Browser(tr.select("td[class=nfo]").text());
						break;
					case "Stand-by":
						detailModel.setBATTERY_StandBy(tr.select("td[class=nfo]").text());
						break;
					case "Talk time":
						detailModel.setBATTERY_TalkTime(tr.select("td[class=nfo]").text());
						break;
					case "Music play":
						detailModel.setBATTERY_MusicPlay(tr.select("td[class=nfo]").text());
						break;
					case "Colors":
						detailModel.setMISC_Colors(tr.select("td[class=nfo]").text());
						break;
					case "SAR":
						detailModel.setMISC_SAR(tr.select("td[class=nfo]").text());
		 				break;
					case "SAR EU":
		 				detailModel.setMISC_SAR_EU(tr.select("td[class=nfo]").text());
		 				break;
		 			case "Price group":
		 				detailModel.setMISC_PriceGroup(tr.select("td[class=nfo]").text());
		 				break;
		 			case "Performance":
		 				detailModel.setTESTS_Performance(tr.select("td[class=nfo]").text());
		 				break;
		 		}
		 	}
		 }
		detailModelRepository.save(detailModel);
	}
}