package com.qualitytaskforce.insightportal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.model.ImpactRating;
import com.qualitytaskforce.insightportal.repository.ImpactRatingRepository;

@Service
public class ImpactRatingService {

	@Autowired
	ImpactRatingRepository repo;

	public ImpactRating save(ImpactRating impactRating) {
		return repo.save(impactRating);
	}	

	public void delete(ImpactRating impactRating) {
		repo.delete(impactRating);
	}
	
	public ImpactRating findByName(int name){
		return repo.findByName(name);
	}
	
	public List<ImpactRating> findAll(){
		return repo.findAll();
	}
}
