package com.qualitytaskforce.insightportal.util;
import java.util.ArrayList;
import java.util.List;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;

public class PrepareToShowInList {
	
	public static List<ArticleWhenList> prepare(List<Article> articles){
		
		ArticleWhenList article;		
		List<ArticleWhenList> articlesCutted = new ArrayList<ArticleWhenList>();		
		DateToString dateString = new DateToString();
		
		for (int i = 0; i < articles.size(); i++){	
			
			article = new ArticleWhenList();			
			String dateStr = dateString.dateToString(articles.get(i).getUpdatedAt());			
			article.setLastUpdate(dateStr);			
			article.setReadTime(articles.get(i).getReadTime());			
			article.setTitle(articles.get(i).getTitle());			
			article.setSummaryText(articles.get(i).getSummaryText());
			article.setImgLink(articles.get(i).getImgLink());
			article.setSefURL(articles.get(i).getSefURL().getSefUrl());
			article.setCategory(articles.get(i).getCategory().getName());
			article.setPublished(articles.get(i).getPublished());
			articlesCutted.add(article);
		}	
		
		return articlesCutted;		
	}
}