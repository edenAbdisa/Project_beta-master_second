package com.qualitytaskforce.insightportal.model.util;

public enum UserLoggingAction {
    LOGIN("Login"),
    LOGOUT("Logout"),
    FAILED_LOGIN("Failed login"),
    CHANGE_PASSWORD("Change password"),
    FORGOTTEN_PASSWORD("Forgotten password");

    private String value;
    
    /**
     * @return the value
     */
    public String getValue() {
      return value;
    }

    UserLoggingAction(String value) {
        this.value = value;
    }
}
