package com.qualitytaskforce.insightportal.util;

import java.util.UUID;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;

public class VerifyUUID {
	
	
	public static UUID verifyUUID(String uuidString) throws DataNotFoundException, InvalidParameterFormatException, NumberFormatException{
		
		UUID uuid = null;
		try{
			uuid = UUID.fromString(uuidString);
			return uuid;
		
		}catch(IllegalArgumentException illArgEx){
			throw new InvalidParameterFormatException("UUID is invalid");
		}
		
	}	

}
