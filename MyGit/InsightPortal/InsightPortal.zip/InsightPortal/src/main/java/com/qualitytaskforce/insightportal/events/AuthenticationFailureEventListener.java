package com.qualitytaskforce.insightportal.events;

import com.qualitytaskforce.insightportal.model.util.UserLoggingAction;
import com.qualitytaskforce.insightportal.service.LoginAttemptService;
import com.qualitytaskforce.insightportal.service.users.UserDetailsServiceImpl;
import com.qualitytaskforce.insightportal.service.users.UserLoggingService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.stereotype.Component;

@Component
public class AuthenticationFailureEventListener
        implements ApplicationListener<AuthenticationFailureBadCredentialsEvent> {

    @Autowired
    private LoginAttemptService loginAttemptService;

    @Autowired
    private UserDetailsServiceImpl userDetailsService;

    @Autowired
    private UserLoggingService userLoggingService;

    public void onApplicationEvent(AuthenticationFailureBadCredentialsEvent e) {
        String ip = userDetailsService.getClientIP();
        loginAttemptService.loginFailed(ip);
        String email = e.getAuthentication().getName();

        userLoggingService.saveUserLog(email, ip, UserLoggingAction.FAILED_LOGIN);
    }
}