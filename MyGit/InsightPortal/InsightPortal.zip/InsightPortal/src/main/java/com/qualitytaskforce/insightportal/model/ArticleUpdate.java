package com.qualitytaskforce.insightportal.model;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.qualitytaskforce.insightportal.model.users.User;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "article_updates")
public class ArticleUpdate implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "content", nullable = false, length = 16777215)
	private String content;
	
	@Column(name = "read_time", nullable = false)
	private int readTime;	

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "article_id", nullable = false)
	public Article articles;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "created_by", nullable = false)
	private User userByCreatedBy;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "updated_by", nullable = false)
	private User userByUpdatedBy;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false, length = 19)
	private Date createdAt;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = false, length = 19)
	private Date updatedAt;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "check_in_by")
	private User userByCheckInBy;
	
	public ArticleUpdate() {
	}

	public ArticleUpdate(UUID uuid, Article articles, User userByCreatedBy, User userByUpdatedBy, User userByCheckInBy, String content,
			int readTime, Date createdAt, Date updatedAt) {
		this.uuid = uuid;
		this.articles = articles;
		this.userByCreatedBy = userByCreatedBy;
		this.userByUpdatedBy = userByUpdatedBy;
		this.userByCheckInBy = userByCheckInBy;
		this.content = content;
		this.readTime = readTime;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;		
	}
	
	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
	public String getContent() {
		return this.content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	public int getReadTime() {
		return readTime;
	}

	public void setReadTime(int readTime) {
		this.readTime = readTime;
	}
	
	public Article getArticle() {
		return this.articles;
	}

	public void setArticle(Article articles) {
		this.articles = articles;
	}

	public User getUserByCreatedBy() {
		return this.userByCreatedBy;
	}

	public void setUserByCreatedBy(User userByCreatedBy) {
		this.userByCreatedBy = userByCreatedBy;
	}

	public User getUserByUpdatedBy() {
		return this.userByUpdatedBy;
	}

	public void setUserByUpdatedBy(User userByUpdatedBy) {
		this.userByUpdatedBy = userByUpdatedBy;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}	
	
	public User getUserByCheckInBy() {
		return this.userByCheckInBy;
	}

	public void setUserByCheckInBy(User userByCheckInBy) {
		this.userByCheckInBy = userByCheckInBy;
	}
}
