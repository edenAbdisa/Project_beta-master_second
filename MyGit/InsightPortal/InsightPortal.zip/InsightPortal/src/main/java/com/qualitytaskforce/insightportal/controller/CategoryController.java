package com.qualitytaskforce.insightportal.controller;
import java.util.List;

import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.service.CategoryService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value = "/category")
public class CategoryController {
    private static Logger LOGGER = LoggerFactory.getLogger(CategoryController.class);

    @Autowired
    private CategoryService categoryService;

    /**
     * Endpoint for retreiving a list all categories
     */
    @GetMapping("/")
    public ResponseEntity<List<Category>> getAllCategory(){
        LOGGER.trace("Getting all categories");
        List<Category> categories = categoryService.getAllCategories();
        LOGGER.trace("Retrieved {} categories", categories.size());
        return new ResponseEntity<List<Category>>(categories, HttpStatus.OK);
    }

}
