package com.qualitytaskforce.insightportal.model.post;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.sql.Date;
import java.util.UUID;

public class JsonReleaseAdvisor {

    @JsonProperty("article_id")
    private UUID articleUuid;
    private String category;
    private String title;
    private String subtitle;
    private boolean published;

    @JsonProperty("start_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date startDate;
    @JsonProperty("end_date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd")
    private Date endDate;

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public UUID getArticleUuid() {
        return articleUuid;
    }

    public void setArticleUuid(UUID articleUuid) {
        this.articleUuid = articleUuid;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public boolean isPublished() {
        return published;
    }

    public void setPublished(boolean published) {
        this.published = published;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    @Override
    public String toString() {
        return "JsonReleaseAdvisor [articleUuid=" + articleUuid + ", category=" + category + ", title=" + title
                + ", subtitle=" + subtitle + ", published=" + published + ", start_date=" + startDate + ", end_date="
                + endDate + "]";
    }
}