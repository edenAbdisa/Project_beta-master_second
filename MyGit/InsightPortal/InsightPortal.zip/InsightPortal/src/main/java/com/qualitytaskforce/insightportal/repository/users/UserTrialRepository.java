package com.qualitytaskforce.insightportal.repository.users;

import java.util.UUID;
import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserTrial;

public interface UserTrialRepository extends JpaRepository<UserTrial, UUID>{
	UserTrial findByUser(User user);
	UserTrial findByConfirmationToken(String token);
}
