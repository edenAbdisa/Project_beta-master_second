package com.qualitytaskforce.insightportal.model.post;

import com.fasterxml.jackson.annotation.JsonProperty;

public class JsonApiLimit {
	
	@JsonProperty("name")
	private String name;

	@JsonProperty("low_hourly")
	private int lowHourly;

	@JsonProperty("low_monthly")
	private int lowMonthly;

	@JsonProperty("med_hourly")
	private int medHourly;

	@JsonProperty("med_monthly")
	private int medMonthly;

	@JsonProperty("high_hourly")
	private int highHourly;

	@JsonProperty("high_monthly")
	private int highMonthly;

	public String getName(){
		return this.name;
	}

	/**
	 * @return the lowHourly
	 */
	public int getLowHourly() {
		return lowHourly;
	}

	/**
	 * @return the lowMonthly
	 */
	public int getLowMonthly() {
		return lowMonthly;
	}

	/**
	 * @return the medHourly
	 */
	public int getMedHourly() {
		return medHourly;
	}

	/**
	 * @return the medMonthly
	 */
	public int getMedMonthly() {
		return medMonthly;
	}

	/**
	 * @return the highHourly
	 */
	public int getHighHourly() {
		return highHourly;
	}

	/**
	 * @return the highMonthly
	 */
	public int getHighMonthly() {
		return highMonthly;
	}

	public boolean checkRequiredNull() {
		if (this.name == null || this.lowHourly == 0 || this.lowMonthly == 0 || this.medHourly == 0 ||
			this.medMonthly == 0 || this.highHourly == 0 || this.highMonthly == 0) {
			return false;
		}
		return true;
	}

}