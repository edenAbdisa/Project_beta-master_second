package com.qualitytaskforce.insightportal.controller.robots;

import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Profile("production")
@RestController
public class ProductionRobots {	
	private HttpHeaders headers = new HttpHeaders();

	/**
	 * Path for serving robots.txt
	 */
	@RequestMapping(value = "/robots.txt", method = RequestMethod.GET)
	public ResponseEntity<?> robots() {
		headers.setContentType(MediaType.TEXT_PLAIN);
		String robots = "User-agent: * \r\n" +
						"Disallow: /testadvisor/ \r\n" +
						"Disallow: /category/ \r\n" +
						"Disallow: /filter/ \r\n" +
						"Disallow: /impact-rating \r\n" +
						"Disallow: /browsers/ \r\n" +
						"Disallow: /devices/ \r\n" +
						"Disallow: /email \r\n" +
						"Disallow: /signin \r\n" +
						"Disallow: /login \r\n" +
						"Disallow: /checkSession \r\n" +
						"Disallow: /user/ \r\n" +
						"Disallow: /search/ \r\n" +
						"Disallow: /article/removelinks \r\n" + 
						"\r\n" + 
						"User-agent: Googlebot \r\n" + 
						"Allow: /testadvisor/deviceranking/ \r\n" + 
						"Allow: /testadvisor/top/ \r\n" + 
						"Allow: /browsers/ \r\n" + 
						"Allow: /devices/ \r\n";
		return new ResponseEntity<String>(robots, headers, HttpStatus.OK);
	}
}