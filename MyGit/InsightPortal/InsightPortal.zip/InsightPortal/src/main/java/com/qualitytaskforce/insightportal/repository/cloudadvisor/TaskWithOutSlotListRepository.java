package com.qualitytaskforce.insightportal.repository.cloudadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Slot;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Task;
import com.qualitytaskforce.insightportal.model.cloudadvisor.TaskWithOutSlotList;

public interface TaskWithOutSlotListRepository extends JpaRepository<TaskWithOutSlotList, UUID> {
	@Query(value = "SELECT * FROM tasks "
			+ "WHERE slot_uuid =:slotUuid "
			, nativeQuery = true)
		List<TaskWithOutSlotList> findBySlot(@Param("slotUuid") UUID slotUuid);
	
}
