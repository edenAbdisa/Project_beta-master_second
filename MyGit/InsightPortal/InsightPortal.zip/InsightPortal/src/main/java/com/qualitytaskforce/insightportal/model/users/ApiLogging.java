package com.qualitytaskforce.insightportal.model.users;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "Api_logging")
public class ApiLogging implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "Api_key_id", nullable = false)
	private ApiKey ApiKey;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "event_time", nullable = false, length = 19)
	private Date eventTime;
	
	@Column(name = "Api_call", nullable = false, length = 500)
	private String ApiCall;
	
	@Column(name = "Api_status", nullable = false)
	private short ApiStatus;
	
	@Column(name = "ip_address", nullable = false)
	private byte[] ipAddress;
	
	@Column(name = "header", length = 300)
	private String header;
	
	@Column(name = "post_data", length = 65535)
	private String postData;
	
	@Column(name = "response", length = 65535)
	private String response;

	public ApiLogging() {
	}

	public ApiLogging(UUID uuid, ApiKey ApiKey, Date eventTime, String ApiCall, short ApiStatus, byte[] ipAddress) {
		this.uuid = uuid;
		this.ApiKey = ApiKey;
		this.eventTime = eventTime;
		this.ApiCall = ApiCall;
		this.ApiStatus = ApiStatus;
		this.ipAddress = ipAddress;
	}

	public ApiLogging(UUID uuid, ApiKey ApiKey, Date eventTime, String ApiCall, short ApiStatus, byte[] ipAddress,
			String header, String postData, String response) {
		this.uuid = uuid;
		this.ApiKey = ApiKey;
		this.eventTime = eventTime;
		this.ApiCall = ApiCall;
		this.ApiStatus = ApiStatus;
		this.ipAddress = ipAddress;
		this.header = header;
		this.postData = postData;
		this.response = response;
	}
	
	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public ApiKey getApiKey() {
		return this.ApiKey;
	}

	public void setApiKey(ApiKey ApiKey) {
		this.ApiKey = ApiKey;
	}

	public Date getEventTime() {
		return this.eventTime;
	}

	public void setEventTime(Date eventTime) {
		this.eventTime = eventTime;
	}

	public String getApiCall() {
		return this.ApiCall;
	}

	public void setApiCall(String ApiCall) {
		this.ApiCall = ApiCall;
	}

	public short getApiStatus() {
		return this.ApiStatus;
	}

	public void setApiStatus(short ApiStatus) {
		this.ApiStatus = ApiStatus;
	}

	public byte[] getIpAddress() {
		return this.ipAddress;
	}

	public void setIpAddress(byte[] ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getHeader() {
		return this.header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getPostData() {
		return this.postData;
	}

	public void setPostData(String postData) {
		this.postData = postData;
	}

	public String getResponse() {
		return this.response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

}