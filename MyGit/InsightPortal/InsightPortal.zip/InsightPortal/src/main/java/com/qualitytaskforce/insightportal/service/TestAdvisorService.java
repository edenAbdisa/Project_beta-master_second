package com.qualitytaskforce.insightportal.service;

import java.util.List;
import java.util.UUID;

import com.qualitytaskforce.insightportal.model.testadvisor.Browser;
import com.qualitytaskforce.insightportal.model.testadvisor.ChartData;
import com.qualitytaskforce.insightportal.model.testadvisor.Country;
import com.qualitytaskforce.insightportal.model.testadvisor.DesktopBrowser;
import com.qualitytaskforce.insightportal.model.testadvisor.Device;
import com.qualitytaskforce.insightportal.model.testadvisor.MobileBrowser;
import com.qualitytaskforce.insightportal.model.testadvisor.MobileDevice;
import com.qualitytaskforce.insightportal.model.testadvisor.OperatingSystem;
import com.qualitytaskforce.insightportal.repository.testadvisor.BrowserRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.ChartRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.CountryRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.DashboardRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.DesktopBrowserRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.MobileBrowserRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.MobileDeviceRepository;
import com.qualitytaskforce.insightportal.repository.testadvisor.OperatingSystemRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TestAdvisorService {

	@Autowired
	BrowserRepository browserRepo;

	@Autowired
	DesktopBrowserRepository desktopRepo;

	@Autowired
	MobileBrowserRepository mobileRepo;

	@Autowired
	MobileDeviceRepository deviceRepo;

	@Autowired
	OperatingSystemRepository osRepo;

	@Autowired
	CountryRepository countryRepo;

	@Autowired
	DashboardRepository dashRepo;

	@Autowired
	ChartRepository chartRepo;

	public long getUserTotal(List<UUID> countries) {
		return dashRepo.getUserTotal(countries);
	}

	public List<Browser> browsers(String code, String date) {
		return browserRepo.browsers(code, date);
	}

	public List<Browser> browsersMultiple(List<UUID> countries, String date, float threshold) {
		return browserRepo.browsersMultiple(countries, date, threshold);
	}

	public List<DesktopBrowser> desktopBrowsers(String code, String date) {
		return desktopRepo.desktopBrowsers(code, date);
	}

	public List<DesktopBrowser> desktopBrowsersMultiple(List<UUID> countries, String date, float threshold) {
		return desktopRepo.desktopBrowsersMultiple(countries, date, threshold);
	}

	public List<MobileBrowser> mobileBrowsers(String code, String date) {
		return mobileRepo.mobileBrowsers(code, date);
	}

	public List<MobileBrowser> mobileBrowsersMultiple(List<UUID> countries, String date, float threshold, List<String> types) {
		return mobileRepo.mobileBrowsersMultiple(countries, date, threshold, types);
	}

	public List<MobileDevice> mobileDevices(String code, String date) {
		return deviceRepo.mobileDevices(code, date);
	}

	public List<MobileDevice> mobileDevicesMultiple(List<UUID> countries, String date, float threshold, List<String> types) {
		return deviceRepo.mobileDevicesMultiple(countries, date, threshold, types);
	}

	public List<OperatingSystem> operatingSystems(String code, String os, String date) {
		return osRepo.operatingSystems(code, os, date);
	}

	public List<OperatingSystem> operatingSystemsMultiple(List<UUID> countries, String os, String startDate, String endDate) {
		return osRepo.operatingSystemsMultiple(countries, os, startDate, endDate);
	}

	public List<Country> getCountries(List<String> codes) {
		return countryRepo.getCountries(codes);
	}

	public List<Country> getCountriesByRegion(List<String> regionCodes) {
		return countryRepo.getCountriesByRegion(regionCodes);
	}

	public List<String> getAllRegions() {
		return countryRepo.getAllRegions();
	}

	public List<Country> getAllCountries() {
		return countryRepo.getAllCountries();
	}

	public List<Device> topDevicesGlobal(List<UUID> countries, String date, int limit, long total) {
		return dashRepo.topDevicesGlobal(countries, date, limit, total);
	}

	public List<Device> topDevicesGlobalNoLimit(List<UUID> countries, String date, long total) {
		return dashRepo.topDevicesGlobalNoLimit(countries, date, total);
	}

	public List<Device> topDevicesCountry(String code, String date, int limit) {
		return dashRepo.topDevicesCountry(code, date, limit);
	}

	public List<ChartData> osBarChartCountry(String code, String date) {
		return chartRepo.osBarChartCountry(code, date);
	}

	public List<ChartData> osBarChartGlobal(List<UUID> countries, String date, long total) {
		return chartRepo.osBarChartGlobal(countries, date, total);
	}

	public List<ChartData> desktopBrowserChartCountry(String code, String date) {
		return chartRepo.desktopBrowserChartCountry(code, date);
	}

	public List<ChartData> desktopBrowserChartGlobal(List<UUID> countries, String date, long total) {
		return chartRepo.desktopBrowserChartGlobal(countries, date, total);
	}
}