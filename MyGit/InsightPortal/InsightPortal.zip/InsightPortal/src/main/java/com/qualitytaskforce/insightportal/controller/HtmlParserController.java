package com.qualitytaskforce.insightportal.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Import;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qualitytaskforce.insightportal.config.WebConfig;
import com.qualitytaskforce.insightportal.jsoupcrawler.HtmlParser;

@RestController
@Import(WebConfig.class)
@RequestMapping(value = "/downloaddevicedata")	
public class HtmlParserController {
	@Autowired
	private HtmlParser htmlParser;
	
	@GetMapping(value = "/")
	public void getDevices() throws IOException, InterruptedException {
		htmlParser.getMakers();
	}
}
