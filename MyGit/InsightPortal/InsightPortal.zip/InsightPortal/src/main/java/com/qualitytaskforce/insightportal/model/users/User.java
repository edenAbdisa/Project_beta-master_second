package com.qualitytaskforce.insightportal.model.users;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ArticleUpdate;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.EmailTemplate;
import com.qualitytaskforce.insightportal.model.ImpactRating;
import com.qualitytaskforce.insightportal.model.Newsletter;
import com.qualitytaskforce.insightportal.model.Subscription;
import com.qualitytaskforce.insightportal.model.SupportCategory;
import com.qualitytaskforce.insightportal.model.SupportComment;
import com.qualitytaskforce.insightportal.model.SupportStatus;
import com.qualitytaskforce.insightportal.model.SupportTicket;
import com.qualitytaskforce.insightportal.model.Team;
import com.qualitytaskforce.insightportal.model.TestRecommendation;

import org.hibernate.annotations.GenericGenerator;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "users", uniqueConstraints = @UniqueConstraint(columnNames = "email"))
public class User implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;

	@Column(name = "name")
	private String name;
	
	@Column(name = "surname")
	private String surname;
	
	@Column(name = "email", unique = true, nullable = false)
	private String email;
	
	@Column(name = "password", nullable = false, length = 64)
	private String password;
	
	@ManyToOne(fetch = FetchType.LAZY, cascade = CascadeType.DETACH)
	@JoinColumn(name = "user_level_id", nullable = false)
	@JsonProperty(value = "user_level")
	private UserLevel userLevel;
	
	@Column(name = "activated", nullable = false)
	private boolean activated;
	
	@Column(name = "blocked", nullable = false)
	private boolean blocked;
	
	@JsonProperty(value = "block_count")
	@Column(name = "block_count")
	private short blockCount;
	
	@JsonProperty(value = "last_block_date")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_block_date", length = 19)
	private Date lastBlockDate;
	
	@JsonProperty(value = "created_at")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created_at", nullable = false, length = 19)
	private Date createdAt;
	
	@JsonProperty(value = "updated_at")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "updated_at", nullable = false, length = 19)
	private Date updatedAt;
	
	@JsonProperty(value = "last_visit")
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_visit", length = 19)
	private Date lastVisit;
	
	@Column(name = "team_id")
	private Team teamId;

	@JsonProperty(value = "company")
	@Column(name = "company")
	private String company;

	@JsonProperty(value = "phone_number")
	@Column(name = "phone_number")
	private String phoneNumber;

	
	@JsonIgnore
	@OneToOne(fetch = FetchType.LAZY, mappedBy = "user", cascade = CascadeType.ALL)
	private UserTrial userTrial = new UserTrial();
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<ImpactRating> impactRatings = new HashSet<ImpactRating>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<Category> categories = new HashSet<Category>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ApiKey> apiKeys = new HashSet<ApiKey>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByCreatedBy", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ArticleUpdate> articleUpdatesForCreatedBy = new HashSet<ArticleUpdate>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByCreatedBy", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Newsletter> newslettersForCreatedBy = new HashSet<Newsletter>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByUpdatedBy", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<ArticleUpdate> articleUpdatesForUpdatedBy = new HashSet<ArticleUpdate>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<SupportTicket> supportTickets = new HashSet<SupportTicket>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByCreatedBy", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Article> articlesForCreatedBy = new HashSet<Article>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByUpdatedBy", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Article> articlesForUpdatedBy = new HashSet<Article>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<Subscription> subscriptions = new HashSet<Subscription>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<SupportCategory> supportCategories = new HashSet<SupportCategory>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<SupportComment> supportComments = new HashSet<SupportComment>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<SupportStatus> supportStatuses = new HashSet<SupportStatus>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<UserNotification> userNotifications = new HashSet<UserNotification>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<EmailTemplate> emailTemplates = new HashSet<EmailTemplate>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByCheckInBy", cascade = CascadeType.ALL, orphanRemoval = true)
	private Set<Article> articlesForCheckInBy = new HashSet<Article>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByCheckInBy")
	private Set<Newsletter> newslettersForCheckInBy = new HashSet<Newsletter>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<TestRecommendation> testRecommendations = new HashSet<TestRecommendation>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userByCheckInBy")
	private Set<ArticleUpdate> articleUpdatesForCheckInBy = new HashSet<ArticleUpdate>(0);
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "user")
	private Set<UserLogging> userLoggings = new HashSet<UserLogging>(0);
	
	
	public User() {
	}

	public User(UUID uuid, String name, String surname, String email, String password, String company, UserLevel userLevel,
			boolean activated, boolean blocked, short blockCount, Date lastBlockDate, Date createdAt, Date updatedAt,
			Date lastVisit, Team teamId) {
		this.uuid = uuid;
		this.name = name;
		this.surname = surname;
		this.email = email;		
		this.password = password;
		this.company = company;
		this.userLevel = userLevel;
		this.activated = activated;
		this.blocked = blocked;
		this.blockCount = blockCount;
		this.lastBlockDate = lastBlockDate;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.lastVisit = lastVisit;
		this.teamId = teamId;
	}

	public User(UUID uuid, String name, String surname, String email, String password, String company, UserLevel userLevel,
			boolean activated, boolean blocked, short blockCount, Date lastBlockDate, Date createdAt, Date updatedAt,
			Date lastVisit, Team teamId, Set<ImpactRating> impactRatings, Set<Category> categories, Set<ApiKey> apiKeys,
			Set<ArticleUpdate> articleUpdatesForCreatedBy, Set<Newsletter> newslettersForCreatedBy, Set<ArticleUpdate> articleUpdatesForUpdatedBy,
			Set<SupportTicket> supportTickets, Set<Article> articlesForCreatedBy, Set<Article> articlesForUpdatedBy, Set<Subscription> subscriptions,
			Set<SupportCategory> supportCategories, Set<SupportComment> supportComments, Set<SupportStatus> supportStatuses, Set<UserNotification> userNotifications, Set<EmailTemplate> emailTemplates,
			Set<Article> articlesForCheckInBy, Set<Newsletter> newslettersForCheckInBy, Set<TestRecommendation> testRecommendations,
			Set<ArticleUpdate> articleUpdatesForCheckInBy, Set<UserLogging> userLoggings) {
		this.uuid = uuid;
		this.userLevel = userLevel;		
		this.name = name;
		this.surname = surname;
		this.email = email;
		this.password = password;
		this.company = company;
		this.activated = activated;
		this.blocked = blocked;
		this.blockCount = blockCount;
		this.lastBlockDate = lastBlockDate;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.lastVisit = lastVisit;
		this.teamId = teamId;
		this.impactRatings = impactRatings;
		this.categories = categories;
		this.apiKeys = apiKeys;
		this.articleUpdatesForCreatedBy = articleUpdatesForCreatedBy;
		this.newslettersForCreatedBy = newslettersForCreatedBy;
		this.articleUpdatesForUpdatedBy = articleUpdatesForUpdatedBy;
		this.supportTickets = supportTickets;
		this.articlesForCreatedBy = articlesForCreatedBy;
		this.articlesForUpdatedBy = articlesForUpdatedBy;
		this.subscriptions = subscriptions;
		this.supportCategories = supportCategories;
		this.supportComments = supportComments;
		this.supportStatuses = supportStatuses;
		this.userNotifications = userNotifications;
		this.emailTemplates = emailTemplates;
		this.articlesForCheckInBy = articlesForCheckInBy;
		this.newslettersForCheckInBy = newslettersForCheckInBy;
		this.testRecommendations = testRecommendations;
		this.articleUpdatesForCheckInBy = articleUpdatesForCheckInBy;
		this.userLoggings = userLoggings;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public UserLevel getUserLevel() {
		return this.userLevel;
	}

	public void setUserLevel(UserLevel userLevel) {
		this.userLevel = userLevel;
	}
	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getSurname() {
		return this.surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getNameAndSurname() { return this.name + " " + this.surname; }

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	// now the user password should not go out with response
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isActivated() {
		return this.activated;
	}

	public void setActivated(boolean activated) {
		this.activated = activated;
	}

	public boolean isBlocked() {
		return this.blocked;
	}

	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}

	public short getBlockCount() {
		return this.blockCount;
	}

	public void setBlockCount(short blockCount) {
		this.blockCount = blockCount;
	}

	public Date getLastBlockDate() {
		return this.lastBlockDate;
	}

	public void setLastBlockDate(Date lastBlockDate) {
		this.lastBlockDate = lastBlockDate;
	}

	public Date getCreatedAt() {
		return this.createdAt;
	}

	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}

	public Date getUpdatedAt() {
		return this.updatedAt;
	}

	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	public Date getLastVisit() {
		return this.lastVisit;
	}

	public void setLastVisit(Date lastVisit) {
		this.lastVisit = lastVisit;
	}
 
	public Team getTeamId() {
		return this.teamId;
	}

	public void setTeamId(Team teamId) {
		this.teamId = teamId;
	}

	public Set<ImpactRating> getImpactRatings() {
		return this.impactRatings;
	}

	public void setImpactRatings(Set<ImpactRating> impactRatings) {
		this.impactRatings = impactRatings;
	}

	public Set<Category> getCategories() {
		return this.categories;
	}

	public void setCategories(Set<Category> categories) {
		this.categories = categories;
	}

	public Set<ApiKey> getApiKeys() {
		return this.apiKeys;
	}

	public void setApiKeys(Set<ApiKey> apiKeys) {
		this.apiKeys = apiKeys;
	}

	public Set<ArticleUpdate> getArticleUpdatesForCreatedBy() {
		return this.articleUpdatesForCreatedBy;
	}

	public void setArticleUpdatesForCreatedBy(Set<ArticleUpdate> articleUpdatesForCreatedBy) {
		this.articleUpdatesForCreatedBy = articleUpdatesForCreatedBy;
	}

	public Set<Newsletter> getNewslettersForCreatedBy() {
		return this.newslettersForCreatedBy;
	}

	public void setNewslettersForCreatedBy(Set<Newsletter> newslettersForCreatedBy) {
		this.newslettersForCreatedBy = newslettersForCreatedBy;
	}

	public Set<ArticleUpdate> getArticleUpdatesForUpdatedBy() {
		return this.articleUpdatesForUpdatedBy;
	}

	public void setArticleUpdatesForUpdatedBy(Set<ArticleUpdate> articleUpdatesForUpdatedBy) {
		this.articleUpdatesForUpdatedBy = articleUpdatesForUpdatedBy;
	}

	public Set<SupportTicket> getSupportTickets() {
		return this.supportTickets;
	}

	public void setSupportTickets(Set<SupportTicket> supportTickets) {
		this.supportTickets = supportTickets;
	}

	public Set<Article> getArticlesForCreatedBy() {
		return this.articlesForCreatedBy;
	}

	public void setArticlesForCreatedBy(Set<Article> articlesForCreatedBy) {
		this.articlesForCreatedBy = articlesForCreatedBy;
	}

	public Set<Article> getArticlesForUpdatedBy() {
		return this.articlesForUpdatedBy;
	}

	public void setArticlesForUpdatedBy(Set<Article> articlesForUpdatedBy) {
		this.articlesForUpdatedBy = articlesForUpdatedBy;
	}

	public Set<Subscription> getSubscriptions() {
		return this.subscriptions;
	}

	public void setSubscriptions(Set<Subscription> subscriptions) {
		this.subscriptions = subscriptions;
	}

	public Set<SupportCategory> getSupportCategories() {
		return this.supportCategories;
	}

	public void setSupportCategories(Set<SupportCategory> supportCategories) {
		this.supportCategories = supportCategories;
	}

	public Set<SupportComment> getSupportComments() {
		return this.supportComments;
	}

	public void setSupportComments(Set<SupportComment> supportComments) {
		this.supportComments = supportComments;
	}

	public Set<SupportStatus> getSupportStatuses() {
		return this.supportStatuses;
	}

	public void setSupportStatuses(Set<SupportStatus> supportStatuses) {
		this.supportStatuses = supportStatuses;
	}

	public Set<UserNotification> getUserNotifications() {
		return this.userNotifications;
	}

	public void setUserNotifications(Set<UserNotification> userNotifications) {
		this.userNotifications = userNotifications;
	}

	public Set<EmailTemplate> getEmailTemplates() {
		return this.emailTemplates;
	}

	public void setEmailTemplates(Set<EmailTemplate> emailTemplates) {
		this.emailTemplates = emailTemplates;
	}

	public Set<Article> getArticlesForCheckInBy() {
		return this.articlesForCheckInBy;
	}

	public void setArticlesForCheckInBy(Set<Article> articlesForCheckInBy) {
		this.articlesForCheckInBy = articlesForCheckInBy;
	}

	public Set<Newsletter> getNewslettersForCheckInBy() {
		return this.newslettersForCheckInBy;
	}

	public void setNewslettersForCheckInBy(Set<Newsletter> newslettersForCheckInBy) {
		this.newslettersForCheckInBy = newslettersForCheckInBy;
	}

	public Set<TestRecommendation> getTestRecommendations() {
		return this.testRecommendations;
	}

	public void setTestRecommendations(Set<TestRecommendation> testRecommendations) {
		this.testRecommendations = testRecommendations;
	}

	public Set<ArticleUpdate> getArticleUpdatesForCheckInBy() {
		return this.articleUpdatesForCheckInBy;
	}

	public void setArticleUpdatesForCheckInBy(Set<ArticleUpdate> articleUpdatesForCheckInBy) {
		this.articleUpdatesForCheckInBy = articleUpdatesForCheckInBy;
	}

	public Set<UserLogging> getUserLoggings() {
		return this.userLoggings;
	}

	public void setUserLoggings(Set<UserLogging> userLoggings) {
		this.userLoggings = userLoggings;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public UserTrial getUserTrial() {
		return userTrial;
	}

	public void setUserTrial(UserTrial userTrial) {
		this.userTrial = userTrial;
	}
}