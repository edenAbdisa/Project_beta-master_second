package com.qualitytaskforce.insightportal.controller.users;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.post.TrialUserRegister;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.service.users.RegisterService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;

import javassist.NotFoundException;

@RestController
@RequestMapping(value = "/trialregister")
public class RegisterController {
    
	private HttpHeaders headers = new HttpHeaders();   
	
	@Autowired
    private UserService userService;
    
    @Autowired
    private RegisterService registerService;
    
    @Autowired
    private UserTrialService userTrialService;

    @PostMapping("")
    public ResponseEntity<?> registerTrialUser(@RequestBody TrialUserRegister inputDetails, HttpServletRequest request, HttpServletResponse resp) throws InvalidParameterException, InvalidParameterFormatException, DataNotFoundException {
    	
    	headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
    	String response = registerService.register(request, resp, inputDetails);
    	
        return new ResponseEntity<String>(response, headers, HttpStatus.CREATED);
    }
    
    @PostMapping("/validate/email")
    public ResponseEntity<?> validateEmail(@RequestBody Map<String,String> email){
        List<User> user = userService.findByEmail(email.get("email"));
        
        if (!user.isEmpty()) {
            return new ResponseEntity<>(new ApiResponse("error", "This email address already exist"), HttpStatus.UNPROCESSABLE_ENTITY);
        }
        return new ResponseEntity<>(new ApiResponse("OK", "This email address is free"), HttpStatus.OK);
    }

    @PostMapping("/validate/token")
    public ResponseEntity<?> validateToken(@RequestBody Map<String,String> tokenObj) throws DataNotFoundException {
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        String token = tokenObj.get("token");
        Map<String, String> response = new HashMap<>();
        String message;

        UserTrial userTrial = userTrialService.findByConfirmationToken(token);
        
        if (userTrial == null) {
            response.put("message", "token is invalid");
            response.put("status", "failure");
            return new ResponseEntity<>(response, HttpStatus.UNPROCESSABLE_ENTITY);
        }
        
        User user = userTrial.getUser();
        String userLevelName = user.getUserLevel().getName();
        boolean isManualTrial = userLevelName.equals("ManualTrial");
        if (isManualTrial) {
        	// ManualTrial: validate token and activate user together 
        	// (AutomaticTrial: validate and activate in separate paths)
        	String messageKey = "ManualTrial";
        	message = "This email token for " + messageKey + " user is valid";
        	userTrialService.invalidateToken(userTrial);
        	user.setActivated(true);
        	userService.save(user);
        } else
        	message = "This email token is valid";
        
        ApiResponse apiResponse = new ApiResponse("OK", message);
        return new ResponseEntity<>(apiResponse, headers, HttpStatus.OK);
    }
    
    
    @Transactional
    @PostMapping("/activate")
    public ResponseEntity<?> finishTrialCreate(@RequestBody Map<String,String> request) throws NotFoundException {
       
    	UserTrial userTrial = userTrialService.findByConfirmationToken(request.get("token"));
    	if (userTrial == null) {
           throw new NotFoundException("Token has expired or not found");
        }
    	
    	User user = userTrial.getUser();
    	user.setName(request.get("firstName"));
    	user.setSurname(request.get("lastName"));
    	user.setCompany(request.get("company"));
    	user.setPhoneNumber(request.get("phone_number"));
    	user.setActivated(true);
    	user.setUpdatedAt(new Date());
    	
    	userService.save(user);
    	userTrialService.invalidateToken(userTrial);
    	return new ResponseEntity<>(new ApiResponse("SUCCESS", "User has been activated"), HttpStatus.OK);
    }
    
    
    /*@PostMapping("/activatemanual")
    public ResponseEntity<?> finishManualTrialCreate(@RequestBody Map<String,String> request) throws NotFoundException {
       
    	UserTrial userTrial = userTrialService.findByConfirmationToken(request.get("token"));
    	if(userTrial == null)
           throw new NotFoundException("Token has expired or not found");
    	
    	User user = userTrial.getUser();
    	user.setActivated(true);
    	
    	userService.save(user);
    	userTrialService.invalidateToken(userTrial);
    	return new ResponseEntity<>(new ApiResponse("SUCCESS", "User has been activated"), HttpStatus.OK);
    }*/
    
    /*@PostMapping("/validateactivatemanual/token")
    public ResponseEntity<?> finishManualTrialCreate(@RequestBody Map<String,String> tokenObj) throws DataNotFoundException {
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        String token = tokenObj.get("token");
        Map<String, String> response = new HashMap<>();
        String message;

        UserTrial userTrial = userTrialService.findByConfirmationToken(token);
        
        if (userTrial == null) {
            response.put("message", "token is invalid");
            response.put("status", "failure");
            return new ResponseEntity<>(response, HttpStatus.UNPROCESSABLE_ENTITY);
        }
        User user = userTrial.getUser();
        String userLevelName = user.getUserLevel().getName();
        boolean isManualTrial = userLevelName.equals("ManualTrial");
        if (isManualTrial)
        	// should be 'ManualTrial' inside
        	message = "This email token for ManualTrial user is valid"; 
        else
        	message = "This email token is valid";
        ApiResponse apiResponse = new ApiResponse("OK", message);
        
        
        return new ResponseEntity<>(apiResponse, headers, HttpStatus.OK);
    }*/
    
}
