package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;

public class JsonTestAdvisorOs {
	
	@JsonProperty("country_codes")
	private List<String> countries;

	@JsonProperty("regions")
	private List<String> regions;

	@JsonProperty("start_date")
	private String startDate;

	@JsonProperty("end_date")
	private String endDate;

	@JsonProperty("os")
	private String os;

	@JsonProperty("historic")
	private boolean historic;

	@JsonProperty("predictive")
	private boolean predictive;

	@JsonCreator
	public JsonTestAdvisorOs(@JsonProperty("country_codes") List<String> countries, @JsonProperty("regions") List<String> regions, 
							@JsonProperty("start_date") String startDate, @JsonProperty("end_date") String endDate, 
							@JsonProperty("os") String os, @JsonProperty("historic") boolean historic,
							@JsonProperty("predictive") boolean predictive) {
		if (startDate == null) {
			startDate = "";
		}
		if (endDate == null) {
			endDate = "";
		}
		this.countries = countries;
		this.regions = regions;
		this.startDate = startDate;
		this.endDate = endDate;
		this.os = os;
		this.historic = historic;
		this.predictive = predictive;
	}

	public List<String> getCountries() {
		return this.countries;
	}

	public List<String> getRegions() {
		return this.regions;
	}

	public String getStartDate() {
		return this.startDate;
	}

	public String getEndDate() {
		return this.endDate;
	}

	public String getOs() {
		return this.os;
	}

	public boolean getHistoric() {
		return this.historic;
	}

	public boolean getPredictive() {
		return this.predictive;
	}
}