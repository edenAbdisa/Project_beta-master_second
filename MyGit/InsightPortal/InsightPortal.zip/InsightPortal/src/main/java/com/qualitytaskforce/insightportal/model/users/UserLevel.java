package com.qualitytaskforce.insightportal.model.users;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "user_levels", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
public class UserLevel implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "name", unique = true, nullable = false, length = 30)
	private String name;
	
	@Column(name = "permissions", nullable = false, length = 65535)
	private String permissions;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "userLevel")
	private Set<User> users = new HashSet<>(0);

	public UserLevel() {
	}

	public UserLevel(UUID uuid, String name, String permissions) {
		this.uuid = uuid;
		this.name = name;
		this.permissions = permissions;
	}

	public UserLevel(UUID uuid, String name, String permissions, Set<User> users) {
		this.uuid = uuid;
		this.name = name;
		this.permissions = permissions;
		this.users = users;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPermissions() {
		return this.permissions;
	}

	public void setPermissions(String permissions) {
		this.permissions = permissions;
	}

	public Set<User> getUsers() {
		return this.users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}
}
