package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.OperatingSystem;

public interface OperatingSystemRepository extends JpaRepository<OperatingSystem, Long> {

	@Query(value = "SELECT ta_ms_oss.uuid, ta_ms_oss.marketpenetration AS marketpen, ta_oss.version AS os_version, ta_ms_oss.date as date "
				+ "FROM ta_ms_oss "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_oss.osuuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_oss.countryuuid "
				+ "WHERE ta_countries.code = :code "
				+ "AND ta_ms_oss.date > :date "
				+ "AND ta_oss.name = :os "
				+ "AND ta_ms_oss.marketpenetration > 0 "
				+ "ORDER BY date ASC"
				, nativeQuery = true)
	List<OperatingSystem> operatingSystems(@Param("code") String code, @Param("os") String os, @Param("date") String date);

	@Query(value = "SELECT uuid_v4() AS uuid, ta_oss.name AS os_name, ta_oss.version AS os_version, ta_ms_oss.date, "
				+ "(SUM(IFNULL(ta_ms_oss.marketpenetration * ta_countries.desktop_users, 0)) / SUM(ta_countries.desktop_users)) AS marketpen "
				+ "FROM ta_ms_oss "
				+ "INNER JOIN ta_oss ON ta_oss.uuid = ta_ms_oss.osuuid "
				+ "INNER JOIN ta_countries ON ta_countries.uuid = ta_ms_oss.countryuuid "
				+ "WHERE ta_countries.uuid IN :countries "
				+ "AND ta_oss.name = :os "
				+ "AND ta_ms_oss.date > :date "
				+ "AND ta_ms_oss.date < :date1 "
				+ "AND ta_ms_oss.marketpenetration > 0 "
				+ "GROUP BY os_name, os_version, date "
				+ "ORDER BY date ASC"
				, nativeQuery = true)
	List<OperatingSystem> operatingSystemsMultiple(@Param("countries") List<UUID> countries, @Param("os") String os, @Param("date") String startDate, @Param("date1") String endDate);

	@Query(value = "SELECT DISTINCT name FROM ta_oss " 		   
		           , nativeQuery = true)
			List<String> getOperatingSystemsName();
}



