package com.qualitytaskforce.insightportal.repository.cloudadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Task;



public interface TaskRepository extends JpaRepository<Task, UUID>{
	List<Task> findByCloudAdvisor(CloudAdvisor cloudAdvisor);
	List<Task> findByPriorityAndCloudAdvisor(int priority,CloudAdvisor cloudAdvisor);
}
