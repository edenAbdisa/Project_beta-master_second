package com.qualitytaskforce.insightportal.service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.model.BrowserRichCard;
import com.qualitytaskforce.insightportal.repository.BrowserRichCardRepository;

// TODO: Auto-generated Javadoc
/**
 * The Class BrowserRichCardService.
 */
@Service
public class BrowserRichCardService {

	/** The browser repository. */
	@Autowired
	private BrowserRichCardRepository browserRepository;

	/**
	 * Find by UUID string.
	 *
	 * @param uuidString the uuid string
	 * @return the browser rich card
	 */
	public BrowserRichCard findByUUIDString(String uuidString) {
		UUID uuid = UUID.fromString(uuidString);
		return browserRepository.findByUuid(uuid);
	}

	/**
	 * Gets the all.
	 *
	 * @return the all
	 */
	public List<BrowserRichCard> getAll() {
		return browserRepository.findAll();
	}

	/**
	 * Gets the browser brands.
	 *
	 * @return the browser brands
	 */
	public List<String> getBrowserBrands() {
		return browserRepository.getBrowserBrands();
	}

	/**
	 * Gets the browser models.
	 *
	 * @param choosenBrand the choosen brand
	 * @return the browser models
	 */
	public List<String> getBrowserModels(String choosenBrand) {
		return browserRepository.getBrowserModels(choosenBrand);
	}
	
	/**
	 * Gets the browser name.
	 *
	 * @return the browser name
	 */
	public List<String> getBrowserName() {
		return browserRepository.getBrowserName();
	}
	
	/**
	 * Gets the browser modelx.
	 *
	 * @param choosenBrand the choosen brand
	 * @return the browser modelx
	 */
	public BrowserRichCard getBrowserModelx(String choosenBrand) {
		return browserRepository.getBrowserModelx(choosenBrand);
	}

	/**
	 * Gets the browser uuid.
	 *
	 * @param brand the brand
	 * @param version the version
	 * @return the browser uuid
	 */
	public UUID getBrowserUuid(String brand, String version) {
		return UUID.fromString(browserRepository.getBrowserUuid(brand, version));
	}
	
	/**
	 * Gets the browser brand.
	 *
	 * @param uuid the uuid
	 * @return the browser brand
	 */
	public String getBrowserBrand(UUID uuid) {
		return browserRepository.findByUuid(uuid).getBrand();
	}
	
	/**
	 * Gets the browser by name and version.
	 *
	 * @param name the name
	 * @param version the version
	 * @return the browser by name and version
	 */
	public BrowserRichCard getBrowserByNameAndVersion(String name,String version) {
		return browserRepository.getBrowserByNameAndVersion(name,version);
	}
	
	/**
	 * Gets the browser model.
	 *
	 * @param uuid the uuid
	 * @return the browser model
	 */
	public String getBrowserModel(UUID uuid) {
		BrowserRichCard browserRC = browserRepository.findByUuid(uuid);
		return browserRC.getName() + " " + browserRC.getVersion();
	}
	
}