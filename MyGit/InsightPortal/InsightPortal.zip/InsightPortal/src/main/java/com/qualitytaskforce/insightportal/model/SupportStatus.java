package com.qualitytaskforce.insightportal.model;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.qualitytaskforce.insightportal.model.users.User;

@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
@Table(name = "support_status")
public class SupportStatus implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@Column(name = "name", nullable = false, length = 50)
	private String name;	
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "check_in_by")
	private User user;
	
	@JsonIgnore
	@OneToMany(fetch = FetchType.LAZY, mappedBy = "supportStatus")
	private Set<SupportTicket> supportTickets = new HashSet<>(0);

	public SupportStatus() {
	}

	public SupportStatus(UUID uuid, String name) {
		this.uuid = uuid;
		this.name = name;
		
	}

	public SupportStatus(UUID uuid, User user, String name, Set<SupportTicket> supportTickets) {
		this.uuid = uuid;
		this.user = user;
		this.name = name;		
		this.supportTickets = supportTickets;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}	

	public Set<SupportTicket> getSupportTickets() {
		return this.supportTickets;
	}

	public void setSupportTickets(Set<SupportTicket> supportTickets) {
		this.supportTickets = supportTickets;
	}
}
