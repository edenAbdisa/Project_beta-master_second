package com.qualitytaskforce.insightportal.model.users;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "user_notifications", uniqueConstraints = @UniqueConstraint(columnNames = "user_id"))
public class UserNotification implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private UUID uuid;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "user_id", unique = true, nullable = false)
	private User user;
	
	@Column(name = "newletter_notification", nullable = false)
	private boolean newletterNotification;

	public UserNotification() {
	}

	public UserNotification(UUID uuid, User user, boolean newletterNotification) {
		this.uuid = uuid;
		this.user = user;
		this.newletterNotification = newletterNotification;
	}

	public UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public User getUser() {
		return this.user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public boolean isNewletterNotification() {
		return this.newletterNotification;
	}

	public void setNewletterNotification(boolean newletterNotification) {
		this.newletterNotification = newletterNotification;
	}
}
