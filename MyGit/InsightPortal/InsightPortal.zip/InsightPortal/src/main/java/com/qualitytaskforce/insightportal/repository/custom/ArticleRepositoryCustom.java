package com.qualitytaskforce.insightportal.repository.custom;

import java.util.Date;
import java.util.List;

import com.qualitytaskforce.insightportal.model.Article;

public interface ArticleRepositoryCustom {	
	
	List<Article> search(String text, int typeSearchField, boolean typeSymbol, 
			boolean isSortedByDate, boolean isPaginated, 
			Date dateFrom, Date dateTo, int rangeFrom, int results );
}