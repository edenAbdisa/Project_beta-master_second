package com.qualitytaskforce.insightportal.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.model.SefURL;
import com.qualitytaskforce.insightportal.repository.SefURLRepository;

@Service
public class SefURLService {

	@Autowired
	SefURLRepository repo;

	public SefURL findBySefURLStr(String sefURLStr){
		return repo.findBySefUrl(sefURLStr);
	}
	
	@Transactional
	public SefURL save(SefURL sefURL) {
		return repo.save(sefURL);
	}	

	public void delete(SefURL sefURL) {
		repo.delete(sefURL);
	}
}
