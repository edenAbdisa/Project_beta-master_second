package com.qualitytaskforce.insightportal.controller.cloudadvisor;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.ArchivedException;
import com.qualitytaskforce.insightportal.error.UnauthorizedException;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Slot;
import com.qualitytaskforce.insightportal.model.cloudadvisor.Task;
import com.qualitytaskforce.insightportal.repository.cloudadvisor.TaskRepository;
import com.qualitytaskforce.insightportal.service.cloudadvisor.CloudAdvisorService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.SlotService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.TaskService;
import com.qualitytaskforce.insightportal.service.cloudadvisor.Utilities;
import org.apache.commons.lang3.EnumUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author Bruktawit
 *
 */
@RestController
@RequestMapping(value = "/cloudadvisor/tasks")
public class TaskController {

	@Autowired
    private TaskService taskService;

    @Autowired
    private TaskRepository taskRepository;

    @Autowired
    private CloudAdvisorService cloudAdvisorService;

    @Autowired
    private SlotService slotService;
    
    @Autowired
    private Utilities utilities;
    
    public static final Date today=new Date();
    
    
    
    /**
     * Method to return a list of all tasks in a user's company
     * @param request an object of the http request required to get the logged in principal
     * @return list of all tasks in a user's company
     * @throws DataNotFoundException if no cloud advisor is found by the user's company name 
     * or no task exists in the user's company name
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     */
    @GetMapping
    public ResponseEntity<List<Task>> getTasks(HttpServletRequest request) throws DataNotFoundException,UnauthorizedException {

        // DataNotFoundException if clouduuid is not found
        CloudAdvisor cloudAdvisorByCompanyName = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));
        
        // DataNotFoundException if task does not exist
        List<Task> tasksByCompany = taskService.findByCompany(cloudAdvisorByCompanyName);
       
        // return list of tasks belonging to the specified cloud uuid
        return new ResponseEntity<>(tasksByCompany, HttpStatus.OK);
    }
    
    /**
     * Method to edit the task for normal users
     * @param task payload JSON object to be edited includes-uuid,target_date,status_comment,priority,status
     * @param request an object of the http request required to get the logged in principal
     * @return edited task object
     * @throws DataNotFoundException if the task to be edited does not exist 
     * @throws InvalidParameterException if priority is < 0 or priority already exists in the user's company 
     * or if target_date is a date in the past or more than 6 months in the future
     * or the status comment provided is shorter than 3 characters 
     * @throws ParseException if a String can't be parsed to Date
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     * or the user is trying to edit a task that does not exist in their company
     */
    @PostMapping(value = "/edit")
    public ResponseEntity<Task> editTask(@RequestBody Map<String, Object> task, HttpServletRequest request) throws ParseException, InvalidParameterException, DataNotFoundException, UnauthorizedException {

        /**
         *   {
         *    "uuid": "83ebcc99-8e9b-48ed-b4ff-edddfa162a2a",
         *    "target_date" : "2019-04-09",
         *    "status_comment" : null,
         *    "priority" : 5,
         *    "status" : "COMPLETED"
         *   }
         **/
    	
    	// Save Updated Task and Send Response
        return new ResponseEntity<>(taskRepository.save(verifyAndEditTask(task,request)), HttpStatus.OK);
        
        // return success if the task was edited successfully
        // DataNotFoundException if task does not exist
        // Verify the date is not a date in the past (InvalidParamterException)
        // Verify the date is not more than 6 months in the future (InvalidParameterException)
        // Verify comment can be null, if not null comment is longer than 3 characters.
        // updated_at date must be updated if validation passes and task is saved
    }
	
    /**
     * Method to edit the task for Admin users
     * @param task payload JSON object to be edited includes-uuid,target_date,slot_uuid,status_comment,priority,task_type,status
     * @param request an object of the http request required to get the logged in principal
     * @return edited task object
     * @throws DataNotFoundException if the task to be edited does not exist 
     * or the requested slot could not be found
     * @throws InvalidParameterException if priority is < 0 or priority already exists in the user's company
     * or if target_date is a date in the past or more than 6 months in the future
     * or the slot id provided is larger than the maximum value of the company 
     * or the status comment provided is shorter than 3 characters
     * @throws ParseException if a String can't be parsed to Date
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     * or the user is trying to edit a task that does not exist in their company
     */
    @PostMapping(value = "/edit-admin")
    public ResponseEntity<Task> editAdminTask(@RequestBody Map<String, Object> task, HttpServletRequest request) throws DataNotFoundException, InvalidParameterException, ParseException, UnauthorizedException {
        /**
         *   {
         *    "uuid": "83ebcc99-8e9b-48ed-b4ff-edddfa162a2a",
         *    "target_date" : "2019-04-09",
         *    "slot_uuid" : "bf1e9d40-1a5b-4044-a10f-812929c2d526",
         *    "status_comment" : null,
         *    "priority" : 5,
         *    "task_type" : "UPGRADE_DEVICE",
         *    "status" : "COMPLETED"
         *   }
         **/
    	Task toBeEdited=verifyAndEditTask(task,request);
        Slot slot = slotService.findOne(UUID.fromString(task.get("slot_uuid").toString()));
        
        if (slot.getSlotId() == 0 || slot.getSlotId() > toBeEdited.getCloudAdvisor().getMaxSlots()) {
            throw new InvalidParameterException("The slot id provided is larger than the maximum value.");
        }
        checkStringFromEnum(Task.TaskType.class,task.get("task_type").toString());
        toBeEdited.setTaskType(Task.TaskType.valueOf(task.get("task_type").toString()));
        toBeEdited.setSlot(slot);

        // Save Updated Task and Send Response
        return new ResponseEntity<>(taskRepository.save(toBeEdited), HttpStatus.OK);

        // verify the same as the `editTask` method
        // verify task-type matches the values from the database table.
        // verify slotid is a valid slot (not less than 0, not more than the max slot set in cloud_advisor table)
        // updated_at date must be updated if the validation passes and task is saved
        // return success if the task was edited successfully
    }

    /**
     * Method to create task in a user's company 
     * @param task payload JSON object to be edited includes-priority,slot_id,task_type,status,status_comment,target_date
     * @param request an object of the http request required to get the logged in principal
     * @return created task object
     * @throws DataNotFoundException if no cloud advisor exists with the user's company name 
     * or no slot exists with the give slot_id
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     * @throws InvalidParameterException  if priority < 0 or priority already exists in the user's company 
     * or task_type and status_values do not match the enum in the database
     * or status_comment is not null and < 3 characters or target_date is not set in the future or given priority is already given
     * to other task in the database
     * @throws ParseException if a String can't be parsed to Date
     */
    @PostMapping(value = "create")
    public ResponseEntity<Task> createTask(@RequestBody Map<String, Object> task, HttpServletRequest request) throws DataNotFoundException,UnauthorizedException,InvalidParameterException,ParseException {
        /**
         * payload =
         * {
         *  "priority" : int,
         *  "slot_id" : int,
         *  "task_type" : String,
         *  "status" : String,
         *  "status_comment" : String,
         *  "target_date" : String
         * }
         */
        
    	// company_name must exist in cloud_advisor table
        CloudAdvisor cloudAdvisor = cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request));
        
        //verify priority
        int priority=checkPriority((Integer) task.get("priority"),cloudAdvisor);
        
        //check slot
        Slot slot = slotService.findOne(UUID.fromString(task.get("slot_id").toString()));
       
        // verify task_type and status values match the enum in the database (you can make an enum class)
        String taskType = task.get("task_type").toString();
        checkStringFromEnum(Task.TaskType.class,taskType);

        String status = task.get("status").toString();
        checkStringFromEnum(Task.Status.class,status);
        
        //verify status comment
        String statusComment=checkStatusComment(task.get("status_comment"));
        
        // target_date must be set in the future
        String targetDateString = (String) task.get("target_date");
        Date targetDate = parseStringToDate(targetDateString);
        if (targetDate.before(today) || targetDate.equals(today)) {
            throw new InvalidParameterException("The target date must be set to the future.");
        }
    
        
        
        Date createdAt = today;
        Date  updatedAt = today;
        Task newTask = new Task(priority, Task.TaskType.valueOf(taskType), Task.Status.valueOf(status),statusComment , createdAt, updatedAt,
                targetDate, slot, cloudAdvisor);

        // save task to database and return success
        return new ResponseEntity<>(taskRepository.save(newTask), HttpStatus.CREATED);
    }
    
    /**
     * Method to set status of a task to "ARCHIVED" 
     * @param uuidString-uuid of the task to be Archived
     * @param request an object of the http request required to get the logged in principal
     * @return archived task object
     * @throws DataNotFoundException if no task exists with the given uuid 
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     * or the user has entered a task that does not exist in their company
     * @throws ArchivedException if the given task's status is already "ARCHIVED"
     */
    @GetMapping("/archive/{uuid}")
    public ResponseEntity<Task> archiveTask(@PathVariable("uuid") String uuidString, HttpServletRequest request) throws DataNotFoundException,UnauthorizedException,ArchivedException {
    	
    	// check if task is null
        Task task=taskService.findOne(uuidString);

        // check if status is in the user's company
        checkUserCompany(request,task);
        
        // save archived task
        if(task.getStatus().equals(Task.Status.valueOf("ARCHIVED"))) {
        	throw new ArchivedException("The task is Already Archived.");
        }
        task.setStatus(Task.Status.valueOf("ARCHIVED"));
        
        //save and return success
        return new ResponseEntity<>(taskRepository.save(task), HttpStatus.OK);
    }
    
    /**
     * Method to check priority already exists in the user's company
     * @param priority-priority to be checked
     * @param cloudAdvisor-to check priority existence from
     * @return validated priority
     * @throws InvalidParameterException if priority is < 0 or priority already exists in the user's company
     */
    public int checkPriority(int priority,CloudAdvisor cloudAdvisor) throws InvalidParameterException {
    	if (priority < 0) {
            throw new InvalidParameterException("Priority must be greate than zero.");
        }
    	if (!taskRepository.findByPriorityAndCloudAdvisor(priority,cloudAdvisor).isEmpty()) {
            throw new InvalidParameterException("Priority already exists in the company.");
        }
    	return priority;
    }
    
    /**
     * Method to check if status comment is not null and < 3 characters at the same time
     * @param statusCommentObject-object to be verified
     * @return validated status comment string
     * @throws InvalidParameterException if the status comment provided is shorter than 3 characters.
     */
    public String checkStatusComment(Object statusCommentObject) throws InvalidParameterException {
    	String statusComment;
    	if (statusCommentObject == null) {
	    	statusComment = "";
	    }else {
	    	statusComment = statusCommentObject.toString();
	    	if (statusComment.length() <= 3) {
		    	throw new InvalidParameterException("The status comment provided is shorter than 3 characters.");
		    }
	    }
    	return statusComment;
    }
    
    /**
	 * Method to check if a string value matches values from enum 
	 * @param databaseEnum-enum class to check string from
	 * @param stringValue-the string to be checked
	 * @throws InvalidParameterException if a string does not match a value from enum
	 */
	public void checkStringFromEnum(Class databaseEnum,String stringValue) throws InvalidParameterException {
		if (!(EnumUtils.isValidEnum(databaseEnum, stringValue))) {
            throw new InvalidParameterException("The given value " +stringValue+ " is not an appropriate value.");
        }
	}
	
    /**
     * Method to check if a user's company is the same as the company of the task the user is
     * trying to access
     * @param request-an object of the http request required to get the logged in principal
     * @param existingTask-the task the user is trying to access
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     * or if the user is trying to access a task that does not exist in their company
     * @throws DataNotFoundException 
     */
    private void checkUserCompany(HttpServletRequest request, Task existingTask) throws UnauthorizedException, DataNotFoundException {
		if(! utilities.getUserCompanyName(request).equals(existingTask.getCloudAdvisor().getCompanyName())) {
    		throw new UnauthorizedException("No such task exists for the current user company.");
    	}
	}
    
    /**
     * Method to return Date from given String
     * @param dateString-string to be parsed to Date
     * @return Date from the string
     * @throws ParseException if a String can't be parsed to Date
     */
    public Date parseStringToDate(String dateString) throws ParseException{
    	return new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
    }
    
    /**
     * Method to verify task parameters passed from user and edit task if 
     * all parameters are valid
     * @param task-object to be edited
     * @param request an object of the http request required to get the logged in principal
     * @return edited task object
     * @throws ParseException if a String can't be parsed to Date
     * @throws InvalidParameterException if priority is < 0 or priority already exists in the user's company 
     * or if target_date is a date in the past or more than 6 months in the future
     * or the status comment provided is shorter than 3 characters 
     * @throws DataNotFoundException if the task to be edited does not exist
     * @throws UnauthorizedException if the user has logged in with incorrect credentials 
     * or the user is trying to edit a task that does not exist in their company
     */
    public Task verifyAndEditTask(Map<String, Object> task,HttpServletRequest request) throws ParseException, InvalidParameterException, DataNotFoundException, UnauthorizedException{
    	
    	Task existingTask=taskService.findOne(task.get("uuid").toString());
    	checkUserCompany(request, existingTask);
    	
    	Calendar currentDateAfter6Months = Calendar.getInstance();
    	currentDateAfter6Months.add(Calendar.MONTH, 6);
    	Date targetDate = parseStringToDate((String) task.get("target_date"));
	    if (targetDate.before(today)) {
	    	throw new InvalidParameterException("Target date has already passed.");
	    }
	    if (targetDate.after(currentDateAfter6Months.getTime())) {
	    	throw new InvalidParameterException("The target date provided is more than six months later than current day.");
	    }
	    
	    String taskStatus=task.get("status").toString();
	    checkStringFromEnum(Task.Status.class,taskStatus);
	    
	    if(existingTask.getPriority()!=(int) task.get("priority")) {
	    	existingTask.setPriority(checkPriority((int) task.get("priority"),cloudAdvisorService.findByCompanyName(utilities.getUserCompanyName(request))));
	    }
	    
	    existingTask.setStatus(Task.Status.valueOf(taskStatus));
	    existingTask.setStatusComment(checkStatusComment(task.get("status_comment")));
        existingTask.setUpdatedAt(today);
	    existingTask.setTargetDate(targetDate);
	    
	    return existingTask;
        }

}
