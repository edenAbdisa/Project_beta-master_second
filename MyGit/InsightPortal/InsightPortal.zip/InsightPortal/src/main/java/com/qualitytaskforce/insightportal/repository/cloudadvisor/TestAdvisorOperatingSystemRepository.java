package com.qualitytaskforce.insightportal.repository.cloudadvisor;

import java.util.List;
import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.cloudadvisor.TestAdvisorOperatingSystem;



public interface TestAdvisorOperatingSystemRepository extends JpaRepository<TestAdvisorOperatingSystem, UUID>{

	@Query(value = "SELECT uuid, name, version "
			+ "FROM ta_oss "
			+ "WHERE name =:name "
			, nativeQuery = true)
	List<TestAdvisorOperatingSystem> getOS(@Param("name") String name);


	@Query(value = "SELECT uuid, name, version "
			+ "FROM ta_oss "
			+ "WHERE uuid = :uuid "
			, nativeQuery = true)
	List<TestAdvisorOperatingSystem> getOsName( @Param("uuid") UUID uuid);
	


	
	@Query(value = "SELECT uuid, name, version "
			+ "FROM ta_oss "
			+ "WHERE name =:name "
			+ "AND version  = :version" 
			, nativeQuery = true)
	TestAdvisorOperatingSystem getSingleOS(@Param("name") String name,@Param("version") String version);
	
	@Query(value = "SELECT DISTINCT name FROM ta_oss " 		   
	           , nativeQuery = true)
		List<String> getOperatingSystemsName();

}
