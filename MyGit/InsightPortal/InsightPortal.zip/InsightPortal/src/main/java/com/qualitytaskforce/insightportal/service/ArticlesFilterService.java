package com.qualitytaskforce.insightportal.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.articleModifications.list.ArticleWhenList;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.util.PrepareToShowInList;
import com.qualitytaskforce.insightportal.util.SefURLToString;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service	
public class ArticlesFilterService {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ArticlesFilterService.class);

	@Autowired
	private ArticleService articleService;
	
	@Autowired
	ArticleRepository articleRepository;
	
	
	public List<ArticleWhenList> getFilteredArticles ( String dateStart, String dateStop, String keywords, 
															JSONArray subcategoriesJson) throws Exception {
		
		List<String> subcategories = getSubcategoriesList(subcategoriesJson);
	    List<ArticleWhenList> articlesCutted = new ArrayList<ArticleWhenList>();
		List<Article> articles = new ArrayList<Article>();
		
		if (!isDatesPresent(dateStart, dateStop)) {
			articlesCutted = getNoDateArticlesCutted(keywords, articles, subcategories, articlesCutted);
		} else {
			articlesCutted = getArticlesCutted(keywords, dateStart, dateStop, articles, subcategories, articlesCutted);
		}
		
		return articlesCutted;
	}
	
	
	boolean isDatesPresent (String dateStart, String dateStop) {
		return !(dateStart.trim().length() < 1 && dateStop.trim().length() < 1);
	}
	
	List<ArticleWhenList> getNoDateArticlesCutted (String keywords, List<Article> articles, List<String> subcategories, List<ArticleWhenList> articlesCutted) {
		if (keywords.equals("none")) {
	    	articles = articleService.filterByDateSubcategories(null, null, subcategories);			
		} else if (keywords.trim().length() > 0 && keywords.trim().length() < 30) {
			
			articles = articleRepository.autocomplWithSQL(keywords);
			List<Article> filteredBySubcategories = getFilteredBySubcats(articles, subcategories);
			articles = filteredBySubcategories;
		}			
	
		return PrepareToShowInList.prepare(articles);
	}
	
	List<ArticleWhenList> getArticlesCutted (String keywords, String dateStart, String dateStop, List<Article> articles, List<String> subcategories, List<ArticleWhenList> articlesCutted) throws Exception {
		
		List<Date> dates = strToDates(dateStart, dateStop);
	    Date dateFrom = dates.get(0);
	    Date dateTo = dates.get(1);
	    
	    if (dateFrom.after(dateTo)) {
	    	throw new Exception("Date sequence is wrong");
		}
	    if (keywords.equals("none")) {
	    	articles = articleService.filterByDateSubcategories(dateFrom, dateTo, subcategories);			
		} else if (keywords.trim().length() > 0 && keywords.trim().length() < 30) {
			
			articles = articleRepository.filterSearchWithSQL(keywords, dateFrom, dateTo);
			List<Article> filteredBySubcategories = getFilteredBySubcats(articles, subcategories);
			articles = filteredBySubcategories;
		}			
		
		return PrepareToShowInList.prepare(articles);	
	}

	
	
	
	List<String> getSubcategoriesList (JSONArray subcategoriesJson) {
		List<String> subcategories = new ArrayList<String>();
		for (int i = 0; i < subcategoriesJson.length(); i++) {
			String converted = null;
			try {
				converted = SefURLToString.sefUrlToString(subcategoriesJson.get(i).toString());
			} catch (JSONException e) {
				LOGGER.info("Error parsing categories", e);
			}
			subcategories.add(converted);
		}
		return subcategories;
	}
	
	
	
	List<Article> getFilteredBySubcats(List<Article> articles, List<String> subcategories) {		
		List<Article> filteredBySubcategories = new ArrayList<Article>();
		for (Article article : articles) {
			for (String subcategory : subcategories) {
				if (article.getSubcategory().equals(subcategory)) {
					filteredBySubcategories.add(article);
					break;
				}
			}
		}
		return filteredBySubcategories;
	}
	
	private List<Date> strToDates(String dateStart, String dateStop) {
		
		Date dateFrom = null;
		Date dateTo = null;
		
		try {
			int day = Integer.valueOf(dateStop.substring(0,2));
	    	String dateStopMod = String.valueOf(day+1);
	    	if (dateStopMod.length()==1) {
				dateStopMod = "0" + dateStopMod;
			}
			dateStop = dateStopMod + dateStop.substring(2);
	    	dateFrom = new SimpleDateFormat("dd/MM/yyyy").parse(dateStart);
			dateTo = new SimpleDateFormat("dd/MM/yyyy").parse(dateStop);
		 } catch (ParseException e) {			
			LOGGER.info("Error parsing dates. From: {}, To: {}", dateStart, dateStop, e);
		 }
		 
		 List<Date> dates = new ArrayList<Date>();
		 dates.add(dateFrom);
		 dates.add(dateTo);
		 return dates;			 
	}
}
