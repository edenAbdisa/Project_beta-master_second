package com.qualitytaskforce.insightportal.util;

public class HtmlToString {
	public static String convert(String input){
		String text = input;		

		text = text.replace(">","> ");
		text = text.replace("> <", "><");
		text = text.replaceAll("\\<.*?\\>","");
		text = text.trim().replaceAll(" +", " ");
		text = text.replace("&nbsp;","");
		text = text.replace(" .", ".");
		text = text.replace(".  ", ". ");
		
		return text;		
	}
	
	/**
	 * Removes html tags from strings
	 * @param input the string to remove tags from
	 * @return the string without tags
	 */
	public static String removeTags(String input) {
		StringBuilder sb = new StringBuilder(input);
		int[][] array = new int[100][2];
		int arrCount = 0;
		for (int i = sb.length() - 1; i >= 0; i--) {
			if (sb.charAt(i) == '>') {
				array[arrCount][1] = i;
				continue;
			}
			if (sb.charAt(i) == '<') {
				array[arrCount][0] = i;
				arrCount++;
			}
		}		
		
		for (int i = 0; i < arrCount; i++) {
			sb.delete(array[i][0], array[i][1] + 1);
		}
		
		return sb.toString();
	}
}