package com.qualitytaskforce.insightportal.model.response;


import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.SefURL;

public class ReleaseAdvisorWithSefUrl {

    ReleaseAdvisor releaseAdvisor;
    SefURL sefUrl;

    public ReleaseAdvisorWithSefUrl(ReleaseAdvisor releaseAdvisor, SefURL sefUrl) {
        this.releaseAdvisor = releaseAdvisor;
        this.sefUrl = sefUrl;
    }

    public ReleaseAdvisor getReleaseAdvisor() {
        return releaseAdvisor;
    }

    public void setReleaseAdvisor(ReleaseAdvisor releaseAdvisor) {
        this.releaseAdvisor = releaseAdvisor;
    }

    public SefURL getSefUrl() {
        return sefUrl;
    }

    public void setSefUrl(SefURL sefUrl) {
        this.sefUrl = sefUrl;
    }
}
