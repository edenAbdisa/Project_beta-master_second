package com.qualitytaskforce.insightportal.model.cloudadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "ta_oss")
public class TestAdvisorOperatingSystem {
	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name="uuid")
	private UUID uuid;
	@Column(name="name")
	private String name;
	
	@Column(name="version")
	private String version;
	
	public TestAdvisorOperatingSystem() {
		
	}
	
	
	public TestAdvisorOperatingSystem(UUID uuid, String name, String version) {
		
		this.uuid = uuid;
		this.name = name;
		this.version = version;
	}


	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	
}
