package com.qualitytaskforce.insightportal.model.cloudadvisor;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.util.UUID;

import javax.persistence.*;

@Entity
@Table(name = "cloud_advisor")
public class CloudAdvisor implements java.io.Serializable {

    @Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name="uuid")
	private UUID uuid;
    
    @Column(name = "coverage", nullable = true)
    private int coverage;

    @Column(name = "max_slots")
    private int maxSlots;

    @Column(name = "company_name")
    private String companyName;

    @Column(name = "browser_rules")
    @Enumerated(EnumType.STRING)
    private BrowserRules browserRules;

    @Column(name = "device_rules")
    @Enumerated(EnumType.STRING)
    private DeviceRules deviceRules;


    // Constructors //

    public CloudAdvisor() {
    }

    public CloudAdvisor(int coverage, int maxSlots, String companyName, BrowserRules browserRules, DeviceRules deviceRules) {
        this.coverage = coverage;
        this.maxSlots = maxSlots;
        this.companyName = companyName;
        this.browserRules = browserRules;
        this.deviceRules = deviceRules;
    }



    // Getters and Setters //

    public UUID getUuid() {
        return uuid;
    }

    public void setUuid(UUID uuid) {
        this.uuid = uuid;
    }

    public int getCoverage() {
        return coverage;
    }

    public void setCoverage(int coverage) {
        this.coverage = coverage;
    }

    public int getMaxSlots() {
        return maxSlots;
    }

    public void setMaxSlots(int maxSlots) {
        this.maxSlots = maxSlots;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public BrowserRules getBrowserRules() {
        return browserRules;
    }

    public void setBrowserRules(BrowserRules browserRules) {
        this.browserRules = browserRules;
    }

    public DeviceRules getDeviceRules() {
        return deviceRules;
    }

    public void setDeviceRules(DeviceRules deviceRules) {
        this.deviceRules = deviceRules;
    }


    // Enums //
    public enum BrowserRules {
        ALPHA_CHANGE, BETA_CHANGE, PRODUCTION_CHANGE, NOTHING
    }

    public enum DeviceRules {
        TEST_ADVISOR, QTF_ADVISOR, NOTHING
    }
}
