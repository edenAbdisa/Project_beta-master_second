package com.qualitytaskforce.insightportal.service;

import java.util.*;

import javax.transaction.Transactional;

import com.qualitytaskforce.insightportal.model.SefURL;
import com.qualitytaskforce.insightportal.model.response.ReleaseAdvisorWithSefUrl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.error.SaveEntityException;
import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.post.JsonReleaseAdvisor;
import com.qualitytaskforce.insightportal.model.put.JsonReleaseAdvisorPut;
import com.qualitytaskforce.insightportal.model.util.ReleaseAdvisorFilterCriteria;
import com.qualitytaskforce.insightportal.repository.ArticleRepository;
import com.qualitytaskforce.insightportal.repository.ReleaseAdvisorRepository;

@Service
public class ReleaseAdvisorService
{
	@Autowired
	ReleaseAdvisorRepository releaseAdvisorRepository;
	
	@Autowired
	ArticleRepository articleRepository;

	public List<ReleaseAdvisor> findMatchingCriteria(ReleaseAdvisorFilterCriteria criteria){	
		return releaseAdvisorRepository.findMatchingCriteria(criteria);
			
	}
	
	public ReleaseAdvisor findByUUIDString(String uuidStr){
		UUID uuid = UUID.fromString(uuidStr);
		return releaseAdvisorRepository.findByUuid(uuid);
	}
	
	public List<ReleaseAdvisor> findAll(){
		return releaseAdvisorRepository.findAll();
	}

	public List<ReleaseAdvisor> findAllPublished() {
		return releaseAdvisorRepository.findAllByPublishedIsTrue();
	}

	/**
	 * Creates ReleaseAdvisor event.
	 * ReleaseAdvicsor event can or cannot have attributed an Article.
	 * If Article UUID is specified and there is no article of the given UUID, method throws an exception.
	 * @param jra
	 * @return
	 * @throws SaveEntityException 
	 */
	@Transactional
	public ReleaseAdvisor create(JsonReleaseAdvisor jra) throws SaveEntityException{
		ReleaseAdvisor ra = new ReleaseAdvisor(jra);
		if (jra.getArticleUuid() != null) {
			Article article = articleRepository.findByUuid(jra.getArticleUuid());
			if (article == null) {
				throw new SaveEntityException("Could not create the event: article with provided UUID does not exist.");
			}
			ra.setArticle(article);
		}
		releaseAdvisorRepository.save(ra);
		return ra;
	}
	
	@Transactional
	public ReleaseAdvisor createAfterArticle(JsonReleaseAdvisor jra, Article article) throws SaveEntityException {
		ReleaseAdvisor ra = new ReleaseAdvisor(jra);
		ra.setArticle(article);
		releaseAdvisorRepository.save(ra);
		return ra;
	}
	
	@Transactional
	public ReleaseAdvisor updateWhenUpdateArticle(JsonReleaseAdvisorPut jra) throws SaveEntityException {
		ReleaseAdvisor ra = findByUUID(jra.getUuid());
		ra.setTitle(jra.getTitle());
		ra.setSubtitle(jra.getSubtitle());
		ra.setCategory(jra.getCategory());
		ra.setStartDate(jra.getStartDate());
		ra.setEndDate(jra.getEndDate());
		releaseAdvisorRepository.save(ra);
		return ra;
	}
	
	@Transactional
	public ReleaseAdvisor createWhenUpdateArticle(JsonReleaseAdvisorPut jra, Article article) throws SaveEntityException {
		ReleaseAdvisor ra = new ReleaseAdvisor();
		ra.setArticle(article);
		ra.setTitle(jra.getTitle());
		ra.setSubtitle(jra.getSubtitle());
		ra.setCategory(jra.getCategory());
		ra.setStartDate(jra.getStartDate());
		ra.setEndDate(jra.getEndDate());
		releaseAdvisorRepository.save(ra);
		return ra;
	}
	
	@Transactional
	public void save(ReleaseAdvisor releaseAdvisor) {
		releaseAdvisorRepository.save(releaseAdvisor);
	}
	
	
	public void deleteByUUIDString(String uuidStr){
		UUID uuid = UUID.fromString(uuidStr);
		
		releaseAdvisorRepository.delete(uuid);
	}

	/**
	 * Updates ReleaseAdvisor event under given UUID given that it exists, otherwise it creates a new resource.
	 * ReleaseAdvicsor event can or cannot have attributed an Article.
	 * If Article UUID is specified and there is no article of the given UUID, method throws an exception.
	 * @param uuidString
	 * @param jra
	 * @throws SaveEntityException
	 */
	@Transactional
	public boolean update(String uuidString, JsonReleaseAdvisor jra) throws SaveEntityException
	{
		ReleaseAdvisor ra = new ReleaseAdvisor(jra);
		ra.setUuid(UUID.fromString(uuidString));
		if (jra.getArticleUuid() != null) {
			Article article = articleRepository.findByUuid(jra.getArticleUuid());
			if (article == null) {
				throw new SaveEntityException("Could not update the event: article with provided UUID does not exist.");
			}
			ra.setArticle(article);
		}
		releaseAdvisorRepository.save(ra);
		return true;
	}
	
	@Transactional
	public List<ReleaseAdvisor> getNextEvents(int n) {
		return releaseAdvisorRepository.getNextEvents(n);
	}

	/**
	 * Get next n events with sef URLs of their corresponding articles
	 * (used in ReleaseAdvisorMobile and Upcoming Releases)
	 * @param n
	 * @return
	 */

	@Transactional
	public List<ReleaseAdvisorWithSefUrl> getNextEventsWithArticleSefUrls(int n) {
		List<ReleaseAdvisor> listOfEvents = releaseAdvisorRepository.getNextEvents(n);
		List<ReleaseAdvisorWithSefUrl> eventsWithSefUrls = new ArrayList<>();
		for (ReleaseAdvisor ra : listOfEvents) {
			/* Check if RA event has an article attached */
			if (ra.getArticle() != null) {
				SefURL sefUrl = articleRepository.findByUuid(ra.getArticle().getUuid()).getSefURL();
				eventsWithSefUrls.add(new ReleaseAdvisorWithSefUrl(ra, sefUrl));
			} else {
				eventsWithSefUrls.add(new ReleaseAdvisorWithSefUrl(ra, null));
			}
		}
		return eventsWithSefUrls;
	}

	@Transactional
	public List<ReleaseAdvisorWithSefUrl> getEventsWithArticleSefUrls() {
		List<ReleaseAdvisor> listOfEvents = releaseAdvisorRepository.findAll();
		List<ReleaseAdvisorWithSefUrl> eventsWithSefUrls = new ArrayList<>();
		for (ReleaseAdvisor ra : listOfEvents) {
			/* Check if RA event has an article attached */
			SefURL sefUrl = null;
			if (ra.getArticle() != null) {
				sefUrl = articleRepository.findByUuid(ra.getArticle().getUuid()).getSefURL();
			}
			eventsWithSefUrls.add(new ReleaseAdvisorWithSefUrl(ra, sefUrl));
		}
		return eventsWithSefUrls;
	}


	public List<Object> getCategories() {
        return releaseAdvisorRepository.getAllCategories();
    }

	public ReleaseAdvisor findByUUID(UUID uuid) {

		return releaseAdvisorRepository.findByUuid(uuid);
	}
	public boolean publishToggle(UUID uuid, boolean isPublish){
		ReleaseAdvisor releaseAdvisor = releaseAdvisorRepository.findByUuid(uuid);
		if (releaseAdvisor != null) {
			releaseAdvisor.setPublished(isPublish);
			releaseAdvisorRepository.save(releaseAdvisor);
			return true;
		} else {
			return false;
		}
	}

    public boolean deleteBatch(UUID uuid) {
		ReleaseAdvisor releaseAdvisor = releaseAdvisorRepository.findByUuid(uuid);
		if (releaseAdvisor != null) {
			releaseAdvisorRepository.delete(uuid);
			return true;
		} else {
			return false;
		}
	}
}
