package com.qualitytaskforce.insightportal.service.cloudadvisor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.model.cloudadvisor.CloudAdvisor;
import com.qualitytaskforce.insightportal.repository.cloudadvisor.CloudAdvisorRepository;

@Service
public class CloudAdvisorService {
	
	@Autowired
	CloudAdvisorRepository cloudAdvisorRepository;

	/**
	 * A method to fetch an existing cloud advisor by a company name
	 *
	 * @param companyName the name of the company whose cloud advisor is to be fetched
	 * @return the cloud advisor object with the provided company name
	 * @throws DataNotFoundException if no cloud advisor exists that has the provided company name
	 */
	public CloudAdvisor findByCompanyName(String companyName) throws DataNotFoundException {
		CloudAdvisor cloudAdvisorByCompanyName = cloudAdvisorRepository.findByCompanyName(companyName);
		if (cloudAdvisorByCompanyName == null) {
            throw new DataNotFoundException("No cloud advisor exists with the provided company name.");
        }
		return cloudAdvisorByCompanyName;
	}

}
