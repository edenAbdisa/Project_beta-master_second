package com.qualitytaskforce.insightportal.model.users;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.hibernate.annotations.GenericGenerator;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "user_trial")
public class UserTrial implements java.io.Serializable{
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "uuid", updatable = false, nullable = false)
    private UUID uuid;
    
    @JsonProperty(value = "user_id")
    @JoinColumn(name = "user_id")
    @OneToOne(fetch = FetchType.LAZY)
	private User user;
    
    @JsonIgnore
	@Column(name = "confirmation_token")
	private String confirmationToken;
    
    @Column(name = "sent_trial_email")
	private boolean sentTrialEmail;
    
    @Temporal(TemporalType.TIMESTAMP)
	@Column(name = "expire_at", nullable = false, length = 19)
	private Date expireAt;

    public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	public String getConfirmationToken() {
		return confirmationToken;
	}

	public void setConfirmationToken(String confirmationToken) {
		this.confirmationToken = confirmationToken;
	}
    
    public boolean isSentTrialEmail() {
		return sentTrialEmail;
	}

	public void setSentTrialEmail(boolean sentTrialEmail) {
		this.sentTrialEmail = sentTrialEmail;
	}

	public Date getExpireAt() {
		return expireAt;
	}

	public void setExpireAt(Date expireAt) {
		this.expireAt = expireAt;
	}
}
