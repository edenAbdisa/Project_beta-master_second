package com.qualitytaskforce.insightportal.model.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.service.LoginAttemptService;
import com.qualitytaskforce.insightportal.service.users.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Component;

@Component
public class CustomBasicAuthProvider implements AuthenticationProvider {

	@Autowired
	UserService userService;

	@Autowired
	LoginAttemptService loginAttemptService;

	private final String DUMMY_PASSWORD = "$2a$10$PSdrjlu95Ul31js6aPFav.vh.t.UrgMKFv6v8boT7r5kgHQUTKWwK"; // Strength = 10 (~80ms)

	@Override
	public Authentication authenticate(Authentication auth) throws AuthenticationException {

		/* Check if user's IP is blocked */
		if (!(auth.getDetails() instanceof WebAuthenticationDetails)) {
			RequestDetails requestDetails = (RequestDetails) auth.getDetails();
			String ip = requestDetails.getIpAddress();
			if (loginAttemptService.isBlocked(ip)) {
				throw new BadCredentialsException("This account is blocked.");
			}
		}

		final String email = auth.getName();
		final String password = auth.getCredentials().toString();

		List<User> validateUser = userService.findByEmail(email);

		if (!validateUser.isEmpty() && validateUser.size() == 1) {
			if (BCrypt.checkpw(password, validateUser.get(0).getPassword())) {
				String userPermissions = validateUser.get(0).getUserLevel().getPermissions();
				List<GrantedAuthority> authorities = parseAuthority(userPermissions);

				return new UsernamePasswordAuthenticationToken(email, password, authorities);
			} else {
				throw new BadCredentialsException("The username and/or password is incorrect.");
			}
		} else {
			//If no user is found, check the password of a dummy user to produce similar response timings
			BCrypt.checkpw(password, DUMMY_PASSWORD);
			throw new BadCredentialsException("The username and/or password is incorrect.");
		}
	}

	@Override
	public boolean supports(Class<?> auth) {
		return auth.equals(UsernamePasswordAuthenticationToken.class);
	}

	private List<GrantedAuthority> parseAuthority(String userPermissions) {
		List<GrantedAuthority> authorities = new ArrayList<>();
		try {

			Map<String, Object> map = new HashMap<String, Object>();

			ObjectMapper mapper = new ObjectMapper();

			map = mapper.readValue(userPermissions, new TypeReference<Map<String, Object>>(){});

			for (Map.Entry<String, Object> entry : map.entrySet()) {
				String name = entry.getKey().toUpperCase();
				String value = entry.getValue().toString();

				if (value.equals("1")) {
					SimpleGrantedAuthority s = new SimpleGrantedAuthority("ROLE_" + name);
					authorities.add(s);
				}
			}

		} catch (JsonGenerationException e) {
			e.getMessage();
		} catch (JsonMappingException e) {
			e.getMessage();
		} catch (IOException e) {
			e.getMessage();
		}

		return authorities;
	}
}