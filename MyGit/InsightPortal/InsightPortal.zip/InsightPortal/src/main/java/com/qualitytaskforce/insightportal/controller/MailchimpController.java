package com.qualitytaskforce.insightportal.controller;

import java.util.Map;
import com.qualitytaskforce.insightportal.mailchimp.MailchimpConnectorService;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MailchimpController {

    @Autowired
    MailchimpConnectorService mailchimpConnectorService;

    @PostMapping("newslettersubscribe")
    public String subscribeToMailchimpNewsletter(@RequestBody Map<String, String> emailBody) throws JSONException {
        String email = emailBody.get("email");
        return mailchimpConnectorService.subscribe(email);
    }
}
