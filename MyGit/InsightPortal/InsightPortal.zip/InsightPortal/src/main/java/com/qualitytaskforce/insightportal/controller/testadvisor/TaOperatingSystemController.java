package com.qualitytaskforce.insightportal.controller.testadvisor;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.testadvisor.Country;
import com.qualitytaskforce.insightportal.model.testadvisor.OperatingSystem;
import com.qualitytaskforce.insightportal.model.testadvisor.JsonTestAdvisorOs;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import com.qualitytaskforce.insightportal.service.TestAdvisorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping(value = "/testadvisor")
public class TaOperatingSystemController {
	public static final Logger LOGGER = LoggerFactory.getLogger(TaOperatingSystemController.class);

	@Autowired
	private TestAdvisorService service;

	private HttpHeaders headers = new HttpHeaders();

	@Autowired
	private MessageUtil util;

	@RequestMapping(value = "/operatingsystems/{os}/{code}", method = RequestMethod.GET)
	public ResponseEntity<?> operatingSystems(@PathVariable String os, @PathVariable String code, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		os = alterOs(os);

		List<OperatingSystem> list = service.operatingSystems(code, os, getDatePast());
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<OperatingSystem>>(list, headers, HttpStatus.OK);
	}

	@RequestMapping(value = "/operatingsystems/", method = RequestMethod.POST)
	public ResponseEntity<?> operatingSystemsMultiple(@RequestBody JsonTestAdvisorOs input, HttpServletRequest request) throws Exception {
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		if (input.getStartDate().equals("")) {
			throw new InvalidParameterException(util.getMessage("error.ta.os.no-start-date"));
		}
		if (input.getEndDate().equals("")) {
			throw new InvalidParameterException(util.getMessage("error.ta.os.no-end-date"));
		}

		List<String> inputCountries = input.getCountries();
		List<String> inputRegions = input.getRegions();
		StringBuilder inputStartDate = new StringBuilder(input.getStartDate());
		StringBuilder inputEndDate = new StringBuilder(input.getEndDate());
		String inputOs = input.getOs().toLowerCase();
		boolean inputHistoric = input.getHistoric();
		boolean inputPredictive = input.getPredictive();
	
		List<String> regions = getRegions();		
		List<Country> countriesByRegion = new ArrayList<>();
		List<UUID> countryuuids = new ArrayList<>();
		List<OperatingSystem> list = new ArrayList<>();
		List<Country> countries = new ArrayList<>();

		if (checkRequiredNull(inputRegions, inputCountries)) {
			throw new InvalidParameterException(util.getMessage("error.ta.generic.no-country-or-region"));
		}

		boolean worldRegion = false;
		//Check World region first, if world is specified countries parameter cant be ignored
		if (inputRegions != null) {
			if (inputRegions.contains("WWW")) {
				countries = service.getAllCountries();
				worldRegion = true;
			} else {
				if (!regions.containsAll(inputRegions)) {
					throw new InvalidParameterFormatException(util.getMessage("error.ta.generic.incorrect-region"));
				}
				countriesByRegion = service.getCountriesByRegion(inputRegions);
				if (countriesByRegion.isEmpty()) {
					throw new DataNotFoundException(util.getMessage("error.ta.generic.no-region-data"));
				}
				countries.addAll(countriesByRegion);
			}
		}

		String os = alterOs(inputOs);

		if (!checkOs(os)) {
			throw new DataNotFoundException(util.getMessage("error.ta.os.not-found"));
		}

		if (!checkHistoricAndPredictive(inputHistoric, inputPredictive)) {
			throw new InvalidParameterException(util.getMessage("error.ta.os.no-historic-predictive"));
		}
		
		addCountries(inputCountries, countries, worldRegion);
		countryuuids = getCountryUuids(countries);

		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date startDate = new Date();
		Date endDate = new Date();
		Date nowDate = new Date();
		try {
			startDate = df.parse(inputStartDate.toString());
			endDate = df.parse(inputEndDate.toString());
		} catch (ParseException e) {
			LOGGER.info("Error parsing dates. Start: {}, End: {}", inputStartDate.toString(), inputEndDate.toString(), e);
		}

		if (inputHistoric) {
			if (nowDate.before(startDate)) {
				throw new InvalidParameterFormatException(util.getMessage("error.ta.os.bad-historic-date"));
			}
		}
		if (inputPredictive) {
			if (nowDate.after(endDate)) {
				throw new InvalidParameterFormatException(util.getMessage("error.ta.os.bad-predictive-date"));
			}
		}

		if (startDate.after(endDate)) {
			throw new InvalidParameterFormatException(util.getMessage("error.ta.os.bad-date-order"));
		}

		if (!inputHistoric && startDate.before(nowDate)) {
			startDate = nowDate;
		}

		if (!inputPredictive && endDate.after(nowDate)) {
			endDate = nowDate;
		}

		list = service.operatingSystemsMultiple(countryuuids, os, df.format(startDate), df.format(endDate));
		
		if (list.isEmpty()) {
			throw new DataNotFoundException(util.getMessage("error.ta.generic.no-data"));
		}

		return new ResponseEntity<List<OperatingSystem>>(list, headers, HttpStatus.OK);
	}

	private String getDatePast() {
		Date now = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(now);
		cal.add(Calendar.YEAR, -2);
		String date = new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime());
		return date;
	}

	private boolean checkRequiredNull(List<String> regions, List<String> countries) {
		if (regions == null && countries == null) {
			return true;
		}
		return false;
	}

	private boolean checkOs(String os) {
		if (os.equals("iOS") || os.equals("Android")) {
			return true;
		}
		return false;
	}

	private String alterOs(String os) {
		os = os.toLowerCase();
		if (os.equals("ios")) {
			os = "iOS";
		} else if (os.equals("android")) {
			os = "Android";
		}
		return os;
	}

	private boolean checkHistoricAndPredictive(boolean hist, boolean pred) {
		if (!hist && !pred) {
			return false;
		}
		return true;
	}

	private List<String> getRegions() {
		List<String> regions = new ArrayList<>();
		regions.add("AF");
		regions.add("AN");
		regions.add("AS");
		regions.add("EU");
		regions.add("NA");
		regions.add("OC");
		regions.add("SA");
		return regions;
	}

	private void addCountries(List<String> inputCountries, List<Country> countries, boolean worldRegion) {
		if (inputCountries != null && worldRegion == false) {
			for (int i = 0; i < countries.size(); i++) {
				if (inputCountries.contains(countries.get(i).getCode())) {
					inputCountries.remove(countries.get(i).getCode());
				}
			}
			if (!inputCountries.isEmpty()) {
				countries.addAll(service.getCountries(inputCountries));
			}
		}
	}

	private List<UUID> getCountryUuids(List<Country> countries) {
		List<UUID> countryuuids = new ArrayList<>();
		for (int i = 0; i < countries.size(); i++) {
			countryuuids.add(countries.get(i).getUuid());
		}
		return countryuuids;
	}
}