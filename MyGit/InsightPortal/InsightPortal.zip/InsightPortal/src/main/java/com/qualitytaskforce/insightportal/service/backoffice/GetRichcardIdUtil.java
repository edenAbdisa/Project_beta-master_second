package com.qualitytaskforce.insightportal.service.backoffice;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.qualitytaskforce.insightportal.service.BrowserRichCardService;
import com.qualitytaskforce.insightportal.service.MobileDeviceRichCardService;

@Service
public class GetRichcardIdUtil {
	
	@Autowired
	BrowserRichCardService browserService;

	@Autowired
	MobileDeviceRichCardService mobileDeviceService;
	
	public UUID getRichcardId (String rcType, String rcBrand, String rcModel) {
		
		if (rcType.equals("browsers")) {
			UUID richcardId = browserService.getBrowserUuid(rcBrand, rcModel);
			return richcardId;
		} else if (rcType.equals("devices")) {
			UUID richcardId = mobileDeviceService.getDeviceUuid(rcBrand, rcModel);
			return richcardId;
		}
		return null;
	}
}
