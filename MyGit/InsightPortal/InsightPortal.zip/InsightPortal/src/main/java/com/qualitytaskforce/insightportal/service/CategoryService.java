package com.qualitytaskforce.insightportal.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.repository.CategoryRepository;
import com.qualitytaskforce.insightportal.util.SefURLToString;

@Service
public class CategoryService {

	@Autowired
	CategoryRepository categoryRepository;

	public Category save(Category category) {
		return categoryRepository.save(category);
	}	

	public void delete(Category category) {
		categoryRepository.delete(category);
	}
	
	public Category findByName (String categoryName){		
		String result = SefURLToString.sefUrlToString(categoryName);
		return categoryRepository.findByName(result);
	}
	
	public List<Category> getAllCategories(){
		return categoryRepository.findAll();
	}
}
