package com.qualitytaskforce.insightportal.jsoupcrawler;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ImagesParser {
	
	public static final Logger LOGGER = LoggerFactory.getLogger(ImagesParser.class);

	// public static void main(String[] args) throws IOException, InterruptedException {
	// getMakers();
	// getDevices();
	// getDetails();
	// }

	public void getMakers() throws IOException, InterruptedException {

		Document doc = Jsoup.connect("http://www.gsmarena.com/makers.php3").timeout(90000).get();
		Elements makers = doc.select("div[class=st-text]");
		Node makerNameNode;
		String makerName;
		String makerAddress;

		for (int o = 100; o < 109; o++) { // 4 amoi 108. ZTE ( Max )
			Element a = makers.select("td").get(o);
			makerNameNode = a.select("a").first().childNodes().get(0);
			makerName = makerNameNode.toString();
			makerAddress = a.select("a").get(0).absUrl("href");
			// System.out.println(i + ". " + makerName + " : " + makerAddress);
			getDevices(makerAddress, makerName, o);
		}
	}

	public void getDevices(String makerAddress, String makerName, int o)
			throws IOException, InterruptedException {

		Document docum = Jsoup.connect(makerAddress).timeout(90000).get();
		Elements devices = docum.select("div[class=makers]").select("ul");
		String deviceName;
		String deviceAddress;

		for (int i = 0; i < devices.select("li").size(); i++) {
			deviceAddress = devices.select("a").get(i).absUrl("href");
			deviceName = devices.select("li").get(i).text();
			// System.out.println(deviceName + " : " + deviceAddress);
			getDetails(deviceAddress, makerName, deviceName, i, o);
		}

		Elements moreDevices = docum.select("div[class=nav-pages]").select("a");
		for (Element a : moreDevices) {
			makerAddress = a.select("a").get(0).absUrl("href");
			Document restDocum = Jsoup.connect(makerAddress).timeout(6000).get();
			Elements restDevices = restDocum.select("div[class=makers]").select("ul");

			for (int i = 0; i < restDevices.select("li").size(); i++) {
				deviceAddress = restDevices.select("a").get(i).absUrl("href");
				deviceName = restDevices.select("li").get(i).text();
				// System.out.println(deviceName + " : " + deviceAddress);
				getDetails(deviceAddress, makerName, deviceName, i, o);
			}
		}
	}

	public void getDetails(String deviceAddress, String makerName, String deviceName, int i, int o)
			throws IOException, InterruptedException {

		Thread.sleep(500);

		Document document = Jsoup.connect(deviceAddress).timeout(90000).get();
		Elements elementary = document.select("ul[class=specs-spotlight-features]").select("li");

		DetailModel detailModel = new DetailModel();
		String brand = makerName;
		String model = deviceName;

		String imgLink =
				document.select("div[class=specs-photo-main]").select("img").attr("abs:src");
		String GENERALos = elementary.select("span[data-spec=os-hl]").text();
		String GENERALsize = elementary.select("span[data-spec=displaysize-hl]").text();
		String GENERALram = elementary.select("strong[class=accent accent-expansion]").text();
		String GENERALchipset = elementary.select("div[data-spec=chipset-hl]").text();
		String batteryDetails =
				document.select("tr").select("td[data-spec=batdescription1]").text();

		detailModel.setBrand(brand);
		detailModel.setModel(model);
		detailModel.setImgLink(imgLink);

		System.out.println("[" + o + "]  " + i + ". " + brand + " " + model + " " + GENERALsize
				+ " : " + GENERALos + " " + GENERALram + " " + GENERALchipset + " "
				+ batteryDetails);

		getImages(imgLink);

	}

	private static final String folderPath = "D:\\images";

	private static void getImages(String imgLink) throws IOException {
		// Exctract the name of the image from the src attribute
		int indexname = imgLink.lastIndexOf("/");
		if (indexname == imgLink.length()) {
			imgLink = imgLink.substring(1, indexname);
		}

		indexname = imgLink.lastIndexOf("/");
		String name = imgLink.substring(indexname, imgLink.length());

		URL url = new URL(imgLink);
		try (InputStream in = url.openStream();
				OutputStream out =
						new BufferedOutputStream(new FileOutputStream(folderPath + name))) {
			for (int b; (b = in.read()) != -1;) {
				out.write(b);
			}
		} catch (IOException e) {
			LOGGER.info("IOException: ", e);
		}

	}
}
