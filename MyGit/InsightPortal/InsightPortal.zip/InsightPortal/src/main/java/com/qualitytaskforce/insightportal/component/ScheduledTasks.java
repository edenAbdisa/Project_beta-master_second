package com.qualitytaskforce.insightportal.component;

import java.text.SimpleDateFormat;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.service.EmailServiceImpl;
import com.qualitytaskforce.insightportal.service.LoginAttemptService;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;

@Component
public class ScheduledTasks {

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduledTasks.class);
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
    private static final int SCHEDULE_TIME = (60000 * 60) * 6; // hour * 6
    
    @Autowired
    LoginAttemptService loginAttemptService;
    
    @Autowired
    UserService userService;
    
    @Autowired
 	private UserTrialService userTrialService;
    
    @Autowired
    UserLevelService userLevelService;
    
    @Autowired
 	private EmailServiceImpl emailService;

    @Scheduled(fixedRate = SCHEDULE_TIME)
    public void emailReminderDaemon() {
        
        // will check if trial && daysBeforeExpire 3 or 1 then send email
        LOGGER.info("emailReminderDaemon: {}", dateFormat.format(new Date()));
		// send remind emails only to AutomaticTrial users
		List<UserLevel> userlevelList = userLevelService.findByName("AutomaticTrial");
		UserLevel userLevel;
		if (!userlevelList.isEmpty()) {
			userLevel = userlevelList.get(0);
			List<User> userList = userService.findByUserLevel(userLevel);
			for (User u : userList) {
				checkTrialUsers(u);
			}
		}
    }
    
    
    void checkTrialUsers (User user) {
    	UserTrial userTrial = userTrialService.findByUser(user);
    	if (userTrial == null) {
			return;
		}
    	Date expireDate = userTrial.getExpireAt();
		 
		if (expireDate == null) {
			return;
		}
		
		Date now = new Date();
		long daysBeforeExpire = ChronoUnit.DAYS.between(now.toInstant(), expireDate.toInstant());				
		boolean isWarningPeriod = daysBeforeExpire >= 0 && daysBeforeExpire <= 2;
		boolean isExpired = expireDate.before(now);
		// DEV
		if (isWarningPeriod) {
			if (daysBeforeExpire == 2 && user.isActivated() && !userTrial.isSentTrialEmail()) {
				LOGGER.info("Send email: {} days to expire trial.", daysBeforeExpire);
				sendReminderEmail(daysBeforeExpire, user.getEmail(), user);
				userTrial.setSentTrialEmail(true);
				userTrialService.save(userTrial);
			} else if (daysBeforeExpire == 0 && user.isActivated() && userTrial.isSentTrialEmail()) {
				LOGGER.info("Send email: {} days to expire trial.", daysBeforeExpire);
				sendReminderEmail(daysBeforeExpire, user.getEmail(), user);
				userTrial.setSentTrialEmail(false);
				userTrialService.save(userTrial);
			}
		} else if (isExpired) {
			user.setBlocked(true);
			userTrial.setSentTrialEmail(false);
			userService.save(user);
		}
    }
    
    
    void sendReminderEmail (long days, String email, User user) {
    	// +1
    	String emailFrom = "contactus@insightportal.io";
    	String emailTitle = "InsightPortal - Trial expiry";
    	
    	String devBody = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\r\n" + 
    			"<html xmlns=\"http://www.w3.org/1999/xhtml\">\r\n" + 
    			"<head>\r\n" + 
    			"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n" + 
    			"</head>\r\n" + 
    			"<body style=\"margin: 0; padding: 0; min-width: 100%!important;\">\r\n" + 
    			"<table width=\"100%\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\r\n" + 
    			"<tr>\r\n" + 
    			"<td>\r\n" + 
    			"<table cellpadding=\"0\" align=\"center\" style=\"width: 100%; max-width: 600px;\">\r\n" + 
    			"<td align=\"center\">\r\n" + 
    			"<a href=\"https://s3-eu-west-1.amazonaws.com/insightportal/images/header/logo.png\" target=\"_blank\"><img alt=\"insightportal logo\" title=\"\" width=\"180\" height=\"auto\" src=\"https://s3-eu-west-1.amazonaws.com/insightportal/images/header/logo.png\" style=\"\"></img></a>\r\n" + 
    			"</td>\r\n" + 
    			"<tr>\r\n" + 
    			"<td style=\"padding-bottom: 20px;\">\r\n" + 
    			"Dear  " + user.getNameAndSurname() + ",\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"<tr>\r\n" + 
    			"<td>\r\n" + 
    			"</td>\r\n" + 
    			"</tr>";
    			
    	
    	String emailContent = "";
    	if (days == 2) {
        	emailContent = "<tr>\r\n" + 
        			"<td style=\"padding-bottom: 20px;\">\r\n" + 
        			"You only have 3 days remaining on your InsightPortal trial. If you would like to continue using InsightPortal you need a subscription package. Please contact us by replying to this email if you would like to receive more information about our subscription packages and pricing.	\r\n" + 
        			"</td>\r\n" + 
        			"</tr>";
    	} else if (days == 0) {
    		// expireTime = "today.";
        	emailContent = "<tr>\r\n" + 
        			"<td style=\"padding-bottom: 20px;\">\r\n" + 
        			"Time flies when you're having fun! Your InsightPortal trial is ending today. We hope you love our product and want to continue using it.\r\n" + 
        			"</td>\r\n" + 
        			"</tr>\r\n" + 
        			"<tr>\r\n" + 
        			"<td style=\"padding-bottom: 20px;\">\r\n" + 
        			"Please contact us by replying to this email or calling us on +48 713 072 006 to receive more information about our subscription packages and pricing.\r\n" + 
        			"</td>\r\n" + 
        			"</tr>";
    	}

    	String endOfEmail = "<tr>\r\n" + 
    			"<td style=\"padding-bottom: 20px;\">\r\n" + 
    			"Best Regards,\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"<tr>\r\n" + 
    			"<td>\r\n" + 
    			"Your InsightPortal Team.\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"<tr>\r\n" + 
    			"<td>\r\n" + 
    			"contactus@insightportal.io\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"<tr>\r\n" + 
    			"<td>\r\n" + 
    			"ul. Swietego Mikolaja 8-11\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"<tr>\r\n" + 
    			"<td>\r\n" + 
    			"<a href=\"tel:+48 713 072 006\">+48 713 072 006</a>\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"</table>\r\n" + 
    			"</td>\r\n" + 
    			"</tr>\r\n" + 
    			"</table>\r\n" + 
    			"</body>\r\n" + 
    			"</html>";
    	
    	devBody += emailContent + endOfEmail;
    	
        emailService.sendEmail(emailFrom, email, emailTitle, devBody);
    }
}