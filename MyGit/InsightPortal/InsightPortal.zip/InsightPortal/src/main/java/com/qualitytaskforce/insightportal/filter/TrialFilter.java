package com.qualitytaskforce.insightportal.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.HiddenHttpMethodFilter;

public class TrialFilter extends HiddenHttpMethodFilter {

	private UserService userService;
	
	private UserTrialService userTrialService;
	
	private UserLevelService userLevelService;
	
	@Override
	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
				
		Object emailOrUser = null;
		String email = "";
		
		// At some point getPrincipal can return either an email or a List containing the User object
		try {
			emailOrUser = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			if (emailOrUser instanceof ArrayList<?>) {
				email = ((ArrayList<User>) emailOrUser).get(0).getEmail();
			} else {
				email = emailOrUser.toString();
			}
		} catch (NullPointerException e) {
			modifyResponse(response, 401, "Unauthorized", "This path requires authentication.");
			return;
		}

		manualAutowire(request);
		List<User> userList = userService.findByEmail(email);
		if (userList.isEmpty()) {
			modifyResponse(response, 404, "Not found", "User with such email not found.");
			return;
		}
		
		// Check trial expire, if true set response and return;
		User user = userList.get(0);
		UserLevel userLevel = user.getUserLevel();
		String userLevelName = userLevel.getName(); 
		if (userLevelName.equals("AutomaticTrial")) {
			checkExpireTrial(response, user);
		}
		
		chain.doFilter(request, response);
	}

		
	private void manualAutowire(HttpServletRequest request) {
		if (userService == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			userService = webApplicationContext.getBean(UserService.class);
		}
		
		if (userTrialService == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			userTrialService = webApplicationContext.getBean(UserTrialService.class);
		}
		
		if (userLevelService == null) {
			ServletContext servletContext = request.getServletContext();
			WebApplicationContext webApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);
			userLevelService = webApplicationContext.getBean(UserLevelService.class);
		}
	}
	
	void checkExpireTrial (HttpServletResponse response, User user) throws IOException {
		UserTrial userTrial = userTrialService.findByUser(user);
		Date now = new Date();
		Date expireDate = userTrial.getExpireAt();
		boolean isExpired = expireDate.before(now);
		if (isExpired) {
			setUserBlocked(user, userTrial);
			modifyResponse(response, 403, "Forbidden", "Trial has been expired.");
			return;
		}
	}
	
	void setUserBlocked(User user, UserTrial userTrial) {
		user.setBlocked(true);
		userService.save(user);
		
		userTrial.setSentTrialEmail(false);
		userTrialService.save(userTrial);
		
	}
	
	void modifyResponse (HttpServletResponse response, int status, String error, String message) throws IOException {
		String responseText = "{\"timestamp\": " + System.currentTimeMillis() 
								+ ", \"status\": " + String.valueOf(status) + " "
								+ ", \"error\": \"" + error + "\"" 
								+ ", \"message\": \"" + message + "\""
								+ "}";

		response.reset();
		response.setContentType("application/json;charset=UTF-8");
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setStatus(status);
		response.getWriter().write(responseText);
		response.getWriter().flush();
		response.getWriter().close();
	}
}