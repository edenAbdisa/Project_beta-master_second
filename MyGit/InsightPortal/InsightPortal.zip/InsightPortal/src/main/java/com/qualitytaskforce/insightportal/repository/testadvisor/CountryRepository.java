package com.qualitytaskforce.insightportal.repository.testadvisor;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.qualitytaskforce.insightportal.model.testadvisor.Country;

public interface CountryRepository extends JpaRepository<Country, Long> {

	@Query(value = "SELECT * FROM ta_countries "
				+ "WHERE code IN :codes "
				+ "AND desktop_users > 0"
				, nativeQuery = true)
	List<Country> getCountries(@Param("codes") List<String> codes);

	@Query(value = "SELECT * FROM ta_countries "
				+ "WHERE region IN :regions "
				+ "AND desktop_users > 0"
				, nativeQuery = true)
	List<Country> getCountriesByRegion(@Param("regions") List<String> regions);

	@Query(value = "SELECT * FROM ta_countries "
				+ "WHERE desktop_users > 0"
				, nativeQuery = true)
	List<Country> getAllCountries();

	@Query(value = "SELECT region FROM ta_countries "
				+ "WHERE desktop_users > 0 "
				+ "GROUP BY region"
				, nativeQuery = true)
	List<String> getAllRegions();

}