package com.qualitytaskforce.insightportal.service;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.RelatedArticles;
import com.qualitytaskforce.insightportal.repository.RelatedArticlesRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RelatedArticlesService {

	@Autowired
	RelatedArticlesRepository relatedArticlesRepository;
	
	public void save(RelatedArticles relatedArticles) {
		relatedArticlesRepository.save(relatedArticles);
	}
	
	public List<RelatedArticles> findByArticle(Article article){		
		return relatedArticlesRepository.findByArticleByOriginalArticleId(article);
	}
	
	public void deleteRelatedArticlesList(List<RelatedArticles> relatedArticles) {
		relatedArticlesRepository.delete(relatedArticles);
	}
}
