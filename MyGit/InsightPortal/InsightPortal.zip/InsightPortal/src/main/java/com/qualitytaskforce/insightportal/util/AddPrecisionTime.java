package com.qualitytaskforce.insightportal.util;

import java.util.Calendar;
import java.util.Date;

public class AddPrecisionTime {
	public Date add (Date expireAt, Date lastExpireAt) {
		
    	// set start of date
    	Calendar c = Calendar.getInstance(); 
		c.setTime(lastExpireAt);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		c.set(Calendar.MILLISECOND, 0);
		
		long millis = (lastExpireAt.getTime() - c.getTimeInMillis()); // 12:50:20 in millis
		Calendar ca = Calendar.getInstance(); 
		ca.setTime(expireAt);
		// add hours:minuts:seconds to date, as millis
		ca.setTimeInMillis(ca.getTimeInMillis() + millis); // 00:00:00 + 12:50:20 in millis
		Date modifiedExpireAt = ca.getTime();
		return modifiedExpireAt;
    }
}
