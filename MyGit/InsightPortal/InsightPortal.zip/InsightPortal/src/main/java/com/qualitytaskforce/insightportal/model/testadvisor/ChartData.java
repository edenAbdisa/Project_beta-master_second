package com.qualitytaskforce.insightportal.model.testadvisor;

import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class ChartData {
	
	@Id
	private UUID uuid;

	@Column(name = "name")
	private String name;

	@Column(name = "marketpen")
	private float marketPen;

	public ChartData () {
	}

	public ChartData(String name, float marketPen) {
		this.name = name;
		this.marketPen = marketPen;
	}

	public ChartData(UUID uuid, String name, float marketPen) {
		this.uuid = uuid;
		this.name = name;
		this.marketPen = marketPen;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public float getMarketPen() {
		return this.marketPen;
	}

	public void setMarketPen(float marketPen) {
		this.marketPen = marketPen;
	}
}