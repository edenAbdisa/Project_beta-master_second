package com.qualitytaskforce.insightportal.model.post;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RelatedArticlesRequest {
	
	@JsonProperty("uuid")
	UUID uuid;

	@JsonProperty("categoryName")
	String categoryName;		
	
	@JsonProperty("fullText")
	String fullText;

	public UUID getUuid() {
		return uuid;
	}

	public void setUuid(UUID uuid) {
		this.uuid = uuid;
	}
	
	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	public String getFullText() {
		return fullText;
	}

	public void setFullText(String fullText) {
		this.fullText = fullText;
	}
	
}