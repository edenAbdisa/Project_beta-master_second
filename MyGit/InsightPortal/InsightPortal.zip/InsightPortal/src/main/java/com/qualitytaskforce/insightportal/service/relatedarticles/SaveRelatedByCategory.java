package com.qualitytaskforce.insightportal.service.relatedarticles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.qualitytaskforce.insightportal.model.Article;
import com.qualitytaskforce.insightportal.model.Category;
import com.qualitytaskforce.insightportal.model.RelatedArticles;
import com.qualitytaskforce.insightportal.service.ArticleService;
import com.qualitytaskforce.insightportal.service.CategoryService;
import com.qualitytaskforce.insightportal.service.RelatedArticlesService;
import com.qualitytaskforce.insightportal.util.CalculateRelated;
import com.qualitytaskforce.insightportal.util.HtmlToString;
import com.qualitytaskforce.insightportal.util.SortMap;

@Service
public class SaveRelatedByCategory {
	
	@Autowired
    private ArticleService articleService;
	
	@Autowired
	private CategoryService categoryService;
	 
	@Autowired
	private RelatedArticlesService relatedArticlesService;	
	
	@Transactional
	public void saveRelated (String categoryName) {
		
		/*
         * [1 step] Method search all articles by category (and store in list)
         * [2 step] And in next step calculate a related articles for each of article in list
         *
         */		
		
		Category category = categoryService.findByName(categoryName);
        List<Article> listOfArticles = articleService.findByCategory(category);

        RelatedArticles relatedArticles = new RelatedArticles();
        List<Double> relatedList = new ArrayList<Double>();

        for (int i = 0; i < listOfArticles.size(); i++) {
            for (int j = 0; j < listOfArticles.size(); j++) {
                if (i != j) {


                    String typeOfAnalize = "fullText";
                    String s1 = "";
                    String s2 = "";

                    if (typeOfAnalize.equals("fullText")) {
                        s1 = listOfArticles.get(i).getFullText();
                        s1 = HtmlToString.convert(s1);
                        s2 = listOfArticles.get(j).getFullText();
                        s2 = HtmlToString.convert(s2);
                    } else {
                        s1 = listOfArticles.get(i).getTitle();
                        s2 = listOfArticles.get(j).getTitle();
                    }

                    double relate = CalculateRelated.diceCoefficient(s1, s2);

                    relatedList.add(relate);

                    /*
                     * When we have coef. for all articles in our category
                     * we check if exist related articles for our article
                     *
                     * so --> Create new RelatedArticles object or Update
                     * exist by uuid Article
                     *
                     */

                } else if (j != listOfArticles.size() - 1) {
                    relatedList.add(
                            -1.0); /*
                     * Must be smth less of 0.0 to eliminate
                     * position of viewed element
                     */
                } // end if(i!=j)

               
                if (j == listOfArticles.size() - 1) {
                    // LOG.info(Arrays.deepToString(relatedList.toArray(new
                    // Double[0])));
                    // LOG.info(listOfArticles.get(i).getTitle().toString());

                    /*
                     * TODO Make decision if we need check exist related
                     * articles for out article - NOT REQUIRED
                     */
                    //RelatedArticles relArticles = relatedArticlesService.findByArticle(listOfArticles.get(i));
                    //if (relArticles == null) {
                    //	relatedArticles = new RelatedArticles();
                    //} else {
                    //	relatedArticles = relArticles;
                    //}

                    //relatedArticles.setArticleByOriginalArticleId(listOfArticles.get(i));

                    Map<Integer, Double> map = new HashMap<>();
                    for (int m = 0; m < relatedList.size(); m++) {
                        map.put(m, relatedList.get(m));
                    }

                    List<Map.Entry<Integer, Double>> srt = SortMap.entriesSortedByValues(map);
                    List<Integer> sortedList = new ArrayList<>();

                    int maxOfRelated = 10;
                    if (relatedList.size() < 10) {
                        maxOfRelated = relatedList.size();
                    }


                    for (int f = 0; f < maxOfRelated; f++) {
                        sortedList.add(srt.get(f).getKey());
                    }
                    /*
                     * Example : Result of sort for : New browser
                     * Mozilla Firefox 5611 <-- this New browser Mozilla
                     * Firefox 57 New browser Mozilla Firefox 581 New
                     * browser Mozilla Firefox 5
                     *
                     * [0.9333333333333333, 0.9180327868852459,
                     * 0.9491525423728814] [2, 0, 1]
                     *
                     */

                    //LOG.info("Sorted list : {}", Arrays.deepToString(sortedList.toArray(new Integer[0])));

                    for (int k = 0; k < sortedList.size(); k++) {

                        relatedArticles = new RelatedArticles();
                        relatedArticles.setArticleByOriginalArticleId(listOfArticles.get(i));
                        relatedArticles.setArticleByRelatedArticle(listOfArticles.get(sortedList.get(k)));

                        relatedArticlesService.save(relatedArticles);
                        //LOG.info(listOfArticles.get(sortedList.get(k)).getTitle());

                    }
                    /* Before end of i-loop clear relatedList */
                    relatedList.clear();
                }

            } // end j
        } // end i
	}
}
