package com.qualitytaskforce.insightportal.model.response;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import com.qualitytaskforce.insightportal.model.Article;

public class SearchArticleResponse {
	
	public class SearchArticle {
		
		private UUID uuid;
		private String title;
		private String summaryText;

		public SearchArticle(Article article) {
			this.uuid = article.getUuid();
			this.title = article.getTitle();
			this.summaryText = article.getSummaryText();
		}

		public UUID getUuid() {
			return uuid;
		}

		public void setUuid(UUID uuid) {
			this.uuid = uuid;
		}

		public String getTitle() {
			return title;
		}

		public void setTitle(String title) {
			this.title = title;
		}

		public String getSummaryText() {
			return summaryText;
		}

		public void setSummaryText(String summaryText) {
			this.summaryText = summaryText;
		}
	}

	private List<SearchArticle> foundArticles;

	public SearchArticleResponse() {
		foundArticles = new ArrayList<>();
	}

	public SearchArticleResponse(List<Article> articles) {
		this();
		List<SearchArticle> searchArticles = articles.stream().map(article -> new SearchArticle(article))
				.collect(Collectors.toList());
		this.foundArticles.addAll(searchArticles);
	}

	public List<SearchArticle> getFoundArticles() {
		return foundArticles;
	}

	public void setFoundArticles(List<SearchArticle> foundArticles) {
		this.foundArticles = foundArticles;
	}
}
