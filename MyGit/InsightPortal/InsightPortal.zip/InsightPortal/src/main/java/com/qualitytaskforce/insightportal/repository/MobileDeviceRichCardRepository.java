package com.qualitytaskforce.insightportal.repository;

import java.util.List;
import java.util.UUID;

import com.qualitytaskforce.insightportal.model.MobileDeviceRichCard;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MobileDeviceRichCardRepository extends JpaRepository<MobileDeviceRichCard, UUID> {

	@Query(value = "SELECT DISTINCT brand FROM ta_devices " 
			+ "ORDER BY brand ASC"
			, nativeQuery = true)
	List<String> getDeviceBrands();

	@Query(value = "SELECT model FROM ta_devices "
			+ "WHERE brand = :choosenBrand ORDER BY model ASC"
			, nativeQuery = true)
	List<String> getDeviceModels(@Param("choosenBrand") String choosenBrand);
	
	@Query(value = "SELECT *, "
			+ "LOWER(CONCAT(" 
			+ "SUBSTR(HEX(uuid), 1, 8), '-'," 
			+ "SUBSTR(HEX(uuid), 9, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 13, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 17, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 21)" 
			+ ")) FROM ta_devices "
			 + "WHERE brand = :choosenBrand AND model = :model ORDER BY model DESC LIMIT 1"
//			 + "WHERE brand = :choosenBrand ORDER BY model ASC"
		     , nativeQuery = true)
	MobileDeviceRichCard getDeviceModelx(@Param("choosenBrand") String choosenBrand, @Param("model") String model);

	@Query(value = "SELECT LOWER(CONCAT(" 
			+ "SUBSTR(HEX(uuid), 1, 8), '-'," 
			+ "SUBSTR(HEX(uuid), 9, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 13, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 17, 4), '-'," 
			+ "SUBSTR(HEX(uuid), 21)" 
			+ ")) FROM ta_devices "
			+ "WHERE brand = :choosenBrand AND model = :model ORDER BY model DESC LIMIT 1"
			, nativeQuery = true)
	String getDeviceUuid(@Param("choosenBrand") String brand, @Param("model") String model);
	
	MobileDeviceRichCard findByUuid(UUID uuid);
}