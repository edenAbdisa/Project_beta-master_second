package com.qualitytaskforce.insightportal.controller.users;

import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.bohnman.squiggly.Squiggly;
import com.github.bohnman.squiggly.util.SquigglyUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.qualitytaskforce.insightportal.model.users.UserLevel;
import com.qualitytaskforce.insightportal.model.post.JsonUserLevel;
import com.qualitytaskforce.insightportal.service.users.UserLevelService;

@RestController
@RequestMapping(value = "/userlevels")
public class UserLevelController {

	@Autowired
	private UserLevelService service;

	@RequestMapping(value = "", method = RequestMethod.GET)
	public @ResponseBody ResponseEntity<?> index(@RequestParam(value = "fields", defaultValue = "**") String queryParameters) {
		ObjectMapper objectMapper = Squiggly.init(new ObjectMapper(), queryParameters);
		List<UserLevel> userLevels = service.findAll();
		return new ResponseEntity<>(SquigglyUtils.stringify(objectMapper, userLevels), HttpStatus.OK);
	}

	@RequestMapping(value = "/create", method = RequestMethod.POST)
	public ResponseEntity<String> create(@RequestBody JsonUserLevel input) {
		String response;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

		List<UserLevel> existing = service.findByName(input.getName());

		if (!input.checkRequiredNull()) {
			response = "{\"timestamp\": " + System.currentTimeMillis() 
									+ ", \"status\": 400 "
									+ ", \"error\": \"Bad Request\"" 
									+ ", \"message\": \"One or more required variables are missing.\""
									+ "}";

			return new ResponseEntity<String>(response, headers, HttpStatus.BAD_REQUEST);
		}

		if (!existing.isEmpty()) {
			response = "{\"timestamp\": " + System.currentTimeMillis() 
									+ ", \"status\": 422 "
									+ ", \"error\": \"Unprocessable Entity\"" 
									+ ", \"message\": \"A userlevel with that name already exists.\""
									+ "}";

			return new ResponseEntity<String>(response, headers, HttpStatus.UNPROCESSABLE_ENTITY);
		}

		if (!input.checkPermissionPattern()) {
			response = "{\"timestamp\": " + System.currentTimeMillis() 
									+ ", \"status\": 422 "
									+ ", \"error\": \"Unprocessable Entity\"" 
									+ ", \"message\": \"Permissions not set correctly.\""
									+ "}";

			return new ResponseEntity<String>(response, headers, HttpStatus.UNPROCESSABLE_ENTITY);
		}

		UserLevel userLevel = new UserLevel(UUID.randomUUID(), input.getName(), input.getPermissions());
		service.save(userLevel);

		response = "{\"timestamp\": " + System.currentTimeMillis() 
									+ ", \"status\": 201 "
									+ ", \"error\": \"Created\"" 
									+ ", \"message\": \"UserLevel has successfully been created.\""
									+ "}";

		return new ResponseEntity<String>(response, headers, HttpStatus.CREATED);
	}
}