package com.qualitytaskforce.insightportal.controller.users;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.qualitytaskforce.insightportal.error.DataNotFoundException;
import com.qualitytaskforce.insightportal.error.InvalidParameterFormatException;
import com.qualitytaskforce.insightportal.model.post.JsonUser;
import com.qualitytaskforce.insightportal.model.put.JsonUpdateUser;
import com.qualitytaskforce.insightportal.model.put.UserCredentialsChange;
import com.qualitytaskforce.insightportal.model.response.ApiResponse;
import com.qualitytaskforce.insightportal.model.users.ApiKey;
import com.qualitytaskforce.insightportal.model.users.PasswordResets;
import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.users.UserLogging;
import com.qualitytaskforce.insightportal.model.users.UserTrial;
import com.qualitytaskforce.insightportal.model.util.EmailValidator;
import com.qualitytaskforce.insightportal.model.util.UserJoomlaCredentials;
import com.qualitytaskforce.insightportal.model.util.UserLoggingAction;
import com.qualitytaskforce.insightportal.service.ManagePasswordEmailService;
import com.qualitytaskforce.insightportal.service.MessageUtil;
import com.qualitytaskforce.insightportal.service.PasswordResetsService;
import com.qualitytaskforce.insightportal.service.users.ApiKeyService;
import com.qualitytaskforce.insightportal.service.users.UserLoggingService;
import com.qualitytaskforce.insightportal.service.users.UserService;
import com.qualitytaskforce.insightportal.service.users.UserTrialService;
import com.qualitytaskforce.insightportal.service.users.backoffice.UserServicePost;
import com.qualitytaskforce.insightportal.service.users.backoffice.UserServicePut;

@RestController
@RequestMapping(value = "/user")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private UserLoggingService userLoggingService;

    @Autowired
    private ApiKeyService apiKeyService;

    @Autowired
    private MessageUtil util;
    
    @Autowired
    private ManagePasswordEmailService managePasswordEmailService;   
    
    @Autowired
    private PasswordResetsService passwordResetsService;
    
    @Autowired
	UserTrialService userTrialService;
    
    @Autowired
	UserServicePost userServicePost;
    
    @Autowired
	UserServicePut userServicePut;
    
    private HttpHeaders headers = new HttpHeaders();

    
    Map<String, Object> getUsersTrialsMap (List<User> users) {
    	List<Map<?,?>> mapList = new ArrayList<Map<?,?>>();
    	for (User u : users) {
            u.setPassword(null);
            UserTrial userTrial = userTrialService.findByUser(u);
            if (userTrial != null) {
            	Map<String, String> emailMap = new HashMap<String, String>();
            	emailMap.put("email", u.getEmail());
            	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            	String expireAtString = df.format(userTrial.getExpireAt());
            	emailMap.put("expireAt", expireAtString);
            	mapList.add(emailMap);
            }
        }
        
    	Map<String, Object> output = new HashMap<String, Object>();
        output.put("users", users);
        output.put("trials", mapList);
        return output;
    }
    
    
    @RequestMapping(value = "", method = RequestMethod.GET)
    public ResponseEntity<?> get(HttpServletRequest request) {
        List<User> users = userService.getAllUsers();
        
        Map<String, Object> output = getUsersTrialsMap(users);
        
        return new ResponseEntity<Map<String, Object>>(output, headers, HttpStatus.OK);
    }
    
    @RequestMapping(value = "", method = RequestMethod.POST)
    public ResponseEntity<String> create(@Valid @RequestBody JsonUser inputDetails, HttpServletRequest request, HttpServletResponse response) throws Exception {
        String resp;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        userServicePost.create(inputDetails, util, request, response);
        
        resp = util.getMessage("success.users.create");
        return new ResponseEntity<String>(resp, headers, HttpStatus.CREATED);
    }
    
    @RequestMapping(value = "{uuid}", method = RequestMethod.PUT)
    public ResponseEntity<?> update(@Valid @RequestBody JsonUpdateUser inputDetails, @PathVariable("uuid") UUID uuidUser, HttpServletRequest request) throws Exception {
        String response;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        
        userServicePut.update(inputDetails, uuidUser);
        
        response = util.getMessage("success.users.create");
        return new ResponseEntity<String>(response, headers, HttpStatus.CREATED);
    }

    @RequestMapping(value = "/{uuid}", method = RequestMethod.GET)
    public ResponseEntity<?> getOne(@PathVariable UUID uuid, HttpServletRequest request, HttpServletResponse response) throws Exception {
        User user = userService.findByUUID(uuid);
        // User password should never leave the database, do not send it to front-end ever.
        user.setPassword(null);
        Map<String, Object> objectMap = new HashMap<>();

        UserTrial userTrial = userTrialService.findByUser(user);
        
        ApiKey apiKey = apiKeyService.findByUser(user).get(0);
        objectMap.put("api_key_limit", apiKey.getApiLimit().getName());
        objectMap.put("user", user);
        if (userTrial != null) {
        	Date expireAt = userTrial.getExpireAt();
        	DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			String expireAtString = df.format(expireAt);
        	objectMap.put("expire_at", expireAtString);
        }
        
        return new ResponseEntity<>(objectMap, headers, HttpStatus.OK);
    }

    @RequestMapping(value = "/changepasswordexternal", method = RequestMethod.POST)
    public ResponseEntity<String> changePassword(@RequestBody UserJoomlaCredentials credentials) {
        User user = userService.findByEmail(credentials.getEmail()).get(0);

        String currentPassword = credentials.getOldPassword();
        String newPassword = credentials.getPassword();
        String oldPassword = user.getPassword();

        String response;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        /* Return 403 error if the old password entered by the user does not match the actual password */
        if (!BCrypt.checkpw(currentPassword, oldPassword)) {
            response = "{\"timestamp\": " + System.currentTimeMillis()
                    + ", \"status\": 403 "
                    + ", \"error\": \"Forbidden\""
                    + ", \"message\": \"Incorrect password.\""
                    + "}";
            return new ResponseEntity<String>(response, headers, HttpStatus.FORBIDDEN);
        }

        /* Return 401 error if the new password is the same as the old one */
        if (BCrypt.checkpw(newPassword, oldPassword)) {
            response = "{\"timestamp\": " + System.currentTimeMillis()
                    + ", \"status\": 400 "
                    + ", \"error\": \"Bad request\""
                    + ", \"message\": \"New password must be different from the old one.\""
                    + "}";
            return new ResponseEntity<String>(response, headers, HttpStatus.BAD_REQUEST);
        }

        response = "{\"timestamp\": " + System.currentTimeMillis()
                + ", \"status\": 200 "
                + ", \"error\": \"Success\""
                + ", \"message\": \"The password has been successfully changed.\""
                + "}";

        user.setPassword(BCrypt.hashpw(newPassword, BCrypt.gensalt(10)));
        userService.save(user);
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        return new ResponseEntity<String>(response, headers, HttpStatus.OK);
    }

    @RequestMapping(value = "/change-password", method = RequestMethod.PUT)
    public ResponseEntity<String> changePassword(@RequestBody UserCredentialsChange userCredentialsChange, HttpServletRequest request) {
        User user = userService.findByEmail(userCredentialsChange.getEmail()).get(0);
        String oldPassword = user.getPassword();

        String response;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);

        /* Return 403 error if the old password entered by the user does not match the actual password */
        if (!BCrypt.checkpw(userCredentialsChange.getCurrentPassword(), oldPassword)) {
            response = "{\"timestamp\": " + System.currentTimeMillis()
                    + ", \"status\": 403 "
                    + ", \"error\": \"Forbidden\""
                    + ", \"message\": \"Incorrect old password.\""
                    + "}";
            return new ResponseEntity<String>(response, headers, HttpStatus.FORBIDDEN);
        }

        /* Return 401 error if the new password is the same as the old one */
        if (BCrypt.checkpw(userCredentialsChange.getNewPassword(), oldPassword)) {
            response = "{\"timestamp\": " + System.currentTimeMillis()
                    + ", \"status\": 400 "
                    + ", \"error\": \"Bad request\""
                    + ", \"message\": \"New password must be different from the old one.\""
                    + "}";
            return new ResponseEntity<String>(response, headers, HttpStatus.BAD_REQUEST);
        }

        response = "{\"timestamp\": " + System.currentTimeMillis()
                + ", \"status\": 200 "
                + ", \"error\": \"Success\""
                + ", \"message\": \"The password has been successfully changed.\""
                + "}";

        user.setPassword(BCrypt.hashpw(userCredentialsChange.getNewPassword(), BCrypt.gensalt(10)));
        userService.save(user);

        String ip = userLoggingService.getClientIP(request);
        userLoggingService.saveUserLog(userCredentialsChange.getEmail(), ip, UserLoggingAction.CHANGE_PASSWORD);

        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        return new ResponseEntity<String>(response, headers, HttpStatus.OK);
    }
    
    @PostMapping("/is-user-exist")
    public ResponseEntity<?> isUserWithEmailExist (@RequestBody Map<String,String> emailObj) throws InvalidParameterFormatException {
    	
    	Map<String,String> map = emailObj;
    	String userEmail = map.get("email");    	
    	EmailValidator ev = new EmailValidator(userEmail);    	
    	if (!ev.validateEmail()) {
            throw new InvalidParameterFormatException(util.getMessage("error.users.create.invalid-email"));
        }
    	 
    	String response, errorResponse;
    	String message = "User with this email not found.";
    	headers.setContentType(MediaType.APPLICATION_JSON_UTF8);    	
    	errorResponse = "{\"timestamp\": " + System.currentTimeMillis()
			        + ", \"status\": 400 "
			        + ", \"error\": \"Bad request\""
			        + ", \"message\": \"" + message + "\""
			        + "}";
    	
    	
        List<User> existingUser = userService.findByEmail(userEmail);
        if (existingUser.size() < 1) {
        	return new ResponseEntity<String>(errorResponse, headers, HttpStatus.BAD_REQUEST);        
        } else {
	    	String[] resetcodeAndToken = passwordResetsService.generateAndSaveResetcodeAndToken(userEmail, "reset");
    		String resetcode = resetcodeAndToken[0];
    		String token = resetcodeAndToken[1];
	    	
    		managePasswordEmailService.sendResetPasswordEmail(userEmail, resetcode, token);
	    	
        }
        
        response = "{\"timestamp\": " + System.currentTimeMillis()
		        + ", \"status\": 200 "
		        + ", \"error\": \"Success\""
		        + ", \"message\": \"Email sent with success.\""
		        + "}";    	
    	return new ResponseEntity<String>(response, headers, HttpStatus.OK);
    }
    
    
    @PostMapping("/verify-reset-token")
    public ResponseEntity<?> verifyAction (@RequestBody Map<String,String> tokenObj) throws Exception {
    	
    	String token = tokenObj.get("token");
    	boolean isTokenActive = passwordResetsService.verifyTokenActivity(token);
    	if (!isTokenActive) {
    		throw new Exception("Current token is wrong");
    	}
    	
    	return new ResponseEntity<Boolean>(isTokenActive, HttpStatus.OK);
    }
    
    @PutMapping("/reset-password")
    public ResponseEntity<String> resetPassword(HttpServletRequest request, @RequestBody Map<String,String> userCredentialsWithToken) throws DataNotFoundException {
        
    	List<User> userList = userService.findByEmail(userCredentialsWithToken.get("email"));
    	if (userList.size() < 1) {
    		throw new DataNotFoundException("Wrong email.");
    	}
    	User user = userList.get(0) ;
    	
    	String resetcode = userCredentialsWithToken.get("validationCode");
        String newPassword = userCredentialsWithToken.get("newPassword");
    	String oldPassword = user.getPassword();

        String response;
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        
        PasswordResets passwordress = passwordResetsService.findByResetcode(resetcode);
        /* Return 403 error if the reset code entered by the user exist in db */
        if (passwordress == null) {
            response = "{\"timestamp\": " + System.currentTimeMillis()
                    + ", \"status\": 403 "
                    + ", \"error\": \"Forbidden\""
                    + ", \"message\": \"Incorrect validation code.\""
                    + "}";
            return new ResponseEntity<String>(response, headers, HttpStatus.FORBIDDEN);
        }

        /* Return 401 error if the new password is the same as the old one */
        if (BCrypt.checkpw(newPassword, oldPassword)) {
            response = "{\"timestamp\": " + System.currentTimeMillis()
                    + ", \"status\": 400 "
                    + ", \"error\": \"Bad request\""
                    + ", \"message\": \"New password must be different from the old one.\""
                    + "}";
            return new ResponseEntity<String>(response, headers, HttpStatus.BAD_REQUEST);
        }

        response = "{\"timestamp\": " + System.currentTimeMillis()
                + ", \"status\": 200 "
                + ", \"error\": \"Success\""
                + ", \"message\": \"The password has been successfully changed.\""
                + "}";

        user.setPassword(BCrypt.hashpw(newPassword, BCrypt.gensalt(10)));
        try {
        	userService.save(user);
        } catch (Exception e) {
        	e.getMessage();
        } finally {
        	passwordress.setActive(false);
        	passwordResetsService.save(passwordress);
        }

        String ip = userLoggingService.getClientIP(request);
        userLoggingService.saveUserLog(userCredentialsWithToken.get("email"), ip, UserLoggingAction.CHANGE_PASSWORD);

        return new ResponseEntity<String>(response, headers, HttpStatus.OK);
    }

    @PutMapping("/{uuid}/block")
    public ResponseEntity<?> block(@PathVariable("uuid") UUID uuid, HttpServletRequest request) throws DataNotFoundException {
        if (uuid == null){
            return new ResponseEntity<>(new ApiResponse("error", "User has been not selected."), headers, HttpStatus.BAD_REQUEST);
        }
            if (!userService.block(uuid)){
                throw new DataNotFoundException(new ApiResponse("error", "This user not exist").toString());
            }

        ApiResponse response = new ApiResponse("success", "User has been blocked.");

        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }

    @PutMapping("/{uuid}/unblock")
    public ResponseEntity<?> unblock(@PathVariable("uuid") UUID uuid, HttpServletRequest request) throws DataNotFoundException {
        if (uuid == null){
            return new ResponseEntity<>(new ApiResponse("error", "User has been not selected."), headers, HttpStatus.BAD_REQUEST);
        }
        if (!userService.unblock(uuid)) {
            throw new DataNotFoundException(new ApiResponse("error", "This user not exist").toString());
        }

        ApiResponse response = new ApiResponse("success", "The user has been unblocked");

        return new ResponseEntity<>(response, headers, HttpStatus.OK);
    }
    
    @PostMapping("/company")
    public ResponseEntity<Map<?,?>> getCompany(@RequestBody Map<String, String> payload) throws DataNotFoundException {
    	User user = userService.getByEmail(payload.get("email"));
    	if (user == null) {
            throw new DataNotFoundException("User with selected email was not found.");
        }
    	String company = user.getCompany();
    	Map<String, String> companyMap = new HashMap<String, String>();
    	companyMap.put("company", company);
    	return new ResponseEntity<Map<?,?>>(companyMap, headers, HttpStatus.OK);
    }
    
    @PostMapping("/companyfilter")
    public ResponseEntity<?> getUsersByCompany(@RequestBody Map<String, String> payload) throws DataNotFoundException {

    	User user = userService.getByEmail(payload.get("email"));
    	if (user == null) {
            throw new DataNotFoundException("User with selected email was not found.");
        }
    	String company = user.getCompany();
    	List<User> users = userService.findByCompany(company);
        Map<String, Object> output = getUsersTrialsMap(users);
    	
        return new ResponseEntity<Map<String, Object>> (output, headers, HttpStatus.OK);
    }
    
    @PostMapping("/createpasswordemail")
    public ResponseEntity<?> createPasswordEmail (@RequestBody Map<String, String> obj) throws DataNotFoundException {
    	
    	Map<String,String> map = obj;
    	String email = map.get("email");
    	
    	User user = userService.findByEmail(email).get(0);
        if (user == null) {
        	throw new DataNotFoundException("User with such email not found.");
        }

    	
    	String[] codeAndToken = passwordResetsService.generateAndSaveResetcodeAndToken(email, "create");
		String code = codeAndToken[0];
        String token = codeAndToken[1];
        
        user.setPassword(BCrypt.hashpw(code, BCrypt.gensalt(10)));
        userService.save(user);
    	
		managePasswordEmailService.sendCreatePasswordEmail(email, token);    	
		return new ResponseEntity<String> ("", headers, HttpStatus.OK);
    }    
    
    @PostMapping("/createpassword")
    public ResponseEntity<?> createPassword (@RequestBody Map<String, String> obj) throws DataNotFoundException {
    	
    	Map<String,String> map = obj;
    	String token = map.get("token");
    	String password = map.get("password");
    	
    	PasswordResets passwordress = passwordResetsService.findByToken(token);
    	String email = passwordress.getEmail();    	
    	User user = userService.findByEmail(email).get(0);
        if (user == null) {
        	throw new DataNotFoundException("User with such email not found.");
        }
    	
        if (password != null && !password.isEmpty()){
            user.setPassword(BCrypt.hashpw(password, BCrypt.gensalt(10)));
            userService.save(user);
        } else {
        	throw new DataNotFoundException("User password not found.");
        }
        
        passwordress.setActive(false);
    	passwordResetsService.save(passwordress);    	
		return new ResponseEntity<String> ("", headers, HttpStatus.OK);
    }
    
    @DeleteMapping("/delete/{uuid}")
    public ResponseEntity<?> deleteUser (@PathVariable("uuid") UUID uuid) throws DataNotFoundException {
    	
    	User user = userService.findByUUID(uuid);
    	if (user == null) {
    		throw new DataNotFoundException("User with such uuid not found.");
    	}
    	    	
    	List<UserLogging> userLoggingList = userLoggingService.findByUser(user);
    	if (userLoggingList.size() > 0) {
    		for (UserLogging ul : userLoggingList) {
        		userLoggingService.delete(ul);
        	}
    	}
    	
    	userService.delete(user);
    	
    	ApiResponse response = new ApiResponse("success", "User has been deleted successfully.");
    	
    	return new ResponseEntity<ApiResponse> (response, headers, HttpStatus.OK);
    }
}