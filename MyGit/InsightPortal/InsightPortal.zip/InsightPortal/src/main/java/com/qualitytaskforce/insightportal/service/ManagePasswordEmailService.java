package com.qualitytaskforce.insightportal.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManagePasswordEmailService {

	@Autowired
	EmailServiceImpl emailService;
	
	public void sendResetPasswordEmail(String userEmail, String password, String linkId) {
		
		String emailFrom = "contactus@insightportal.io";
		String emailTo = userEmail;
		String host = "https://www.insightportal.io";
		
		String emailTitle = "InsightPortal – Password Reset";
		String emailContent = "Dear User," 
									+ "<br><br>"
								+ "To reset your InsightPortal password please click on the following link:"
									+ "<br><br>"
								+ host + "/recover-password?id=" + linkId
									+ "<br><br>"
								+ "Your password reset code is: " 
									+ "<br><br>"
								+ password 
									+ "<br><br>"
								+ "If you did not request a password reset, please ignore this email." 
									+ "<br><br>"
								+ "Best Regards," 
									+ "<br><br>"
								+ "Your InsightPortal Team.";
		
		emailService.sendEmail(emailFrom, emailTo, emailTitle, emailContent);
	}
	

	public void sendCreatePasswordEmail(String userEmail, String linkId) {
		
		String emailFrom = "contactus@insightportal.io";
		String emailTo = userEmail;
		String host = "https://www.insightportal.io";
		
		String emailTitle = "InsightPortal – Create password";
		String emailContent = "Dear User," 
									+ "<br><br>"
								+ "To create your InsightPortal password please click on the following link:"
									+ "<br><br>"
								+ host + "/create-password?id=" + linkId
									+ "<br><br>"
								+ "Best Regards," 
									+ "<br><br>"
								+ "Your InsightPortal Team.";
		
		emailService.sendEmail(emailFrom, emailTo, emailTitle, emailContent);
	}
	
}
