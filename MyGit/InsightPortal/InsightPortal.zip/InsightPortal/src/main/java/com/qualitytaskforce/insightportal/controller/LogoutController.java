package com.qualitytaskforce.insightportal.controller;

import javax.servlet.http.HttpServletRequest;

import com.qualitytaskforce.insightportal.model.users.User;
import com.qualitytaskforce.insightportal.model.util.UserLoggingAction;
import com.qualitytaskforce.insightportal.service.users.UserLoggingService;
import com.qualitytaskforce.insightportal.service.users.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Logout Controller is only used to save logout event to database
 */

@RestController
@RequestMapping(value="/userlogout")
public class LogoutController {

    @Autowired
    UserLoggingService userLoggingService;

    @Autowired
    UserService userService;

    @PostMapping(value="/")
    public void logout(HttpServletRequest request, @RequestBody User userBody) {
        String userEmail = userBody.getEmail();
        String ip = userLoggingService.getClientIP(request);
        userLoggingService.saveUserLog(userEmail, ip, UserLoggingAction.LOGOUT);
    }

}
