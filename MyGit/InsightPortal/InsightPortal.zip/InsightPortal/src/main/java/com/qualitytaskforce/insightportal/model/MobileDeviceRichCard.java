package com.qualitytaskforce.insightportal.model;

import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

// import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@DiscriminatorValue(value = "device")
@Table(name = "ta_devices")
public class MobileDeviceRichCard implements java.io.Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "UUID")
	@GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
	@Column(name = "uuid", updatable = false, nullable = false)
	private java.util.UUID uuid;

	@NotNull()
	@Size(min = 1, max = 70, message = "The model must be between {min} and {max} characters long")
	@Column(name = "model", length = 255)
	private String model;

	@NotNull()
	@Size(min = 1, max = 30, message = "The brand must be between {min} and {max} characters long")
	@Column(name = "brand", length = 50)
	private String brand;
	
	@NotNull()
	@Column(name = "type", length = 30)
	private String type;

	@Column(name = "general_status", length = 255)
	private String releaseDate;

	@Column(name = "general_size", length = 50)
	private String displaySize;

	@Column(name = "general_resolution", length = 100)
	private String displayRes;

	@Column(name = "general_os", length = 255)
	private String os;

	@Column(name = "general_chipset", length = 50)
	private String chipset;

	@Column(name = "ram", length = 50)
	private String ram;

	@Column(name = "img_link", length = 255)
	private String imgLink;

	public MobileDeviceRichCard() {

	}

	public MobileDeviceRichCard(java.util.UUID uuid, String model, String brand, String type, String releaseDate, String displaySize,
								String displayRes, String os, String chipset, String ram, String imgLink) {
		this.model = model;
		this.brand = brand;
		this.type = type;
		this.releaseDate = releaseDate;
		this.displaySize = displaySize;
		this.displayRes = displayRes;
		this.os = os;
		this.chipset = chipset;
		this.ram = ram;
		this.imgLink = imgLink;
	}

	public java.util.UUID getUuid() {
		return this.uuid;
	}

	public void setUuid(java.util.UUID uuid) {
		this.uuid = uuid;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}

	public String getReleaseDate() {
		return releaseDate;
	}

	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}

	public String getDisplaySize() {
		return displaySize;
	}

	public void setDisplaySize(String displaySize) {
		this.displaySize = displaySize;
	}

	public String getDisplayRes() {
		return displayRes;
	}

	public void setDisplayRes(String displayRes) {
		this.displayRes = displayRes;
	}

	public String getOs() {
		return os;
	}

	public void setOs(String os) {
		this.os = os;
	}

	public String getChipset() {
		return chipset;
	}

	public void setChipset(String chipset) {
		this.chipset = chipset;
	}

	public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getImgLink() {
		return imgLink;
	}

	public void setImgLink(String imgLink) {
		this.imgLink = imgLink;
	}
}
