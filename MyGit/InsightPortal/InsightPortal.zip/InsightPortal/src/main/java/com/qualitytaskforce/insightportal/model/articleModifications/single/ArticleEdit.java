package com.qualitytaskforce.insightportal.model.articleModifications.single;

import java.util.List;

import com.qualitytaskforce.insightportal.model.ReleaseAdvisor;

public class ArticleEdit {
    String title;
    String summaryText;
    String editorName;
    String editorSurname;
    List<ArticleUpdateWhenSingle> articleUpdates;
    String testRecommendation;
    String fullText;
    ReleaseAdvisor releaseAdvisor;

    public String getEditorName() {
        return editorName;
    }

    public void setEditorName(String editorName) {
        this.editorName = editorName;
    }

    public String getEditorSurname() {
        return editorSurname;
    }

    public void setEditorSurname(String editorSurname) {
        this.editorSurname = editorSurname;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummaryText() {
        return summaryText;
    }

    public void setSummaryText(String summaryText) {
        this.summaryText = summaryText;
    }

    public List<ArticleUpdateWhenSingle> getArticleUpdates() {
        return articleUpdates;
    }

    public void setArticleUpdates(List<ArticleUpdateWhenSingle> articleUpdates) {
        this.articleUpdates = articleUpdates;
    }

    public String getTestRecommendation() {
        return testRecommendation;
    }

    public void setTestRecommendation(String testRecommendation) {
        this.testRecommendation = testRecommendation;
    }

    public String getFullText() {
        return fullText;
    }

    public void setFullText(String fullText) {
        this.fullText = fullText;
    }


}

