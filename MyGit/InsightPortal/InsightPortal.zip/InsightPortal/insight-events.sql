DELIMITER //
CREATE EVENT IF NOT EXISTS refresh_api_limits
ON SCHEDULE EVERY 1 MONTH
STARTS '2018-01-01 00:00:00'
ON COMPLETION PRESERVE
COMMENT 'Refreshes the api limits on all keys'
DO
BEGIN
	UPDATE api_keys s
	JOIN (SELECT uuid, `low_monthly` FROM `api_limits`) l 
	ON s.limit_tier = l.uuid SET s.low_monthly = l.low_monthly;

	UPDATE api_keys s
	JOIN (SELECT uuid, `med_monthly` FROM `api_limits`) l 
	ON s.limit_tier = l.uuid SET s.med_monthly = l.med_monthly;

	UPDATE api_keys s
	JOIN (SELECT uuid, `high_monthly` FROM `api_limits`) l 
	ON s.limit_tier = l.uuid SET s.high_monthly = l.high_monthly;
END
//
DELIMITER ;