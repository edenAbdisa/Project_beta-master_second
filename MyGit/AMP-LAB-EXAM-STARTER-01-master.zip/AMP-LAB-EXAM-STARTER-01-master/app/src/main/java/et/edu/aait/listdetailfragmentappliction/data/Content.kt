package et.edu.aait.listdetailfragmentappliction.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class Content(@PrimaryKey val value:String)
